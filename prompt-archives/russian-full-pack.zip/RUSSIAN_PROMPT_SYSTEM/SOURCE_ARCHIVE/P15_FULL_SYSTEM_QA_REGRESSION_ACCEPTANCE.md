# P15 — FULL-SYSTEM QA · REGRESSION · ACCEPTANCE CONSTITUTION
## CROSS-PHASE VERIFICATION · E2E · DEVICE/BROWSER · OFFLINE · SECURITY · PERFORMANCE · ACCEPTANCE EVIDENCE

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Execution mode:

**AUTONOMOUS · EVIDENCE-FIRST · RISK-BASED · CROSS-PHASE · DEFECT-DRIVEN · REPRODUCIBLE · NO-KNOWN-BLOCKER · TOKEN-EFFICIENT**

---

# P15 CHANGELOG

- 2026-09-30 — Full deep P15 constitution created.
- 2026-09-30 — Final hardening: evidence freshness/parity, test-infrastructure validation, intermittent/soak recovery, resource-pressure/network adversity, artifact integrity, skipped/flaky-test governance, candidate lineage, cross-domain rechecks and RC evidence hashing.

---

# 0. MISSION

P15 is the integrated acceptance layer.

P1–P14 can each look correct in isolation and still fail when combined.

P15 proves that the complete Russian learning system works as one product across real journeys, real state transitions, real failure modes and representative devices without violating upstream contracts.

P15 does not primarily design or build.

It verifies, isolates defects, routes fixes to the correct owner, retests and decides whether the system is acceptable for Release Candidate freeze.

---

# 1. P15 AUTHORITY BOUNDARY

P15 may:

- inspect;
- test;
- reproduce;
- classify;
- block;
- request an upstream fix;
- verify a fix;
- sign acceptance evidence.

P15 must not silently:

- change curriculum;
- change mastery rules;
- weaken security;
- lower acceptance criteria;
- bypass governance merely to get green tests.

---

# 2. INPUTS

P15 consumes P0–P14:

- contracts;
- phase evidence;
- risk registers;
- known limitations;
- migration maps;
- device/browser support;
- performance budgets;
- security mitigations;
- content snapshots;
- golden fixtures.

Missing required evidence becomes:

`UPSTREAM_EVIDENCE_GAP`.

Do not fabricate PASS.

---

# 3. ACCEPTANCE ≠ UNIT TEST GREEN

P15 requires a portfolio of evidence:

- static checks;
- unit tests;
- integration tests;
- E2E;
- browser/device;
- accessibility;
- offline;
- migration;
- security;
- performance;
- manual exploratory;
- content sampling.

No single suite is enough.

---

# 4. TEST PORTFOLIO

Use the cheapest level that can prove a contract:

`STATIC`

`UNIT`

`INTEGRATION`

`CONTRACT`

`E2E`

`EXPLORATORY`

`NON_FUNCTIONAL`.

Avoid moving every rule into brittle browser tests.

---

# 5. RISK-BASED PRIORITY

Highest priority:

- learner-state integrity;
- official assessment;
- content truth;
- authoring activation;
- migration;
- offline sync;
- security;
- AI source integrity;
- long writing;
- scenario state;
- rollback.

Cosmetic polish does not outrank these.

---

# 6. DEFECT SEVERITY

Use:

`BLOCKER`

`CRITICAL`

`HIGH`

`MEDIUM`

`LOW`.

Severity describes impact, not repair difficulty.

---

# 7. BLOCKER

Examples:

- core course cannot start;
- official learner work lost;
- assessment answer leaked before submit;
- secret exposed;
- privilege escalation;
- migration irreversibly corrupts state;
- rollback impossible;
- official submission duplicates or disappears.

P15 cannot PASS with a known blocker.

---

# 8. CRITICAL

Examples:

- supported major device class unusable;
- offline core fails contract;
- AI fabricates source in research mode;
- scenario world contradicts state;
- content activation bypasses approval;
- long drafts intermittently disappear;
- core keyboard/screen-reader path blocked.

Normally unresolved CRITICAL means FAIL.

---

# 9. PRIORITY ≠ SEVERITY

Priority may include:

- frequency;
- affected population;
- workaround;
- release timing.

Do not relabel severity to improve release metrics.

---

# 10. DEFECT STATUS

`NEW`

`TRIAGED`

`REPRODUCED`

`ASSIGNED`

`FIX_IN_PROGRESS`

`READY_FOR_RETEST`

`VERIFIED`

`REOPENED`

`DEFERRED`

`ACCEPTED_RISK`

`CLOSED`.

---

# 11. DEFECT OWNER ROUTING

Route to canonical responsibility:

- P3 schema/content identity;
- P4 mastery/assessment state;
- P6 speech/audio;
- P7 linguistic;
- P8 technical;
- P9 writing/research;
- P10 AI;
- P11 scenario;
- P12 authoring;
- P13 UX/a11y;
- P14 infra/security.

Do not patch in the wrong layer.

---

# 12. DEFECT RECORD

Every important defect records:

- candidate SHA;
- content snapshot;
- environment;
- role;
- preconditions;
- steps;
- expected;
- actual;
- evidence;
- frequency;
- severity;
- suspected owner.

---

# 13. REPRODUCIBILITY

Classify:

`ALWAYS`

`FREQUENT`

`INTERMITTENT`

`ONCE`

`NOT_REPRODUCED`.

Intermittent is still real.

---

# 14. EVIDENCE TYPES

Use when appropriate:

- test logs;
- screenshots;
- short video;
- network trace;
- console/error trace;
- state snapshot;
- scenario event trace;
- semantic diff;
- performance trace;
- accessibility result.

Redact private data.

---

# 15. TEST ENVIRONMENTS

Distinguish:

`LOCAL`

`CI`

`PREVIEW`

`STAGING`

`PRODUCTION_LIKE`.

Acceptance must run sufficiently close to release conditions.

---

# 16. ENVIRONMENT PARITY

Record differences in:

- auth;
- database;
- CDN;
- service worker;
- APIs;
- feature flags;
- AI provider;
- storage.

Do not transfer PASS blindly across materially different environments.

---

# 17. TEST DATA

Use controlled accounts/fixtures.

Avoid real learner private data.

---

# 18. TEST DATA RESET

Reset test fixtures only.

Never target production data.

---

# 19. GOLDEN DATA

Version known-good fixtures for:

- vocabulary;
- grammar;
- lesson;
- assessment;
- scenario;
- writing source;
- AI;
- migration.

---

# 20. CROSS-PHASE ACCEPTANCE MAP

Build the central matrix:

`CONTRACT → OWNER PHASE → IMPLEMENTATION → TEST → EVIDENCE → STATUS`.

This prevents forgotten requirements.

---

# 21. ORPHAN CONTRACT

If an upstream critical contract has no test/evidence:

flag it.

---

# 22. ORPHAN TEST

If a test no longer maps to requirement/regression value:

review or retire it.

---

# 23. TEST TAGS

Use useful tags such as:

`SMOKE`

`CRITICAL`

`OFFLINE`

`ASSESSMENT`

`AI`

`SCENARIO`

`AUTHORING`

`MIGRATION`

`SECURITY`

`A11Y`

`PERFORMANCE`.

---

# 24. SMOKE SUITE

Fast checks after build/deploy:

- app opens;
- Russian subject resolves;
- active snapshot loads;
- one lesson;
- one review;
- one audio;
- one state write;
- author/admin route if applicable.

---

# 25. CRITICAL SUITE

Cover every blocker-class path.

Must pass before RC freeze.

---

# 26. FULL REGRESSION

Broader functional and non-functional matrix.

---

# 27. CHANGE-BASED REGRESSION

Use impact/dependency map after a fix.

Still run global critical smoke.

---

# 28. CANDIDATE IDENTITY

Every test result belongs to exact:

- repo SHA;
- content snapshot;
- environment/config;
- dependency lock/build artifact.

No acceptance against a moving target.

---

# 29. UNIT ACCEPTANCE

Critical pure logic includes:

- mastery transition;
- SRS;
- scoring;
- parser;
- scenario guard;
- migration;
- validator;
- import mapping.

Code-coverage percentage alone is insufficient.

---

# 30. INTEGRATION ACCEPTANCE

Test boundaries:

- content → lesson;
- lesson → learner state;
- assessment → P4;
- AI → retrieval;
- scenario → P6/P10;
- editor → validators;
- activation → snapshot;
- offline queue → server/action.

---

# 31. CONTRACT TESTS

Stabilize interfaces for:

- schema;
- AI structured output;
- scenario events;
- sync operation;
- authoring API.

---

# 32. CONTENT/SCHEMA INTEGRITY

All active canonical entities validate.

No dangling required refs.

IDs unique.

Owner registry consistent.

---

# 33. CURRICULUM INTEGRITY

Validate:

- stages;
- module/unit order;
- prerequisites;
- objectives;
- stage gates.

---

# 34. P7 REGRESSION

Run linguistic golden set and changed-scope samples.

---

# 35. P8 REGRESSION

Run technical truth golden set and affected domains.

---

# 36. P9 REGRESSION

Run source-lineage, meaning-preservation and NIR/VKR fixtures.

---

# 37. P10 REGRESSION

Run:

- canonical grounding;
- source fabrication;
- prompt injection;
- assessment leak;
- writing locks;
- model/provider fallback.

---

# 38. P11 REGRESSION

Run:

- state/world consistency;
- hidden facts;
- branch/replay;
- stale AI response;
- offline deterministic fallback.

---

# 39. P12 REGRESSION

Run:

- permissions;
- review;
- approval invalidation;
- import;
- activation;
- rollback;
- concurrency.

---

# 40. P13 REGRESSION

Run critical journeys, responsive and accessibility matrix.

---

# 41. P14 REGRESSION

Run offline, service worker, migration, security, performance and restore evidence.

---

# 42. LEARNER JOURNEY J1 — ENTRY

Open app → Russian subject → current stage → primary task.

Acceptance:

- route resolves;
- current status understandable;
- no irrelevant setup blocker.

---

# 43. J2 — TODAY

Open Today → understand priority/reason → start task → finish → plan updates once.

UI must consume P5, not compute another plan.

---

# 44. J3 — LESSON

Open module/unit → learn → practice → feedback → continue.

Test reload/back/deep link.

---

# 45. J4 — SRS REVIEW

Open due queue → answer → feedback → next → queue changes exactly once.

---

# 46. J5 — LISTENING

Play → replay → answer → transcript according policy → feedback.

Test audio failure fallback.

---

# 47. J6 — SPEAKING

Grant mic → record → stop → transcript/signal → feedback → retry.

Also deny mic and use fallback.

---

# 48. J7 — OFFICIAL ASSESSMENT

Start → answer → submit once → result/rubric → retry/history according P4.

No pre-submit answer leak.

---

# 49. J8 — SCENARIO

Read objective → interact → misunderstanding → repair → branch → completion → debrief.

World remains consistent.

---

# 50. J9 — WRITING

Open source/task → draft → autosave → AI advisory feedback → revise → submit.

Drop network during draft.

---

# 51. J10 — RESEARCH/NIR

Source note → objective/method/result → source lineage preserved.

---

# 52. J11 — DEFENSE

Presentation → question → answer → follow-up → debrief.

No invented project facts.

---

# 53. J12 — SEARCH

Search Cyrillic/VI/EN alias → open result → return.

---

# 54. J13 — OFFLINE CORE

Download pack → offline → lesson → review → draft → deterministic scenario → reconnect → sync.

No duplicate state.

---

# 55. J14 — UPDATE

Old app/content → update available → safe activation → active draft/session preserved.

---

# 56. J15 — STORAGE PRESSURE

Near quota → disposable cleanup → critical work survives.

---

# 57. J16 — MULTI-TAB

Same draft/task in two tabs → conflicting edit → no silent overwrite.

---

# 58. AUTHOR JOURNEY A1 — EDIT

Find entity → edit draft → validate → save → submit review.

---

# 59. A2 — REVIEW

Review semantic diff + source + impact → approve/request changes.

---

# 60. A3 — ASSESSMENT FIX

Block bad item if urgent → edit accepted answer → validate → inspect learner-impact classification.

---

# 61. A4 — SCENARIO EDIT

Change branch/world → graph validation → sandbox preview → review.

---

# 62. A5 — BULK IMPORT

Upload → map → validate → repair errors → draft batch.

No direct active import.

---

# 63. A6 — ACTIVATION

Approved changeset → stage → derived build → smoke → activate snapshot → verify.

---

# 64. A7 — ROLLBACK

Bad activation → inspect impact → rollback/forward fix → verify known-good state.

---

# 65. A8 — PERMISSION

Contributor calls activation directly.

Server/action must deny.

---

# 66. E2E FIXTURE CLEANUP

Tests clean their own data.

No polluted shared environment.

---

# 67. E2E SELECTORS

Use stable semantic/test IDs.

Avoid brittle CSS position selectors.

---

# 68. E2E WAITS

Wait for semantic state/network result.

Avoid arbitrary sleeps.

---

# 69. MOCK VS REAL

Use mocks for deterministic edge cases and real integrations for critical acceptance paths.

Both are required.

---

# 70. AI MOCK

Structured deterministic AI mock verifies app contract without stochastic CI.

---

# 71. REAL AI ACCEPTANCE

Small real-provider suite verifies candidate model/config.

Do not make every test depend on live AI.

---

# 72. SPEECH MOCK + REAL DEVICE

Mock recognition workflow in CI.

Use representative real browser/device for mic/media acceptance.

---

# 73. MIGRATION FIXTURES

Keep realistic prior-version state samples.

---

# 74. BROWSER MATRIX

Use P14 supported browsers.

Record exact tested versions.

Do not claim untested support.

---

# 75. MOBILE MATRIX

Representative:

- small viewport;
- mid-range Android;
- iOS Safari if supported;
- tablet.

Real device for PWA/mic/storage where emulator insufficient.

---

# 76. DESKTOP MATRIX

Representative Windows/macOS based on actual support/audience.

---

# 77. RESPONSIVE MATRIX

Test:

- small mobile;
- large mobile;
- tablet;
- laptop;
- wide desktop.

---

# 78. INPUT MATRIX

- mouse;
- touch;
- keyboard;
- microphone;
- text fallback.

---

# 79. ORIENTATION

Portrait + landscape for mobile/tablet critical views.

---

# 80. LARGE TEXT

Test enlarged font/zoom with no clipped critical controls.

---

# 81. DARK/HIGH-CONTRAST

If supported by product.

---

# 82. REDUCED MOTION

If supported.

---

# 83. ACCESSIBILITY TARGET

Use recognized web accessibility expectations such as WCAG 2.2 AA where applicable to web UI.

Document any project-specific exception.

---

# 84. A11Y AUTOMATION

Automated scan helps find:

- label;
- role;
- contrast;
- duplicate ID;
- landmark issues.

It cannot prove full accessibility.

---

# 85. A11Y MANUAL

Test:

- keyboard;
- focus;
- dialogs;
- screen-reader semantics;
- errors;
- audio transcripts;
- drag alternatives.

---

# 86. KEYBOARD-ONLY

Complete representative lesson, review, assessment and author form without mouse.

---

# 87. SCREEN READER

Test representative learner and author flows with a supported screen-reader/browser combination where available.

---

# 88. COLOR/CONTRAST/ZOOM

No color-only meaning.

Themes readable.

Critical UI usable at enlarged text/zoom.

---

# 89. OFFLINE ACCEPTANCE

Disable actual network, not just toggle an app flag.

---

# 90. FIRST-INSTALL OFFLINE

Expected behavior is explicit if app/pack was never loaded.

---

# 91. WARM OFFLINE

Previously downloaded current content works.

---

# 92. INTERRUPTED PACK DOWNLOAD

Drop network mid-install.

No partial-active pack.

---

# 93. OFFLINE UPDATE

New snapshot exists while device offline.

Old compatible pack remains usable.

---

# 94. RECONNECT/SYNC

Queued authoritative write applies exactly once.

---

# 95. AUTH EXPIRY DURING SYNC

Work remains queued until re-auth.

---

# 96. STORAGE EVICTION

Simulate where feasible.

App detects degraded local data and offers recovery.

---

# 97. OLD TAB AFTER DEPLOY

Keep old tab across deploy.

Test chunk/service-worker/data compatibility.

---

# 98. MIGRATION ACCEPTANCE

Every supported prior state version upgrades to candidate.

---

# 99. LEARNER-STATE MIGRATION

Representative:

- unseen;
- in progress;
- demonstrated;
- review due;
- first attempt;
- retries;
- writing draft;
- scenario state.

---

# 100. MIGRATION FAILURE

Inject corrupt/unsupported fixture.

Recovery path must work.

---

# 101. MIGRATION IDEMPOTENCY

Running migration again does not duplicate/corrupt.

---

# 102. ROLLBACK/DOWNGRADE

Test supported rollback route and compatibility gates.

---

# 103. PERFORMANCE ACCEPTANCE

Use P14 budgets and comparable test conditions.

---

# 104. COLD START

No warm cache.

---

# 105. WARM START

Expected caches available.

---

# 106. FIRST LEARNING ACTION

Measure time to usable primary task.

---

# 107. ROUTE NAVIGATION

Today → lesson and common back/forward.

---

# 108. SEARCH SCALE

Test realistic 8k vocabulary + other indexed content.

---

# 109. SRS SCALE

Representative backlog.

---

# 110. LONG WRITING

Large draft typing remains responsive.

---

# 111. ADMIN LARGE LIST

Filters/pagination/virtualization remain usable.

---

# 112. SCENARIO LONG SESSION

Repeated turns do not leak memory or slow catastrophically.

---

# 113. MEDIA START

Representative audio/video startup and seek.

---

# 114. MEMORY ACCEPTANCE

Repeated route/recording/AI cycles do not show unbounded growth.

---

# 115. PERFORMANCE COMPARISON

Compare against P14 baseline and defined thresholds.

---

# 116. SECURITY ACCEPTANCE

Use P14 threat model.

---

# 117. SECRET SCAN

Scan repo/build output and inspect exposed client config.

---

# 118. XSS / STORED XSS

Test learner, imported, AI and admin-authored content rendering.

---

# 119. DANGEROUS URL / MARKDOWN

Unsafe scheme/script remains inert/rejected.

---

# 120. CSP / HEADERS

Headers present where applicable and legitimate flows still work.

---

# 121. AUTHORIZATION

Call protected server/action endpoints directly with insufficient role.

Must fail.

---

# 122. CROSS-USER ACCESS

Changing resource ID must not expose another learner's private state/draft.

---

# 123. STALE ROLE

Revoke role and verify old session cannot perform privileged action.

---

# 124. CSRF/CORS

Test according to actual auth architecture.

Do not invent irrelevant threat.

---

# 125. RATE LIMIT

High-cost/auth paths protected without harming normal use.

---

# 126. UPLOAD/ARCHIVE

Reject malicious/oversized/wrong-type payloads and unsafe archive extraction.

---

# 127. CSV FORMULA INJECTION

Mitigate on spreadsheet-targeted exports where applicable.

---

# 128. DEPENDENCY GATE

No unresolved release-blocking exploitable dependency issue.

---

# 129. AI SECURITY

Prompt/source injection cannot override P10 permission contract.

---

# 130. AI SOURCE INTEGRITY

Real/canonical source fixture cannot become fabricated citation.

---

# 131. AI ASSESSMENT LEAK

Official route cannot reveal hidden answer through Mentor.

---

# 132. AI STATE WRITE

AI cannot directly mark mastery, unlock stage or change official score.

---

# 133. AI OUTAGE

Core app continues with deterministic/canonical fallback.

---

# 134. AI STALE RESPONSE

Older response cannot overwrite newer draft/task context.

---

# 135. AI PROVIDER/MODEL REGRESSION

Run P10 golden suite against actual release config.

---

# 136. CONTENT ACCEPTANCE STRATEGY

Do not manually inspect every record.

Combine:

- validators;
- golden sets;
- changed-scope review;
- stratified risk sampling.

---

# 137. CONTENT SAMPLE DESIGN

Sample across:

- stage;
- skill;
- domain;
- source;
- generated/manual;
- risk.

---

# 138. VOCAB SAMPLE

Check:

stress;
sense;
collocation;
government;
example;
source.

---

# 139. GRAMMAR SAMPLE

Function/form/example/error handling.

---

# 140. LISTENING SAMPLE

Audio/transcript/task alignment.

---

# 141. SPEAKING SAMPLE

Prompt/rubric/evidence alignment.

---

# 142. TECHNICAL SAMPLE

P8 terminology/fact consistency.

---

# 143. RESEARCH SAMPLE

P9 source/claim integrity.

---

# 144. SCENARIO SAMPLE

World/role/branch/language consistency.

---

# 145. ASSESSMENT SAMPLE

Accepted variants, hidden answer and objective mapping.

---

# 146. DERIVED-ARTIFACT TEST

Search/link/index artifacts must derive from canonical owners and match active snapshot.

---

# 147. SEARCH ACCEPTANCE

Queries include:

- Cyrillic;
- stressless text;
- Vietnamese;
- English technical alias;
- abbreviation;
- ambiguous domain term.

---

# 148. UX ACCEPTANCE

Verify P13 semantics and blockers, not personal aesthetic preference.

---

# 149. VISUAL REGRESSION

Review representative screenshots against accepted baseline.

---

# 150. GLYPH TEST

No broken Cyrillic, Vietnamese, stress marks, math symbols or code glyphs.

---

# 151. OVERFLOW TEST

Long URL, technical term, formula, code and table do not break page.

---

# 152. MOBILE TEST

Primary action visible; normal page has no accidental horizontal scroll.

---

# 153. SETTINGS TEST

Font/theme/language changes are truthful and do not mutate learning state.

---

# 154. SAVED/PROGRESS STATE TEST

`Saved`, `Completed`, `Mastered`, `Published`, `Offline` display only when domain/runtime state supports them.

---

# 155. EXPLORATORY CHARTERS

Run explicit charters:

- Try to lose a draft.
- Try to duplicate an official attempt.
- Try to reveal an answer through AI.
- Try to confuse scenario state.
- Try to activate unreviewed content.
- Try to break offline update.
- Try to overflow mobile UI.
- Try to keep a stale tab through deploy.

---

# 156. FAILURE INJECTION

In isolated environment inject:

- network loss;
- timeout;
- 500;
- 429;
- corrupted cache fixture;
- storage denial;
- expired auth;
- AI outage.

Observe recovery.

---

# 157. NO UNSAFE CHAOS

Never corrupt real production learner data to test failure handling.

---

# 158. FLAKY TEST

Flakiness is a defect in test or system.

Track and repair.

---

# 159. TEST RETRY

Retry may diagnose transient behavior but must not hide first-attempt failures.

Record retries.

---

# 160. TEST ISOLATION

Tests must be order-independent where feasible.

---

# 161. TEST PARALLELISM

Parallel jobs use isolated fixtures/state.

---

# 162. CI LAYERS

PR:

fast high-signal affected tests.

Main/RC:

broader suites.

Scheduled:

expensive browser/performance/security trends if useful.

---

# 163. NO MOVING TARGET

If candidate SHA or content snapshot changes after acceptance run, retest affected scope plus critical smoke.

---

# 164. FIX LOOP

`FAIL → TRIAGE → OWNER FIX → NEW CANDIDATE → REPRO RETEST → IMPACT REGRESSION → GATE UPDATE`.

---

# 165. FIX VERIFICATION

Original reproduction must pass.

---

# 166. NEIGHBOR REGRESSION

Test behavior adjacent to changed logic.

---

# 167. ESCAPED DEFECT

Add regression at lowest useful test layer after a blocker/critical escape.

---

# 168. ROOT-CAUSE CLASS

For serious defect classify root cause:

- requirement gap;
- implementation;
- test gap;
- migration;
- config;
- dependency;
- environment;
- content;
- concurrency.

---

# 169. KNOWN LIMITATION

A limitation is intentional and documented.

It is not a hidden defect.

---

# 170. ACCEPTED RISK

Record:

- issue;
- severity;
- mitigation;
- reason;
- owner;
- revalidation trigger.

P15 still reports residual risk honestly.

---

# 171. ACCEPTANCE GATES

`GATE-A FUNCTIONAL`

`GATE-B DATA INTEGRITY`

`GATE-C CONTENT`

`GATE-D OFFLINE/MIGRATION`

`GATE-E SECURITY`

`GATE-F PERFORMANCE`

`GATE-G ACCESSIBILITY/UX`

`GATE-H OPERABILITY/ROLLBACK`.

---

# 172. GATE-A FUNCTIONAL

Core learner + author/admin journeys pass.

---

# 173. GATE-B DATA INTEGRITY

No loss, duplicate authoritative write or state corruption.

---

# 174. GATE-C CONTENT

Active snapshot, schemas, golden sets and risk samples pass.

---

# 175. GATE-D OFFLINE/MIGRATION

Supported offline, update and migration paths pass.

---

# 176. GATE-E SECURITY

No known release-blocking security defect in scope.

---

# 177. GATE-F PERFORMANCE

Budgets/regression gates pass or have explicit non-blocking exception under project policy.

---

# 178. GATE-G ACCESSIBILITY/UX

Critical accessible/responsive journeys pass.

---

# 179. GATE-H OPERABILITY

Observability, backup/restore where relevant and rollback work.

---

# 180. ACCEPTANCE MATRIX

Every gate records:

criterion;
test;
result;
evidence;
owner;
residual risk.

---

# 181. PASS STATES

Use:

`PASS`

`PASS_WITH_DOCUMENTED_NON_BLOCKING_RISKS`

`FAIL`

`BLOCKED`.

Do not use vague “almost pass”.

---

# 182. BLOCKED

Cannot verify because critical environment/evidence/dependency unavailable.

Blocked is not PASS.

---

# 183. MANUAL ACCEPTANCE

Use manual review where automation cannot prove:

- linguistic naturalness;
- audio quality;
- complex usability;
- source fidelity;
- screen-reader experience;
- defense realism.

---

# 184. UAT

If teachers/real target learners are available, run representative UAT/pilot.

If not, record that limitation explicitly rather than pretending it happened.

---

# 185. TEST ROLES

Representative accounts:

learner;
author;
reviewer;
admin

when these roles exist.

---

# 186. DATA ISOLATION

No private state/draft leaks across test accounts.

---

# 187. LOCALE ACCEPTANCE

Test actual supported UI/support language modes.

---

# 188. BILINGUAL MODE

Meaning aligned and responsive.

---

# 189. UI LANGUAGE VS COURSE CONTENT

Changing UI language cannot rewrite canonical Russian learning content.

---

# 190. PWA ACCEPTANCE

If PWA is supported:

- manifest;
- launch;
- standalone nav;
- offline;
- update;
- safe data behavior.

---

# 191. EXPORT/IMPORT ACCEPTANCE

Only for implemented features.

Verify Unicode, formulas/code and round-trip where promised.

---

# 192. NO-CODE AUTHORING ACCEPTANCE

Create representative vocab, lesson unit, assessment and scenario without application-code change.

If impossible, P12 requirement is not satisfied.

---

# 193. AUTHORING AUDIT

Every meaningful change has actor/revision/action.

---

# 194. APPROVAL INVALIDATION

Semantic edit after approval forces required re-review.

---

# 195. EMERGENCY BLOCK

Bad active content can be disabled quickly while history remains intact.

---

# 196. SNAPSHOT REPRODUCIBILITY

Active content set can be verified/reconstructed from manifest.

---

# 197. ROLLBACK ACCEPTANCE

Rollback candidate/new snapshot to last known-good.

Verify app, state compatibility and content.

---

# 198. BACKUP RESTORE ACCEPTANCE

Where server-side backup exists, perform representative restore evidence.

Backup job success alone is insufficient.

---

# 199. OBSERVABILITY ACCEPTANCE

Trigger representative failures:

- client crash;
- API error;
- migration failure;
- AI outage;
- activation failure.

Verify actionable diagnostic signal.

---

# 200. LOG REDACTION

Inspect diagnostics for secrets, auth headers and unnecessary confidential content.

---

# 201. EVIDENCE INDEX

Central index links:

- gate;
- test;
- result;
- artifact;
- defect;
- candidate.

---

# 202. TEST REPORT

Each suite records:

scope;
environment;
candidate;
cases;
results;
defects;
limitations.

---

# 203. DEFECT SUMMARY

Count by severity/status, but never use count alone as release verdict.

---

# 204. PASS-RATE LIMITATION

99% pass can still contain one blocker.

---

# 205. COVERAGE LIMITATION

High code coverage can still miss data-loss/security failures.

---

# 206. RELEASE-BLOCKER LIST

Explicit list.

P16 cannot freeze with unresolved blocker.

---

# 207. CRITICAL RESIDUAL LIST

Explicit.

---

# 208. DEFERRED LIST

Only non-blocking items under policy.

---

# 209. P15 SIGNOFF

P15 signoff is technical/product acceptance evidence.

Final production release authority remains P17/release owner.

---

# 210. P16 HANDOFF PACKAGE

Include exact:

- candidate SHA;
- content snapshot;
- environment/config;
- acceptance report;
- blocker/critical status;
- known limitations;
- performance report;
- security report;
- accessibility report;
- offline/migration report;
- rollback evidence;
- defect register.

---

# 211. P16 MAY NOT REINTERPRET FAIL

If P15 FAIL, P16 cannot rename it Release Candidate.

Fix/retest first.

---

# 212. TEST ARTIFACT RETENTION

Keep enough acceptance evidence to support RC/release forensics.

Exact retention is project policy.

---

# 213. GOLDEN-FIXTURE GOVERNANCE

Do not change expected result merely to make implementation green.

Fixture changes need reason and authority.

---

# 214. CRITICAL TEST REVIEW

Critical acceptance test changes deserve code review.

---

# 215. PROPERTY-BASED TESTING

Useful for:

- migrations;
- scenario state;
- parsers;
- invariants.

Not mandatory everywhere.

---

# 216. FUZZING

Bounded fuzz useful for:

- import;
- URL/text parsing;
- malformed state;
- scenario intent parser.

---

# 217. SECURITY DYNAMIC TEST

If tooling exists, run against isolated environment.

Manual authorization logic tests remain necessary.

---

# 218. PERFORMANCE AUTOMATION

Trend reports help detect regression but noisy lab metrics need review.

---

# 219. A11Y AUTOMATION TREND

Zero automated violations does not equal complete accessibility.

---

# 220. VISUAL BASELINE UPDATE

Only after reviewed intentional design change.

---

# 221. AI GOLDEN UPDATE

Only for validated policy/content/model change, not stochastic wording preference.

---

# 222. QA IDENTITIES

Stable IDs for:

- requirements;
- tests;
- defects;
- evidence;
- candidate.

---

# 223. P15 INITIAL VERTICAL SLICE

Before full acceptance, validate the QA harness using:

- Today;
- lesson;
- SRS;
- speaking;
- offline;
- author edit;
- activation;
- rollback.

---

# 224. FULL ACCEPTANCE ORDER

Recommended:

1. Candidate identity.
2. Static/schema/content checks.
3. Unit/integration.
4. Critical smoke.
5. Learner E2E.
6. Author/admin E2E.
7. Browser/device.
8. Accessibility.
9. Offline/migration.
10. AI/scenario.
11. Security.
12. Performance.
13. Restore/rollback.
14. Exploratory/failure injection.
15. Defect closure/retest.
16. Final gates.

---

# 225. STOP-THE-LINE

Stop expensive acceptance immediately for:

- data corruption;
- secret leak;
- privilege escalation;
- assessment integrity break;
- irreversible migration;
- candidate identity changing unexpectedly.

---

# 226. CHEAP GATES FIRST

Run high-signal cheap failures before long visual/performance suites.

---

# 227. TOKEN-EFFICIENT CONTINUATION

When resuming P15 work, read:

- latest P15 status;
- candidate identity;
- open defect register;
- affected contracts;
- latest diff.

Do not re-read all P1–P14 unless impact requires.

---

# 228. DEFECT FIX LOOP

`FAIL → TRIAGE → OWNER FIX → NEW CANDIDATE → REPRO RETEST → IMPACTED REGRESSION → GATE UPDATE`.

---

# 229. P15 REQUIRED DELIVERABLES — CORE

Create/maintain:

`subjects/russian/docs/p15/RUSSIAN_P15_EXECUTIVE_SUMMARY.md`

`RUSSIAN_ACCEPTANCE_TRACEABILITY_MATRIX.md`

`RUSSIAN_TEST_INVENTORY.md`

`RUSSIAN_CRITICAL_JOURNEY_TEST_PLAN.md`

`RUSSIAN_BROWSER_DEVICE_MATRIX.md`

`RUSSIAN_DEFECT_SEVERITY_TRIAGE_POLICY.md`

`RUSSIAN_ACCEPTANCE_GATE_MATRIX.md`.

---

# 230. REQUIRED DELIVERABLES — REGRESSION

Create:

`RUSSIAN_P1_P14_REGRESSION_MATRIX.md`

`RUSSIAN_CONTENT_REGRESSION_REPORT.md`

`RUSSIAN_AI_REGRESSION_ACCEPTANCE.md`

`RUSSIAN_SCENARIO_REGRESSION_ACCEPTANCE.md`

`RUSSIAN_AUTHORING_REGRESSION_ACCEPTANCE.md`

`RUSSIAN_UX_ACCESSIBILITY_ACCEPTANCE.md`.

---

# 231. REQUIRED DELIVERABLES — NON-FUNCTIONAL

Create:

`RUSSIAN_OFFLINE_MIGRATION_ACCEPTANCE.md`

`RUSSIAN_PERFORMANCE_ACCEPTANCE.md`

`RUSSIAN_SECURITY_ACCEPTANCE.md`

`RUSSIAN_BACKUP_ROLLBACK_ACCEPTANCE.md`

`RUSSIAN_OBSERVABILITY_ACCEPTANCE.md`.

---

# 232. REQUIRED DELIVERABLES — FINAL

Create:

`RUSSIAN_P15_DEFECT_REGISTER.json`

`RUSSIAN_P15_KNOWN_LIMITATIONS.md`

`RUSSIAN_P15_EVIDENCE_INDEX.md`

`RUSSIAN_P15_FINAL_ACCEPTANCE_REPORT.md`

`RUSSIAN_P16_INPUT_CONTRACT.md`.

No empty ceremonial documents.

---

# 233. P15 BLOCKERS

P15 is BLOCKED if:

- exact candidate cannot be identified;
- active content snapshot unknown;
- critical environment unavailable;
- official state integrity cannot be tested;
- security/auth test impossible;
- rollback path unavailable;
- upstream evidence required for interpretation is missing.

---

# 234. P15 FAIL CONDITIONS

P15 FAIL if:

- any mandatory gate fails;
- unresolved blocker remains;
- unresolved critical remains under normal policy;
- test evidence belongs to another candidate;
- critical browser/device support is unverified;
- offline contract fails;
- migration corrupts state;
- AI/source integrity fails;
- scenario world/state fails;
- authoring governance fails;
- security gate fails;
- performance exceeds accepted gate;
- accessibility blocks a core journey;
- rollback cannot restore known-good.

---

# 235. P15 PASS CONDITIONS

P15 PASS when:

1. Exact candidate identity is frozen for test.
2. Required P1–P14 evidence exists.
3. Static/schema/content integrity passes.
4. Critical unit/integration passes.
5. Core learner journeys pass.
6. Core author/admin journeys pass.
7. Official assessment integrity passes.
8. First-attempt/idempotency passes.
9. Writing draft safety passes.
10. Mastery/SRS state integrity passes.
11. Scenario state/world integrity passes.
12. AI grounding/source/permission passes.
13. Authoring review/activation/rollback passes.
14. Supported browser/device matrix passes.
15. Responsive critical screens pass.
16. Accessibility critical journeys pass.
17. Offline core passes.
18. Service-worker/pack/update passes.
19. Migration/recovery passes.
20. Security release gate passes.
21. Secrets/authorization/import security pass.
22. Performance gates pass.
23. Long-session/memory checks pass.
24. Observability critical signals pass.
25. Backup/rollback evidence passes where applicable.
26. Exploratory charters reveal no unresolved blocker.
27. All blocker defects are VERIFIED/CLOSED.
28. Residual risks are documented.
29. Final acceptance report is complete.
30. P16 receives exact RC-ready handoff.

---

# 236. P15 PROMPT COMPLETENESS GATE

P15 prompt is structurally complete only if it covers:

1. QA authority;
2. severity/triage;
3. traceability;
4. candidate identity;
5. static/unit/integration;
6. learner E2E;
7. author/admin E2E;
8. browser/device;
9. responsive;
10. accessibility;
11. offline;
12. service worker/cache;
13. migration;
14. performance;
15. security;
16. AI;
17. scenario;
18. writing/research;
19. content;
20. authoring;
21. observability;
22. backup/rollback;
23. failure injection;
24. exploratory;
25. flaky tests;
26. fix/retest loop;
27. acceptance gates;
28. evidence/reporting;
29. residual risk;
30. P16 handoff.

If all are defined:

`P15 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P15 acceptance has PASSed.

---

# 237. FINAL RESPONSE FORMAT

When P15 acceptance completes:

`P15 STATUS: PASS / FAIL / BLOCKED`

`Candidate SHA:`

`Content snapshot:`

`Environment/config:`

`Functional gate: PASS / FAIL`

`Data integrity gate: PASS / FAIL`

`Content gate: PASS / FAIL`

`Offline/Migration gate: PASS / FAIL`

`Security gate: PASS / FAIL`

`Performance gate: PASS / FAIL`

`Accessibility/UX gate: PASS / FAIL`

`Operability/Rollback gate: PASS / FAIL`

`Browser/device matrix: PASS / PARTIAL / FAIL`

`Critical journeys: PASS / FAIL`

`AI regression: PASS / FAIL`

`Scenario regression: PASS / FAIL`

`Authoring regression: PASS / FAIL`

`Open blockers:`

`Open criticals:`

`Known non-blocking limitations:`

`P16 readiness: READY / NOT READY`

`Evidence index:`

End:

**P15 FULL-SYSTEM QA · REGRESSION · ACCEPTANCE COMPLETE**

---

# 238. EXECUTION RULE

When authorized:

`identify exact candidate`

→ `load P1–P14 evidence`

→ `build traceability matrix`

→ `run cheap blocking gates`

→ `run critical smoke`

→ `run learner/admin E2E`

→ `run browser/device/a11y`

→ `run offline/migration`

→ `run AI/scenario/content`

→ `run security`

→ `run performance`

→ `run rollback/restore`

→ `run exploratory/failure injection`

→ `triage/fix/retest`

→ `close blockers`

→ `produce final acceptance report`

→ `handoff exact candidate to P16`.

Do not merge unrelated features during acceptance.

---

# 239. FINAL P15 PRINCIPLE

P15 succeeds only when the evidence answers:

- Does the real learner journey work?
- Does learner state remain correct?
- Can official work be lost or duplicated?
- Does the app survive offline/reload/update?
- Are migrations safe?
- Can AI lie about sources or authority?
- Can scenario state contradict itself?
- Can an unauthorized actor activate content?
- Can malicious content execute?
- Does the app work on supported devices?
- Can keyboard/screen-reader users complete core work?
- Does the candidate stay inside performance gates?
- Can we observe and roll back failure?

A release candidate is not trustworthy because “tests are green”.

It is trustworthy because:

> critical contracts have traceable evidence and no known release-blocking defect remains.

**TEST THE SYSTEM, NOT JUST THE FUNCTIONS.**
**TRACE EVERY CRITICAL CONTRACT.**
**REPRODUCE BEFORE FIXING.**
**RETEST AFTER FIXING.**
**NO KNOWN BLOCKER ENTERS RC FREEZE.**


---

# P15 HARDENING ADDENDUM
## FINAL COMPLETENESS PASS BEFORE P16

This addendum closes the last acceptance-layer edge cases that commonly appear only when a candidate survives repeated fixes, browser drift, intermittent failures, test-infrastructure defects, evidence gaps and release-pressure decisions.

It does not expand P15 into P16.

---

# 312. ACCEPTANCE EVIDENCE FRESHNESS

Acceptance evidence expires semantically when the tested subject changes materially.

Revalidation triggers include:

- candidate SHA changes;
- content snapshot changes;
- runtime config changes;
- dependency lock changes;
- model/provider config changes;
- browser/runtime support changes;
- security mitigation changes.

Do not reuse old PASS because the file name is unchanged.

---

# 313. EVIDENCE SCOPE

Every evidence artifact should make clear:

- what was tested;
- what was not tested;
- which environment;
- which build;
- which snapshot;
- which configuration.

Avoid screenshots/logs with ambiguous provenance.

---

# 314. CROSS-ENVIRONMENT EVIDENCE TRANSFER

Evidence from local/CI/preview may transfer only if the relevant behavior is equivalent.

Examples of non-transferable differences:

- production auth;
- CDN;
- service worker;
- database;
- OAuth callback;
- security headers;
- feature flags;
- environment secrets.

Record transfer assumptions explicitly.

---

# 315. TEST INFRASTRUCTURE VALIDATION

Before trusting acceptance results, validate the test system itself:

- correct target URL;
- correct candidate SHA;
- correct content snapshot;
- correct test account role;
- no stale browser cache;
- no hidden mocks in production-like run.

A test pointed at the wrong build is invalid evidence.

---

# 316. STALE TEST ENVIRONMENT

If a preview/staging environment failed to redeploy:

detect by build/snapshot identity check.

Do not continue acceptance against stale deployment.

---

# 317. TEST DOUBLE / MOCK DISCLOSURE

Each acceptance result should know whether critical dependency was:

`REAL`

`MOCKED`

`SIMULATED`

`DISABLED`.

Do not claim live-provider acceptance from a mock.

---

# 318. MOCK PARITY

Mocks must implement contract behavior, not merely return success.

Examples:

- AI mock returns structured allowed/invalid variants;
- sync mock can return conflict;
- storage mock can fail/quota;
- auth mock can expire.

---

# 319. TEST ACCOUNT PERMISSION PARITY

A test admin with superuser rights cannot prove reviewer/contributor permission boundaries.

Use exact roles.

---

# 320. TEST DATA SENSITIVITY

Synthetic test data should avoid resembling real confidential research/student records unnecessarily.

---

# 321. TEST ARTIFACT SANITIZATION

Screenshots/HAR/logs may contain:

- email;
- token;
- document text;
- internal IDs.

Redact before broad sharing/archival where appropriate.

---

# 322. INTERMITTENT DEFECT ESCALATION

An intermittent blocker remains a blocker.

Do not downgrade because it is hard to reproduce.

Increase instrumentation/repetition.

---

# 323. REPRODUCTION CONFIDENCE

For intermittent issues, record:

- run count;
- failure count;
- environment;
- correlation factors.

Avoid anecdotal “seems fixed”.

---

# 324. SOAK TEST

For long-lived behaviors where risk warrants:

- long writing session;
- repeated route changes;
- AI conversations;
- scenario replay;
- offline/online cycles.

Look for:

- memory growth;
- listener duplication;
- stale state;
- sync drift.

---

# 325. ENDURANCE STATE INTEGRITY

After long session:

mastery/SRS/draft/scenario state should match expected event history.

---

# 326. RECOVERY TEST AFTER BROWSER CRASH

Where feasible:

terminate/reload during:

- autosave;
- pack download;
- scenario;
- assessment;
- migration.

Validate recovery contract.

---

# 327. RECOVERY TEST AFTER DEVICE RESTART

For PWA/offline-critical workflows where practical:

verify persisted state after browser/device restart simulation or representative real-device test.

---

# 328. LOW MEMORY TEST

On constrained mobile/device profile:

app should degrade rather than crash from eager data/media loading.

---

# 329. LOW STORAGE TEST

Verify:

- warning;
- cleanup;
- critical data protection;
- pack degradation/recovery.

---

# 330. HIGH LATENCY TEST

Not just low bandwidth.

Test long RTT affecting:

- submit;
- AI;
- sync;
- media start.

---

# 331. PACKET LOSS / INTERMITTENT NETWORK

Where tooling allows, simulate unstable connection.

Check retry/idempotency.

---

# 332. DNS / ENDPOINT FAILURE

Dependency-specific fallback should work.

---

# 333. CLOCK SKEW TEST

Manipulate client clock where relevant.

Validate no duplicate/invalid due date or official submission loss.

---

# 334. TIMEZONE TEST

At least current supported user timezones/contexts.

SRS/date display remains coherent.

---

# 335. LOCALE NUMBER TEST

Technical decimal values should not be corrupted by UI locale formatting.

---

# 336. UNICODE NORMALIZATION TEST

Equivalent Cyrillic/stress forms should search/compare correctly according to P7/P14 policy.

---

# 337. HOMOGLYPH SECURITY TEST

Sensitive IDs/usernames should not become ambiguous through Unicode confusables if user-controlled.

---

# 338. CONTENT SIZE EXTREMES

Test:

- minimum/empty valid;
- very long valid;
- large source;
- large draft;
- large scenario;
- maximum practical list.

---

# 339. BOUNDARY VALUE TEST

For numeric/state limits:

- zero;
- one;
- max;
- over max;
- negative where invalid.

---

# 340. MALFORMED STATE TEST

Inject malformed:

- learner state;
- SRS;
- scenario session;
- draft metadata.

Recovery must preserve evidence.

---

# 341. DERIVED INDEX CORRUPTION TEST

Delete/corrupt search/link index.

System rebuilds/falls back without canonical loss.

---

# 342. CONTENT SNAPSHOT MISMATCH TEST

App points to unavailable/incompatible snapshot.

Expected safe behavior.

---

# 343. RELEASE ARTIFACT INTEGRITY

Acceptance should verify the artifact intended for RC:

- build hash/identity;
- content manifest;
- dependency lock;
- config reference.

Not merely source tree.

---

# 344. ARTIFACT REBUILD COMPARISON

If rebuilt from same source/toolchain, compare expected reproducible characteristics.

Document unavoidable nondeterministic metadata.

---

# 345. TEST RESULT TAMPER RESISTANCE

Critical acceptance result should be generated/stored in a way that preserves:

- candidate identity;
- timestamp;
- suite outcome.

Do not manually rewrite FAIL to PASS without trace.

---

# 346. MANUAL OVERRIDE RECORD

If a flaky/incorrect automated test is overridden:

record:

- why;
- reviewer;
- evidence;
- replacement validation.

---

# 347. ACCEPTED RISK EXPIRY

A non-blocking risk accepted for RC should have:

- owner;
- follow-up;
- trigger/date if appropriate.

Do not let “accepted risk” become permanent forgotten debt.

---

# 348. DEFECT DEFER CRITERIA

A defect can be deferred only if:

- non-blocking;
- impact understood;
- workaround/mitigation documented if needed;
- P16 release-note/technical-debt handling assigned.

---

# 349. NO SILENT KNOWN-ISSUE SUPPRESSION

Test code must not skip known failing critical path without visible issue reference.

---

# 350. SKIPPED TEST POLICY

Every skipped critical test needs:

- reason;
- issue;
- impact;
- alternative evidence.

---

# 351. QUARANTINED TEST POLICY

Quarantined flaky tests remain visible.

Release acceptance needs alternative evidence if they cover critical contract.

---

# 352. TEST MAINTENANCE DEBT

P15 reports stale/duplicated/brittle tests to P16 if not release blocking.

---

# 353. DEFECT CLUSTERING

Multiple visible defects may share one root cause:

- stale cache;
- duplicate state owner;
- schema mismatch.

Cluster to avoid patching symptoms separately.

---

# 354. ROOT-CAUSE CONFIRMATION

A proposed root cause is confirmed only when:

- evidence supports it;
- fix addresses reproduction;
- regression remains green.

---

# 355. FIX SIDE-EFFECT AUDIT

For high-risk fix:

inspect nearby domains before retest.

Example:

fix offline sync

may affect:

assessment submit;
writing autosave;
scenario persistence.

---

# 356. CHANGE FREEZE DURING FINAL RUN

When final acceptance run begins:

unrelated code/content changes stop.

Only release-blocking fixes enter candidate.

---

# 357. EMERGENCY FIX DURING FREEZE

If blocker found:

- fix minimal scope;
- new candidate identity;
- rerun affected suites + critical gates.

No invisible patch.

---

# 358. CANDIDATE LINEAGE

Maintain:

RC-candidate-1

→ fix

→ RC-candidate-2

with exact SHA/snapshot.

Do not overwrite identity.

---

# 359. EVIDENCE LINEAGE

Acceptance evidence must point to candidate generation.

Evidence from candidate-1 cannot prove candidate-2 for changed scope.

---

# 360. FINAL RUN REPEATABILITY

Critical smoke should pass in at least repeated representative runs sufficient to reveal intermittent startup/state issues.

No arbitrary universal run count; choose based on risk.

---

# 361. SECURITY RECHECK AFTER FUNCTIONAL FIX

If fix touches:

- auth;
- upload;
- rendering;
- API;
- dependency;

rerun relevant security cases.

---

# 362. PERFORMANCE RECHECK AFTER FUNCTIONAL FIX

If fix adds:

- bundle;
- data fetch;
- render loop;
- polling;

rerun relevant performance gates.

---

# 363. ACCESSIBILITY RECHECK AFTER UI FIX

If DOM/component changes:

rerun keyboard/a11y affected journeys.

---

# 364. OFFLINE RECHECK AFTER CACHE/BUILD FIX

If service worker/asset changes:

rerun offline/update.

---

# 365. MIGRATION RECHECK AFTER SCHEMA FIX

Any schema/state change triggers migration matrix.

---

# 366. AI RECHECK AFTER PROMPT/MODEL FIX

Run P10 golden + affected real-provider acceptance.

---

# 367. CONTENT RECHECK AFTER DATA FIX

Run P7/P8/P9 validators/golden sampling.

---

# 368. SCENARIO RECHECK AFTER WORLD/BRANCH FIX

Run branch coverage + golden replay.

---

# 369. AUTHORING RECHECK AFTER GOVERNANCE FIX

Run permission/approval/rollback path.

---

# 370. P15 INCIDENT DURING TEST

If test itself causes data/config damage:

stop;
restore;
investigate test isolation.

Acceptance infrastructure must not be a production risk.

---

# 371. RELEASE NOTE INPUT

P15 supplies P16 with:

- user-visible fixed issues;
- known limitations;
- behavior changes;
- migration/update notes.

P16 owns final release-note assembly.

---

# 372. TECHNICAL DEBT INPUT

P15 sends non-blocking discovered debt to P16:

- stale test;
- duplicate helper;
- compatibility shim;
- low-risk warning;
- obsolete fixture.

Do not hide debt after PASS.

---

# 373. LEGACY PATH OBSERVATION

During acceptance, record which legacy routes/code paths are actually exercised.

P16 uses evidence to retire safely.

---

# 374. FEATURE FLAG OBSERVATION

Record active/inactive flags in candidate.

P16 removes stale flags or freezes intended values.

---

# 375. DEPENDENCY OBSERVATION

Record runtime dependencies actually loaded/used on critical journeys where practical.

P16 uses for cleanup.

---

# 376. CONSOLE CLEANLINESS

Critical journeys should not emit unexplained:

- errors;
- unhandled rejections;
- severe warnings.

Not every harmless third-party warning is blocker, but document.

---

# 377. NETWORK CLEANLINESS

Look for:

- repeated 404;
- duplicate API call;
- unnecessary polling;
- CORS failure;
- mixed content.

---

# 378. SERVICE WORKER CLEANLINESS

No repeated install/update failure loop.

---

# 379. LOG CLEANLINESS

No repeated noisy error hiding real signals.

---

# 380. DEPRECATION WARNING

Framework/runtime deprecation warnings relevant to near-term release should be routed to P16 debt closure.

---

# 381. ACCEPTANCE OF KNOWN LEGACY COMPATIBILITY

If compatibility layer still needed:

P15 documents which test proves it is still needed.

P16 must not delete blindly.

---

# 382. RELEASE-CANDIDATE CONTENT FREEZE INPUT

P15 identifies exact content snapshot accepted.

P16 must freeze this snapshot unless a fix causes retest.

---

# 383. FINAL ACCEPTANCE HASH LIST

Where practical list hashes/IDs for:

- source SHA;
- content manifest;
- lockfile;
- build artifact;
- key generated indexes.

Supports P16 reproducibility.

---

# 384. P15 GOLDEN ACCEPTANCE REGRESSION SET

Maintain compact must-pass set spanning:

- Today;
- lesson;
- SRS;
- listening;
- speaking;
- assessment;
- scenario;
- writing;
- AI;
- authoring;
- offline;
- migration;
- security;
- rollback.

This is not a replacement for full regression.

---

# 385. P15 REVALIDATION TRIGGERS

P15 final acceptance becomes `NEEDS_REVALIDATION` when:

- candidate changes;
- content snapshot changes;
- lockfile changes materially;
- production-like config changes;
- critical browser support changes;
- P16 cleanup modifies runtime behavior.

P16 must send affected changes back for retest.

---

# 386. P15 PROMPT COMPLETENESS GATE — HARDENED

P15 is fully hardened only if it covers:

1. candidate/evidence identity;
2. environment parity;
3. test-infrastructure validation;
4. mock disclosure;
5. defect severity;
6. intermittent defects;
7. soak/recovery;
8. resource pressure;
9. network adversity;
10. clock/timezone/unicode;
11. malformed/corrupt state;
12. artifact integrity;
13. skipped/flaky test policy;
14. accepted-risk policy;
15. root-cause/fix loop;
16. change freeze;
17. candidate lineage;
18. cross-domain rechecks;
19. legacy/debt observation;
20. RC handoff hashes;
21. golden acceptance set;
22. revalidation triggers;
23. P16 handoff.

If all are defined:

`P15 PROMPT STATUS: COMPLETE / HARDENED / READY TO EXECUTE`.

**P15 PROMPT HARDENING COMPLETE**

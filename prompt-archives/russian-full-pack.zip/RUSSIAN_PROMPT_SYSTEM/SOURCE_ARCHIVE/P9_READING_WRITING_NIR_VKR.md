# P9 — READING · WRITING · NOTE-TAKING · НИР · ВКР PRODUCTION CONSTITUTION
## ACADEMIC INPUT → STRUCTURED OUTPUT → RESEARCH COMMUNICATION → DEFENSE

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Primary curriculum targets:

- R10 preparatory reading/writing bridge.
- R11 university operations.
- R14 lecture/note-taking.
- R18 experiment/report bridge.
- R19–R22 research/НИР.
- R23–R26 ВКР, presentation and defense.

Execution mode:

**AUTONOMOUS · SOURCE-BASED · P7/P8-VALIDATED · PRODUCTION-FIRST · ACADEMIC-INTEGRITY-AWARE · EVIDENCE-FIRST · TOKEN-EFFICIENT**

---

# P9 CHANGELOG

- 2026-09-30 — Full deep P9 constitution created.
- 2026-09-30 — Final hardening: source lineage/versioning, multilingual sources, supervisor feedback provenance, draft lifecycle/conflict, AI-assistance trace, meaning-preservation locks, extraction uncertainty and golden research regression.

---

# 0. MISSION

P9 builds the system that turns Russian input into independent academic/research output.

The core journey is:

`READ`

→ `UNDERSTAND`

→ `EXTRACT`

→ `NOTE`

→ `PARAPHRASE`

→ `SUMMARIZE`

→ `ORGANIZE`

→ `WRITE`

→ `PRESENT`

→ `DEFEND`.

The target is not:

“learner can copy Russian academic templates”.

The target is:

> learner can understand technical/academic material, transform it into their own structured Russian, write НИР/ВКР components, present them and respond to questions.

---

# 1. FOUNDATION DEPENDENCIES

P9 consumes:

### P2
- R01–R26 curriculum;
- research progression;
- reading/writing ladder.

### P3
- reading/writing schemas;
- academic functions;
- technical concept IDs;
- provenance;
- content graph.

### P4
- assessment/mastery boundaries;
- writing/speaking rubrics;
- first-attempt integrity;
- performance task evidence.

### P5
- adaptive support;
- skill deficit routing;
- scaffold fading.

### P6
- listening/speaking runtime;
- recording;
- Deep Speaking;
- Q&A evidence.

### P7
- linguistic correctness;
- academic register;
- naturalness;
- accepted variants;
- source authority.

### P8
- academic function core;
- technical terminology;
- technical concepts;
- graph/table/experiment language;
- domain truth.

P9 must not redefine P7/P8 canonical truth silently.

---

# 2. P9 OWNERSHIP

P9 owns:

- reading progression;
- reading task design;
- academic reading strategies;
- technical reading strategies;
- annotation/note-taking pedagogy;
- source extraction;
- paraphrasing;
- summarization;
- synthesis;
- email/formal messages;
- lab/report writing;
- academic paragraphing;
- cohesion;
- research question/problem/objective writing;
- literature synthesis language;
- method description;
- result description;
- discussion;
- limitations;
- conclusion;
- abstract;
- НИР writing/oral production;
- ВКР writing/oral production;
- figures/tables/slides verbalization;
- presentation signposting;
- defense Q&A language;
- revision/editing workflow;
- source-based academic integrity;
- writing performance tasks.

P9 does NOT own:

- canonical technical terminology;
- mastery persistence;
- AI Mentor policy;
- scenario engine;
- editor/admin workflow;
- UI architecture;
- final production release.

---

# 3. NON-GOALS

P9 is not:

- a thesis ghostwriter;
- a citation generator without sources;
- a plagiarism tool;
- a translation-only workflow;
- a template copy system;
- a full research-methodology degree;
- a replacement for supervisor feedback.

P9 teaches language and communication structure.

---

# 4. CENTRAL PRINCIPLE

Every advanced writing task should answer:

1. What is the source/input?
2. What transformation must learner perform?
3. What language function is required?
4. What technical concepts are involved?
5. What evidence proves independent production?
6. What support is allowed?
7. What is prohibited copying?

If those are unclear:

task design is incomplete.

---

# 5. READING IS NOT TRANSLATION

Reading ability includes:

- identify purpose;
- find key idea;
- locate detail;
- infer relation;
- identify definition;
- identify evidence;
- identify method;
- extract terminology;
- distinguish result vs interpretation;
- summarize structure;
- evaluate relevance.

Translation may support comprehension but is not the sole objective.

---

# 6. READING LADDER

Recommended progression:

`R0` sign/label.

`R1` form/menu/table.

`R2` message/notice.

`R3` timetable/instruction.

`R4` email.

`R5` short explanatory text.

`R6` textbook paragraph.

`R7` technical instruction/documentation.

`R8` problem statement.

`R9` lab/manual fragment.

`R10` abstract.

`R11` academic article fragment.

`R12` research-method/results fragment.

`R13` multi-source research reading.

Not every learner must reach all levels immediately.

---

# 7. READING TEXT TYPE METADATA

A reading text should identify where useful:

- type;
- level;
- domain;
- purpose;
- source/provenance;
- technical density;
- expected prior concepts;
- target functions;
- target vocabulary;
- task types.

Do not use word count alone as difficulty.

---

# 8. READING PURPOSES

Different reading modes:

`SCAN`

`SKIM`

`DETAILED`

`STUDY`

`REFERENCE`

`COMPARE_SOURCES`.

Teach learner to choose strategy.

---

# 9. SCANNING

Use for:

- dates;
- room;
- deadline;
- value;
- parameter;
- variable;
- section;
- command.

Assessment should not require full translation.

---

# 10. SKIMMING

Learner identifies:

- topic;
- purpose;
- overall structure;
- likely relevant section.

Useful for textbooks/articles.

---

# 11. DETAILED READING

Learner analyzes:

- relation;
- condition;
- cause;
- method;
- result;
- exception;
- definition.

---

# 12. REFERENCE READING

Technical documentation often requires:

find specific parameter/behavior.

Teach navigation and selective comprehension.

---

# 13. MULTI-SOURCE READING

Advanced learner must compare:

- source A;
- source B;
- agreements;
- differences;
- method;
- result;
- limitation.

This is bridge to literature review.

---

# 14. READING STRUCTURE SIGNALS

Teach recognition of:

- heading;
- definition;
- enumeration;
- example;
- contrast;
- cause;
- result;
- conclusion;
- limitation.

P7 validates linguistic forms.

---

# 15. TECHNICAL DENSITY CONTROL

Technical reading should gradually increase:

- term density;
- nominalization;
- sentence length;
- reference chains;
- embedded clauses;
- formula integration.

Do not jump from simple sentence to dense paper abstract without scaffolding.

---

# 16. GLOSSARY SUPPORT FADING

Support progression:

full glossary

→ selected glossary

→ Russian simple definitions

→ learner-selected lookup

→ independent reading.

P5 may adapt support.

---

# 17. INLINE TRANSLATION POLICY

Vietnamese translation may be available as scaffold.

But advanced reading should not show full line-by-line translation by default.

Avoid creating translation dependence.

---

# 18. ANNOTATION SYSTEM

Learner should be able to mark or conceptually identify:

- unknown word;
- key term;
- definition;
- claim;
- evidence;
- result;
- question;
- important sentence.

Actual UI implementation belongs P13.

P9 defines learning semantics.

---

# 19. NOTE-TAKING MISSION

Note-taking converts listening/reading input into compact structured memory.

It is not transcription.

---

# 20. NOTE-TAKING PROGRESSION

N0:
copy keyword.

N1:
keyword + value.

N2:
short phrase.

N3:
structured bullet list.

N4:
concept relation.

N5:
lecture outline.

N6:
research/source note.

---

# 21. NOTE-TAKING SYMBOLS

Learner may use:

- arrows;
- abbreviations;
- symbols;
- English/code tokens where useful;
- Russian keywords.

Do not require full grammatical sentences in notes.

---

# 22. NOTE-TAKING ABBREVIATIONS

Teach high-value Russian academic/technical abbreviations only when validated.

Learner-created private abbreviations are allowed in personal notes.

Do not confuse them with canonical terminology.

---

# 23. NOTE → RECONSTRUCTION

Important learning loop:

input

→ notes

→ source hidden

→ learner reconstructs explanation.

This tests comprehension better than copying.

---

# 24. SOURCE EXTRACTION

Learner must extract:

- problem;
- objective;
- method;
- data;
- result;
- limitation;
- conclusion.

These become building blocks for research writing.

---

# 25. SOURCE FACT VS AUTHOR INTERPRETATION

Advanced reading should distinguish:

- reported fact/data;
- source author's interpretation;
- learner's interpretation.

Critical for academic integrity.

---

# 26. PARAPHRASING MISSION

Paraphrasing means:

preserve meaning

while changing expression/structure appropriately.

It does not mean:

replace several words with synonyms.

---

# 27. PARAPHRASING LADDER

P0:
replace simple phrase with equivalent.

P1:
change sentence structure.

P2:
combine/split sentences.

P3:
summarize concept in simpler Russian.

P4:
academic paraphrase.

P5:
technical paraphrase preserving exact meaning.

---

# 28. PARAPHRASE VALIDATION

Check:

- meaning preserved;
- technical terms preserved where needed;
- no invented claim;
- no lost condition;
- no reversed causal relation;
- register appropriate.

---

# 29. TECHNICAL TERM PRESERVATION IN PARAPHRASE

Do not force learner to replace canonical technical terms with synonyms.

Good paraphrase may keep core technical terminology while changing structure/explanation.

---

# 30. SUMMARY MISSION

Summary reduces content while preserving central meaning.

Progression:

- one-sentence gist;
- 3-point summary;
- paragraph summary;
- technical summary;
- abstract-like summary.

---

# 31. SUMMARY CONTENT SELECTION

Learner should decide:

keep:
- main purpose;
- key method;
- key result.

omit:
- minor example;
- repetition;
- low-value detail.

Task design must define expected scope.

---

# 32. SUMMARY ≠ COPY

If output copies long source spans:

do not count as independent production.

Assessment may detect high overlap as signal, not automatic misconduct verdict.

---

# 33. SYNTHESIS

Advanced learner combines multiple sources.

Structure:

source A says...

source B differs...

common point...

difference...

own neutral synthesis.

Do not force a conclusion unsupported by sources.

---

# 34. SOURCE ATTRIBUTION

Teach language for:

- according to author/source;
- study shows;
- documentation states;
- results reported by;
- compared with.

P7 validates forms.

---

# 35. ACADEMIC INTEGRITY

P9 must explicitly distinguish:

- quote;
- paraphrase;
- summary;
- synthesis;
- own claim.

Do not encourage unattributed copying.

---

# 36. QUOTATION POLICY

Learner should know:

- quotation is exact;
- preserve wording;
- cite/source according to required style;
- quotations should be used purposefully.

P9 does not prescribe a citation style unless institution/course requires one.

---

# 37. CITATION STYLE BOUNDARY

If Bauman/course requires a specific citation standard:

record it as course/institution-specific.

Do not invent formatting rules.

P9 teaches language of attribution independently from bibliography formatting.

---

# 38. AI & ACADEMIC INTEGRITY BOUNDARY

P10 later governs AI Mentor.

P9 requires that AI assistance not erase learner authorship.

For official writing assessment:

record allowed support.

Do not treat AI-generated full thesis text as learner production.

---

# 39. WRITING LADDER

W0:
handwriting/word.

W1:
sentence.

W2:
short message.

W3:
form.

W4:
email.

W5:
paragraph.

W6:
summary.

W7:
technical explanation.

W8:
lab/report section.

W9:
multi-paragraph report.

W10:
abstract.

W11:
НИР section.

W12:
ВКР section.

W13:
integrated research document.

Handwriting remains separate capability.

---

# 40. SENTENCE-LEVEL WRITING

Core targets:

- correct word order;
- case;
- agreement;
- aspect;
- connector;
- punctuation;
- technical term use.

Do not jump to essay feedback when sentence control is missing.

---

# 41. PARAGRAPH ARCHITECTURE

Teach:

- topic/function;
- development;
- evidence/example;
- transition;
- closing/connection.

Academic paragraph structure need not imitate English five-paragraph essay.

Use Russian academic conventions validated by sources.

---

# 42. COHESION

Teach:

- pronoun/reference;
- lexical repetition when appropriate;
- synonyms carefully;
- connectors;
- thematic progression.

Avoid mechanical connector stuffing.

---

# 43. COHERENCE

A grammatically perfect text can still be incoherent.

Assess:

- logical order;
- relevance;
- relation among claims;
- evidence placement;
- conclusion support.

---

# 44. REGISTER

Writing modes:

- neutral message;
- polite email;
- technical note;
- formal report;
- academic research.

P7 supplies register truth.

---

# 45. EMAIL SYSTEM

Teach email components:

- subject;
- greeting;
- context;
- purpose/request;
- relevant details;
- attachment reference;
- thanks;
- closing.

Use authentic Russian university politeness.

---

# 46. EMAIL SCENARIOS

At minimum:

- ask clarification;
- request meeting;
- submit work;
- report technical issue;
- ask about deadline;
- send revised file.

Avoid overly ceremonial language.

---

# 47. FORM / APPLICATION WRITING

Foundation/prep tasks may include:

- personal data;
- dates;
- address;
- study information.

Do not store sensitive learner data unnecessarily in canonical lesson content.

---

# 48. SHORT TECHNICAL EXPLANATION

Structure:

term/concept

→ purpose

→ how it works

→ simple example.

This bridges P8 into writing.

---

# 49. PROCESS DESCRIPTION

Learner should write:

initial state

→ steps

→ condition

→ output.

Useful for algorithm, setup, experiment.

---

# 50. SYSTEM DESCRIPTION

Structure:

purpose

→ components

→ relations

→ flow

→ result.

---

# 51. COMPARATIVE WRITING

Compare two:

- methods;
- algorithms;
- models;
- systems.

Use explicit criteria.

Do not write “A is better” without criterion/evidence.

---

# 52. ADVANTAGE / LIMITATION WRITING

Teach balanced structure:

advantage

→ context

→ limitation

→ implication.

Avoid absolute claims.

---

# 53. PROBLEM–SOLUTION WRITING

Structure:

problem

→ cause/context

→ proposed solution

→ expected effect

→ limitation.

---

# 54. LAB REPORT ARCHITECTURE

Typical language components:

- objective;
- equipment/setup;
- procedure;
- measurement;
- data;
- calculation;
- result;
- error/uncertainty;
- conclusion.

Actual institutional format must be audited.

---

# 55. LAB REPORT INPUT INTEGRITY

Data/values should come from:

- provided fixture;
- learner experiment;
- validated synthetic dataset.

Do not let model invent “observed” values.

---

# 56. RESULT VS CONCLUSION

Teach difference:

result:
what was obtained.

conclusion:
what it means relative to objective.

Learner should not collapse them.

---

# 57. DISCUSSION

Advanced report/research discussion can include:

- interpretation;
- comparison;
- expected vs actual;
- causes;
- limitations;
- implications.

---

# 58. LIMITATION LANGUAGE

Teach honest language:

- limited by;
- not considered;
- outside scope;
- insufficient data;
- future work.

Do not teach evasive language.

---

# 59. ERROR / UNCERTAINTY WRITING

Use P8/P7 validated terminology.

Distinguish:

measurement error

vs methodological limitation

vs model error.

---

# 60. GRAPH DESCRIPTION

Writing/speaking tasks should identify:

- graph purpose;
- axes;
- key trend;
- important values;
- comparison;
- interpretation.

Do not narrate every point.

---

# 61. TABLE DESCRIPTION

Learner should select meaningful comparisons.

Do not simply read every cell.

---

# 62. FIGURE REFERENCE LANGUAGE

Teach how academic Russian refers to:

- figure;
- table;
- equation;
- section.

Formatting/citation style may be institution-specific.

---

# 63. FORMULA EXPLANATION

Learner should explain:

- variables;
- relation;
- condition;
- implication.

Do not restate symbols only.

---

# 64. ABSTRACT READING

Learner identifies:

- problem/context;
- objective;
- method;
- result;
- conclusion.

---

# 65. ABSTRACT WRITING

A short research abstract should generally cover relevant functions:

- context/problem;
- objective;
- method;
- main result;
- conclusion.

Do not force a rigid template if institutional format differs.

---

# 66. ABSTRACT CONCISION

Teach removal of:

- unnecessary background;
- repeated definitions;
- details not central.

---

# 67. KEYWORDS

If required:

keywords should represent research concepts.

Do not generate arbitrary related words.

Institutional formatting belongs to audited requirements.

---

# 68. RESEARCH TITLE LANGUAGE

Title should be:

- accurate;
- scoped;
- terminology-correct;
- not sensational.

Do not overclaim result in title.

---

# 69. RESEARCH PROBLEM

Learner must distinguish:

topic

from:

problem.

Topic:
area.

Problem:
specific unresolved/target issue in scope.

---

# 70. RELEVANCE / MOTIVATION

Teach evidence-based relevance.

Avoid empty phrases equivalent to:

“this topic is very important today”

without explanation.

---

# 71. RESEARCH OBJECTIVE

Objective should describe intended research outcome.

Not simply:

“study X”

when a more concrete outcome is required.

---

# 72. RESEARCH TASKS

Tasks should operationalize objective.

Avoid duplicate tasks phrased differently.

---

# 73. OBJECT / SUBJECT OF RESEARCH

If Russian academic tradition/course requires these notions:

teach carefully and validate definitions.

Do not force them if not required by actual institutional context.

---

# 74. RESEARCH QUESTION

Teach clear question aligned with:

problem

and objective.

---

# 75. HYPOTHESIS

If methodology uses hypothesis:

teach cautious language.

Do not require hypothesis for every technical project.

---

# 76. SCOPE

Learner should state:

- what is included;
- what is excluded;
- assumptions;
- constraints.

---

# 77. TERMINOLOGY SECTION

If ВКР/НИР needs term definitions:

use P7/P8 canonical terminology.

Do not redefine established technical term incorrectly for convenience.

---

# 78. LITERATURE REVIEW MISSION

Not:

“list authors one by one”.

Goal:

- organize by problem/method/theme;
- compare;
- identify gap/relevance;
- position work.

---

# 79. SOURCE NOTE STRUCTURE

For each source, learner can record:

- reference;
- purpose;
- method;
- key result;
- useful concept;
- limitation;
- relation to own work.

---

# 80. LITERATURE MATRIX

Possible structure:

source

× problem

× method

× data

× result

× limitation

× relevance.

This supports synthesis.

---

# 81. LITERATURE REVIEW LANGUAGE

Functions:

- source reports;
- proposes;
- uses;
- compares;
- obtains;
- differs;
- limitation;
- gap.

P7 validates Russian patterns.

---

# 82. SOURCE COMPARISON

Learner should compare on explicit criteria:

- method;
- data;
- metric;
- result;
- assumption;
- scope.

---

# 83. GAP LANGUAGE

Teach cautious wording.

Do not claim:

“nobody has studied X”

without strong evidence.

Possible safer function:

“within the reviewed sources, X remains insufficiently addressed”.

Actual Russian phrasing validated by P7.

---

# 84. METHOD SECTION

Learner should explain:

- why method selected;
- inputs/data;
- procedure;
- parameters;
- tools;
- evaluation.

Do not copy documentation as method.

---

# 85. METHOD REPRODUCIBILITY

Writing should contain enough information for reader to understand/replicate at appropriate academic level.

Exact standard depends on project.

---

# 86. DATA DESCRIPTION

Include where relevant:

- source;
- size;
- variables/features;
- split;
- preprocessing;
- limitations.

P8 validates domain terms.

---

# 87. SOFTWARE / TOOL DESCRIPTION

Describe only tools relevant to method.

Do not turn method section into product advertisement.

---

# 88. ALGORITHM DESCRIPTION

Options:

- prose;
- pseudocode;
- flowchart;
- formula.

Learner must connect them coherently.

---

# 89. EXPERIMENT DESIGN

Explain:

- objective;
- setup;
- baseline;
- variable;
- controlled factors;
- metric;
- procedure.

Do not invent methodological rigor beyond actual project.

---

# 90. RESULTS SECTION

Results should state:

- what was measured;
- main values/findings;
- relevant table/figure;
- comparison.

Keep interpretation distinct when structure requires.

---

# 91. DISCUSSION SECTION

Discussion may:

- interpret result;
- compare with expectation/source;
- explain difference;
- identify limitation;
- implication.

---

# 92. NEGATIVE / NULL RESULTS

Teach neutral reporting.

Do not force positive success narrative.

---

# 93. LIMITATIONS SECTION

Learner can describe:

- data limitation;
- method limitation;
- scope;
- measurement;
- computational resource;
- generalizability where relevant.

---

# 94. FUTURE WORK

Future work should follow from limitation/result.

Avoid generic filler.

---

# 95. CONCLUSION

Conclusion should answer:

- objective;
- main result;
- contribution;
- limitation/future work if appropriate.

Do not introduce major new evidence.

---

# 96. CONTRIBUTION LANGUAGE

Teach calibrated claims:

- developed;
- implemented;
- proposed;
- evaluated;
- compared;
- demonstrated.

Do not use “novel” unless defensible.

---

# 97. ORIGINALITY CLAIMS

No automatic claim of scientific novelty.

If institution requires novelty section:

language must reflect actual evidence/supervisor requirements.

---

# 98. НИР ARCHITECTURE

P9 should support НИР components:

- topic;
- problem/relevance;
- objective/tasks;
- literature/method;
- data/experiment;
- results;
- conclusion;
- oral presentation;
- Q&A.

Actual formal template must be audited before enforcing formatting.

---

# 99. НИР WRITING PROGRESSION

NIR-W1:
write objective.

NIR-W2:
write tasks.

NIR-W3:
method paragraph.

NIR-W4:
result paragraph.

NIR-W5:
limitation/conclusion.

NIR-W6:
integrated mini-report.

---

# 100. НИР ORAL PROGRESSION

NIR-O1:
30-second topic.

NIR-O2:
1-minute objective/method.

NIR-O3:
3-minute mini report.

NIR-O4:
5-minute report.

NIR-O5:
Q&A.

P6 owns recording runtime.

---

# 101. ВКР ARCHITECTURE

P9 supports:

- title;
- abstract/annotation if required;
- introduction;
- problem;
- objective/tasks;
- review;
- method/system;
- experiment;
- results;
- discussion;
- conclusion;
- bibliography language;
- slides;
- defense.

Formatting requirements must come from actual institution/course evidence.

---

# 102. ВКР IS NOT A TEMPLATE-FILL EXERCISE

Learner must develop:

- logical structure;
- technical explanation;
- evidence;
- argumentation.

Templates are scaffolds only.

---

# 103. ВКР SECTION DEPENDENCIES

Example:

results cannot be written before:

method/data/experiment exist.

Conclusion depends on results.

Abstract should be written/revised after main work.

Planner may reflect these dependencies.

---

# 104. LONG-FORM COHERENCE

For long documents:

track:

- terminology consistency;
- abbreviations;
- variable names;
- chapter references;
- figure numbering;
- repeated definitions;
- claim consistency.

P12 may later expose editor tooling.

---

# 105. TERMINOLOGY CONSISTENCY

Once a technical term is chosen:

use consistent canonical form unless variant is intentional.

P7/P8 owner map controls.

---

# 106. ABBREVIATION CONSISTENCY

First-use expansion where required.

Do not alternate unexplained abbreviations.

---

# 107. VARIABLE / SYMBOL CONSISTENCY

Long writing must keep same variable meaning.

Flag reused symbol with different meaning unless clearly scoped.

---

# 108. CROSS-REFERENCE CONSISTENCY

If text says:

“see Figure 3”

the figure must exist.

Potential automated validator.

---

# 109. FIGURE / TABLE NUMBERING

Formatting depends on institutional rules.

P9 can validate consistency without inventing numbering style.

---

# 110. CAPTION LANGUAGE

Captions should be concise and technically accurate.

Do not use captions as paragraph-length explanation unless required.

---

# 111. PRESENTATION MISSION

Slides are not the thesis pasted into PowerPoint.

Learner must convert document into oral visual narrative.

---

# 112. PRESENTATION STRUCTURE

Typical functional sequence:

- topic;
- problem/relevance;
- objective;
- method/system;
- experiment/data;
- results;
- contribution;
- limitations;
- conclusion.

Actual duration determines depth.

---

# 113. SLIDE TEXT DENSITY

P9 defines pedagogical rule:

slides support speech.

Do not require learner to read paragraphs.

P13 later handles presentation UI if in-app.

---

# 114. PRESENTATION SIGNPOSTING

Teach:

- opening;
- moving to next point;
- referring to figure;
- emphasizing result;
- summarizing;
- closing.

P7 validates Russian forms.

---

# 115. FIGURE ORAL DESCRIPTION

Structure:

what figure shows

→ axes/components

→ key observation

→ meaning.

Do not read every label.

---

# 116. METHOD ORAL EXPLANATION

Learner should explain method more simply than formal written section.

Oral ≠ read written paragraph.

---

# 117. RESULT ORAL EXPLANATION

State:

main finding

→ evidence/value

→ interpretation.

---

# 118. TIME MANAGEMENT

Presentation tasks may include:

3-minute;
5-minute;
7-minute;
10-minute

variants.

Content must scale, not merely speak faster.

---

# 119. DEFENSE Q&A MISSION

Defense language requires:

- understand question;
- clarify;
- answer directly;
- justify;
- cite evidence;
- acknowledge limitation;
- state insufficient data;
- future work.

---

# 120. QUESTION COMPREHENSION

Before answering:

learner may:

- repeat/rephrase question;
- ask clarification.

This is legitimate interaction skill.

---

# 121. DIRECT ANSWER FIRST

Train response structure:

direct answer

→ explanation

→ evidence

→ limitation if needed.

Avoid long preamble that never answers.

---

# 122. JUSTIFICATION

Learner should justify:

- method choice;
- dataset;
- parameter;
- architecture;
- metric;
- controller/model;
- experimental setup.

P8 supplies technical concepts.

---

# 123. CRITICISM RESPONSE

Teach:

- acknowledge valid criticism;
- clarify scope;
- explain decision;
- distinguish limitation from error;
- propose future improvement.

Do not teach combative language.

---

# 124. UNKNOWN ANSWER

Teach honest response:

- not examined;
- outside scope;
- insufficient data;
- requires further analysis.

Do not fabricate.

---

# 125. PARTIAL ANSWER

Learner can answer known part and clearly delimit uncertainty.

This is better than confident invention.

---

# 126. MISUNDERSTOOD QUESTION

Repair:

- ask repeat;
- ask rephrase;
- confirm interpretation.

P6 runtime supports interaction.

---

# 127. UNEXPECTED QUESTION

Question pool should include transfer, not only scripted rehearsal.

P4 defines official assessment policy.

---

# 128. DEFENSE QUESTION CATEGORIES

- definition;
- method;
- parameter;
- comparison;
- result;
- limitation;
- validity;
- implementation;
- future work;
- conceptual challenge.

---

# 129. DEFENSE RUBRIC INPUTS

P9 proposes evidence dimensions:

- response relevance;
- technical accuracy;
- language clarity;
- terminology;
- argumentation;
- limitation awareness;
- interaction repair.

P4 owns scoring/mastery.

---

# 130. READING ASSESSMENT

Reading assessment may test:

- gist;
- detail;
- structure;
- relation;
- terminology;
- inference;
- summary.

Not only translation.

---

# 131. WRITING ASSESSMENT

Separate:

language quality

from:

technical/research content quality

when needed.

Do not hide cause of low score.

---

# 132. PARAPHRASE ASSESSMENT

Check:

- semantic fidelity;
- independence;
- technical term preservation;
- grammar/register.

---

# 133. SUMMARY ASSESSMENT

Check:

- central content;
- concision;
- accuracy;
- organization;
- language.

---

# 134. SOURCE-BASED WRITING ASSESSMENT

Provide source package.

Learner must:

read

→ select

→ synthesize

→ write.

Do not expect factual content not in source unless task says use prior knowledge.

---

# 135. MODEL ANSWER POLICY

Model text may support learning.

Official first attempt:

model hidden unless assessment explicitly open-book.

After submission:

show annotated model/criteria.

Do not let model replace feedback.

---

# 136. MULTIPLE GOOD ANSWERS

Academic writing often has many valid outputs.

Assessment should use rubric, not exact string.

P4 owns evaluator.

---

# 137. AI EVALUATION BOUNDARY

If AI evaluates writing:

its result is a signal unless canonical policy defines validated authority.

P10 later defines AI feedback guardrails.

Do not let model rewrite score history directly.

---

# 138. REVISION CYCLE

Writing learning should include:

draft

→ feedback

→ revise

→ compare

→ final.

First draft remains evidence when required.

---

# 139. REVISION TYPES

Classify feedback:

- content;
- organization;
- grammar;
- vocabulary;
- register;
- cohesion;
- technical accuracy;
- citation/integrity.

Learner should know what changed.

---

# 140. ERROR CORRECTION PRIORITY

Do not mark every error equally.

Prioritize:

meaning-changing

→ task-blocking

→ recurring grammar

→ register

→ style.

---

# 141. FEEDBACK OVERLOAD

For early writers:

limit correction focus.

Do not return a page covered in every minor issue if learning objective is narrower.

P5 may adapt.

---

# 142. SELF-EDIT CHECKLIST

Teach learner to inspect:

- objective answered?
- terminology consistent?
- cases/agreement?
- verbs/aspect?
- connectors?
- paragraph logic?
- result/conclusion distinction?
- unsupported claim?
- source attribution?
- figures referenced?

---

# 143. PEER/TEACHER REVIEW LANGUAGE

If collaborative feature exists:

teach constructive Russian for:

- clarification;
- suggestion;
- disagreement;
- correction.

P11/P12 may implement workflow later.

---

# 144. SPELLING/GRAMMAR TOOLS

External spellcheck may assist.

Do not treat tool output as linguistic authority.

P7 remains truth policy.

---

# 145. AUTO-CORRECT POLICY

Do not silently auto-correct learner writing in assessment.

Suggestions may be shown after/according to task policy.

---

# 146. TRANSLATION TOOL POLICY

If translation tool is available:

official assessment must specify whether allowed.

Practice may use it strategically.

Do not make translation dependence invisible.

---

# 147. DICTIONARY POLICY

Dictionary lookup may be allowed in certain writing/reading tasks.

Record support mode if it affects evidence.

---

# 148. OPEN-BOOK VS CLOSED-SUPPORT

Task metadata should distinguish:

`CLOSED_SUPPORT`

`GLOSSARY_ALLOWED`

`DICTIONARY_ALLOWED`

`SOURCE_ALLOWED`

`FULL_OPEN_BOOK`.

This makes evidence interpretable.

---

# 149. SOURCE PACK CONTRACT

Source-based tasks should package references by ID.

Do not embed duplicate full technical truth unnecessarily.

---

# 150. PROVENANCE IN WRITING TASKS

Source materials require provenance.

Generated synthetic source should be labeled.

Do not fabricate article authors/citations as if real.

---

# 151. SYNTHETIC ACADEMIC TEXT

Allowed for pedagogy if labeled:

`PEDAGOGICAL_SYNTHETIC`.

Do not present synthetic text as real publication.

---

# 152. REAL PUBLICATION EXCERPTS

Use copyright-safe excerpts/references.

Do not copy large protected texts.

Tasks may paraphrase source ideas with citation.

---

# 153. DOCUMENTATION EXCERPTS

Prefer concise relevant portions or links/references.

Offline pack may contain allowed/local material.

---

# 154. INSTITUTIONAL TEMPLATE AUDIT

Before enforcing НИР/ВКР formal structure:

audit actual Bauman/faculty/course requirements.

If unavailable:

mark:

`GENERIC_ACADEMIC_STRUCTURE`

not:

`BAUMAN_OFFICIAL`.

---

# 155. OFFICIAL FORMAT BOUNDARY

P9 separates:

LANGUAGE/PEDAGOGICAL STRUCTURE

from:

OFFICIAL DOCUMENT FORMATTING.

Official formatting requires evidence.

---

# 156. DATE-SENSITIVE REQUIREMENTS

Institutional templates/rules may change.

Record version/date.

Do not bake one year's rule permanently into curriculum.

---

# 157. ACADEMIC STYLE NATURALNESS

Avoid:

- excessive passive;
- excessive noun chains;
- empty bureaucratic phrases;
- translated English academic clichés.

P7 validates style.

---

# 158. CONCISION

Teach elimination of:

- tautology;
- duplicated claim;
- filler;
- overlong introductory phrases.

Russian academic writing can be formal without being bloated.

---

# 159. PRECISION

Prefer:

specific technical noun/verb

over vague:

“thing”, “do”, “good”, “bad”.

But keep level appropriate.

---

# 160. CLAIM–EVIDENCE LINK

Advanced paragraph should connect:

claim

→ evidence

→ interpretation.

Do not allow unsupported conclusion.

---

# 161. CAUSAL CLAIM SAFETY

Learner should distinguish:

correlation

from:

causation

when technical content requires.

P8 validates domain concept.

---

# 162. UNCERTAINTY LANGUAGE

Teach calibrated uncertainty:

- approximately;
- likely;
- may;
- within scope;
- insufficient evidence.

Avoid both overconfidence and excessive hedging.

---

# 163. CONTRADICTION CHECK

Long documents should be checked for conflicting:

- objective;
- parameter;
- result;
- term;
- number.

Potential automated validator.

---

# 164. NUMERIC CONSISTENCY

If abstract says 92% and result section says 89%:

flag.

If multiple experiments exist:

context must disambiguate.

---

# 165. UNIT CONSISTENCY

Check same quantity uses consistent/compatible units or explicitly converts.

---

# 166. VERSION CONSISTENCY

Software/version named in methods should match screenshots/code/results where relevant.

---

# 167. DATASET CONSISTENCY

Dataset name/split/size should remain consistent across document unless revised explicitly.

---

# 168. TERMINOLOGY CONSISTENCY VALIDATOR

Use P8 canonical IDs to detect inconsistent synonyms/translation where one canonical term is expected.

Allow intentional variant with context.

---

# 169. ABBREVIATION VALIDATOR

Flag:

- unexplained abbreviation;
- multiple expansions;
- inconsistent capitalization;
- reused abbreviation with different meaning.

---

# 170. CITATION CONSISTENCY VALIDATOR

If bibliography/reference tooling exists:

flag missing cited source or unused reference where appropriate.

Do not invent bibliography.

---

# 171. FIGURE/TABLE REFERENCE VALIDATOR

Flag:

- referenced but missing;
- present but never referenced when policy expects;
- duplicate numbering;
- caption mismatch.

---

# 172. STRUCTURE VALIDATOR

For task-specific document:

check required functional sections.

Do not enforce universal chapter structure.

---

# 173. ABSTRACT CONSISTENCY VALIDATOR

Abstract should not claim result absent from main text.

Useful for final ВКР audit.

---

# 174. CONCLUSION CONSISTENCY VALIDATOR

Conclusion should align with stated objective/tasks/results.

Flag new unsupported technical claims.

---

# 175. WRITING QUALITY METRICS

Possible internal metrics:

- task coverage;
- terminology consistency;
- unsupported-claim flags;
- cohesion flags;
- language error categories.

Do not create pseudo-scientific single “academic quality 94%”.

---

# 176. PLAGIARISM BOUNDARY

P9 may teach originality and overlap awareness.

Do not claim plagiarism detection without a real comparison corpus/tool.

Text similarity is only a signal.

---

# 177. SOURCE OVERLAP SIGNAL

If task source is known:

system may detect excessive verbatim overlap.

Do not automatically accuse learner.

Use as feedback/review signal.

---

# 178. AUTHORSHIP EVIDENCE

For assessed writing:

keep draft/attempt history according to P4.

Revision history can demonstrate development.

---

# 179. NIR/VKR PERSONAL DATA

Do not put sensitive personal/research data into generic training content.

User-provided thesis material follows project privacy rules.

---

# 180. CONFIDENTIAL RESEARCH DATA

If learner uses confidential material:

do not upload/share externally through AI without appropriate authorization.

P10/P14 later govern connectors/security.

P9 defines caution.

---

# 181. READING SUPPORT FOR FORMULAS

Textbook/article reading must teach how prose refers to equations.

Learner should connect:

“from equation (3) follows...”

to actual equation.

---

# 182. READING SUPPORT FOR FIGURES

Teach:

figure mention

→ locate figure

→ identify message

→ return to text interpretation.

---

# 183. READING SUPPORT FOR REFERENCES

Learner should recognize citation/reference markers without needing full bibliography parsing initially.

---

# 184. PAPER STRUCTURE RECOGNITION

Advanced reading:

- abstract;
- introduction;
- method;
- results;
- discussion;
- conclusion.

Actual structure may vary.

Do not force every paper into IMRaD.

---

# 185. ABSTRACT TRIAGE

Learner can decide:

relevant / maybe / not relevant

based on:

problem;
method;
result.

Useful for literature search.

---

# 186. SOURCE QUALITY AWARENESS

Teach basic distinction among:

- textbook;
- peer-reviewed article;
- documentation;
- blog/forum;
- generated text.

P7/P10 govern authority.

Do not turn course into full information-science curriculum.

---

# 187. RESEARCH READING VOCABULARY

P9 uses P8 academic verb/noun banks.

Avoid creating duplicate research vocabulary owner.

---

# 188. WRITING TEMPLATE OWNERSHIP

Templates are derived/support artifacts.

Canonical truth remains functions/concepts.

Do not create “template source” that conflicts with grammar/terminology.

---

# 189. TEMPLATE VARIATION

Offer more than one valid structure where discipline allows.

Prevent learner believing one exact sentence is mandatory.

---

# 190. SCAFFOLD FADING — WRITING

Stage:

full model

→ annotated model

→ outline

→ prompts

→ checklist

→ independent.

P5 adapts pace.

---

# 191. SCAFFOLD FADING — READING

Stage:

glossary + translation support

→ glossary

→ Russian definitions

→ independent lookup

→ independent reading.

---

# 192. SCAFFOLD FADING — DEFENSE

Stage:

script

→ cue cards

→ slide keywords

→ no script

→ unexpected questions.

---

# 193. SCRIPT POLICY

Reading a memorized script can be useful early.

But final defense competence requires spontaneous response.

Do not claim full speaking mastery from script reading.

---

# 194. SLIDE NOTES

Speaker notes may support rehearsal.

Official performance task can restrict notes.

Record support mode.

---

# 195. QUESTION BANK FOR DEFENSE

Question pool should map to:

- slide;
- concept;
- method;
- result;
- limitation.

Avoid generic random questions disconnected from learner's topic.

For generic course simulations, use validated synthetic project context.

---

# 196. SYNTHETIC RESEARCH PROJECTS

P9 may use synthetic projects to train research language.

Each should have:

- clear topic;
- data;
- method;
- result;
- limitations;
- internal consistency.

Label synthetic.

---

# 197. PROJECT DIFFICULTY

Synthetic projects can vary:

- simple data analysis;
- software system;
- control experiment;
- AI model;
- database design.

Use P8 domain content.

---

# 198. CROSS-DOMAIN RESEARCH

Advanced task may combine:

data + control;

AI + database;

software + experiment.

Only when prerequisites are met.

---

# 199. R10 WRITING BRIDGE

R10:

- short answers;
- simple definitions;
- small problem explanation;
- note-taking.

Do not demand research prose.

---

# 200. R11 UNIVERSITY WRITING

R11:

- email;
- task clarification;
- schedule/deadline;
- short progress message.

---

# 201. R14 NOTE-TAKING

R14:

- lecture notes;
- key concept extraction;
- reconstruction.

---

# 202. R18 REPORT BRIDGE

R18:

- objective;
- procedure;
- data;
- graph;
- result;
- short conclusion.

---

# 203. R19 RESEARCH FOUNDATION WRITING

R19:

- topic;
- problem;
- relevance;
- objective;
- tasks;
- scope.

---

# 204. R20 LITERATURE/METHOD WRITING

R20:

- source notes;
- comparison;
- method description;
- evidence;
- limitation.

---

# 205. R21 SEMINAR PRODUCTION

R21:

- position;
- evidence;
- technical question;
- response;
- critique.

Mostly oral + short written preparation.

---

# 206. R22 НИР INTEGRATION

R22:

- integrated written mini-report;
- presentation;
- Q&A;
- revision.

---

# 207. R23 ВКР WRITING

R23:

- introduction;
- method/system;
- experiment;
- results;
- discussion;
- conclusion;
- abstract.

Actual formal layout depends on audited requirements.

---

# 208. R24 FIGURES/TABLES/PRESENTATION

R24:

- figure description;
- table interpretation;
- slide signposting;
- architecture/algorithm diagram;
- timed presentation.

---

# 209. R25 DEFENSE Q&A

R25:

- question comprehension;
- direct answer;
- justification;
- criticism;
- limitations;
- unknown answer;
- future work.

---

# 210. R26 CAPSTONE

Integrated:

read source

→ note

→ write technical/research response

→ present

→ defend.

Uses unseen but level-appropriate scenario.

---

# 211. PERFORMANCE TASK — READING TO WRITING

Input:
short technical text.

Output:
structured summary.

Evidence:
semantic fidelity + language + organization.

---

# 212. PERFORMANCE TASK — MULTI-SOURCE

Input:
2–3 short sources.

Output:
comparison/synthesis.

Must identify source attribution.

---

# 213. PERFORMANCE TASK — LAB REPORT

Input:
experiment fixture.

Output:
objective + method + result + conclusion.

---

# 214. PERFORMANCE TASK — NIR

Input:
research scenario/data.

Output:
mini НИР + presentation.

---

# 215. PERFORMANCE TASK — VKR DEFENSE

Input:
project package.

Output:
slides/outline + presentation + Q&A.

---

# 216. RUBRIC ARCHITECTURE

P9 proposes rubric dimensions but P4 owns scoring.

Reading:
- comprehension;
- extraction;
- inference.

Writing:
- task completion;
- organization;
- grammar;
- lexical accuracy;
- cohesion;
- register;
- technical accuracy.

Research:
- objective-method-result alignment;
- evidence;
- limitations;
- source integrity.

Defense:
- question comprehension;
- relevance;
- technical accuracy;
- language;
- argumentation;
- repair.

---

# 217. RUBRIC DESCRIPTORS

Descriptors should be observable.

Avoid vague:

“excellent Russian”.

Use:

“states main result and supports it with the provided evidence”.

---

# 218. TECHNICAL ERROR VS LANGUAGE ERROR

Feedback must distinguish:

- wrong Russian;
- wrong technical concept;
- unsupported claim;
- structural issue.

Learner needs correct remediation route.

---

# 219. FIRST ATTEMPT

Official writing/presentation first attempt remains preserved under P4.

Revision is new evidence, not overwrite.

---

# 220. MODEL FEEDBACK

If AI later provides feedback:

P10 constraints apply.

P9 task/rubric remains canonical.

---

# 221. OFFLINE WRITING

Core writing tasks should function offline.

Draft storage must be durable according to platform/state contract.

P14 later hardens storage.

---

# 222. DRAFT RECOVERY

Unexpected reload/navigation should not lose long writing where platform supports autosave.

Do not equate autosave with submit.

---

# 223. AUTOSAVE STATE

Separate:

`DRAFT_SAVED`

from:

`SUBMITTED`.

Rendering/reload must not submit automatically.

---

# 224. VERSION HISTORY

For substantial research writing, version history can be useful.

Do not require full Git-like history for every sentence exercise.

---

# 225. EXPORT

If learner exports report/draft:

content export is user artifact.

P12/P14 later own workflow/file security.

P9 defines semantic completeness.

---

# 226. IMPORT

Imported writing must not become canonical lesson content.

Keep learner artifact separate.

---

# 227. LONG-TEXT PERFORMANCE

Large research drafts may be heavy.

UI must not rerender entire document unnecessarily.

P13/P14 later optimize.

P9 should avoid schema that requires full duplicate text in many places.

---

# 228. SEARCH WITHIN DRAFT

Potential useful capability for long work.

P13/P12 decide implementation.

P9 defines no dependency on it.

---

# 229. REFERENCE MANAGER INTEGRATION

Optional future capability.

P9 does not require external reference manager.

If added, connector/tool owns external data.

---

# 230. SOURCE TRACEABILITY

Every source-derived writing exercise should retain source IDs.

This allows:

- feedback;
- attribution;
- evidence.

---

# 231. FACTUAL GROUNDING IN SOURCE-BASED TASKS

If task says “use provided sources”:

evaluation must not penalize learner for omitting facts not in source.

Do not silently fill gaps with model knowledge in official feedback.

---

# 232. OUTSIDE-KNOWLEDGE TASKS

If prior/domain knowledge is allowed:

state explicitly.

This keeps assessment interpretable.

---

# 233. SOURCE CONFLICT TASKS

Advanced task may present conflicting sources.

Learner should:

identify disagreement

not automatically choose one.

---

# 234. CLAIM ATTRIBUTION

Teach:

“source A reports...”

instead of presenting contested claim as own fact.

---

# 235. EVIDENCE QUALITY LANGUAGE

Advanced learner can describe:

- limited sample;
- preliminary result;
- stronger/weaker evidence.

Do not create fake statistical authority.

---

# 236. WRITING SECURITY

Sanitize learner text before rendering.

Do not execute HTML/script.

P14 owns security hardening.

---

# 237. MARKDOWN SUPPORT

If writing editor supports Markdown:

code/math blocks must remain distinct from prose.

Do not let auto-correction alter code.

---

# 238. FORMULA ENTRY

If math input supported:

learner should be able to reference formulas in prose.

P13/P12 decide editor implementation.

---

# 239. CYRILLIC INPUT

Writing experience must support Russian keyboard/input naturally.

P13 may add input help.

P9 must not require transliteration as primary writing method.

---

# 240. HANDWRITING BRIDGE

Handwriting may support early Cyrillic.

Research writing is keyboard-centric unless task specifically trains handwritten notes.

Keep capabilities separate.

---

# 241. SPELLING FEEDBACK

Separate spelling from grammar/meaning.

Do not fail technical argument solely for one typo unless task is spelling-focused.

Rubric handles severity.

---

# 242. PUNCTUATION FEEDBACK

Advanced writing includes Russian punctuation.

P7 validates rules.

P9 teaches and assesses according to level.

---

# 243. STYLE FEEDBACK

Style suggestions must be distinguished from correctness.

Do not present one stylistic preference as only valid Russian.

---

# 244. REGISTER FEEDBACK

Flag when text is:

too colloquial

or

unnecessarily bureaucratic

for academic context.

---

# 245. REPETITION FEEDBACK

Technical writing may intentionally repeat term for precision.

Do not force synonym replacement mechanically.

---

# 246. PRONOUN REFERENCE

Check ambiguous pronouns in dense technical text.

Sometimes repeating noun is clearer.

---

# 247. CONNECTOR OVERUSE

Flag mechanical use:

firstly/secondly/therefore

in every sentence.

Cohesion is not connector count.

---

# 248. LONG SENTENCE CONTROL

Teach splitting overly complex sentences.

Do not equate long sentence with academic quality.

---

# 249. NOMINALIZATION CONTROL

Use when natural.

Do not turn every verb into noun phrase.

---

# 250. PASSIVE CONTROL

Use passive when functionally appropriate.

Avoid blanket “academic = passive”.

---

# 251. READER ORIENTATION

Long texts should signal:

- purpose;
- section focus;
- transition;
- conclusion.

---

# 252. SECTION OPENING

Teach concise opening that states section purpose.

Avoid repetitive “in this section we will... ” if not needed.

---

# 253. SECTION CLOSING

Summarize key result or transition where helpful.

Do not duplicate entire section.

---

# 254. CROSS-SECTION FLOW

Problem

→ method

→ result

→ discussion

should remain logically connected.

---

# 255. OBJECTIVE-TASK-RESULT TRACEABILITY

Create matrix:

research objective

↔ tasks

↔ method

↔ results

↔ conclusion.

Flag orphan task or result.

---

# 256. CLAIM-EVIDENCE MATRIX

For major claims:

record supporting:

- result;
- source;
- figure;
- experiment.

Useful for final QA.

---

# 257. LIMITATION-IMPACT MATRIX

Limitation

→ what it affects

→ whether conclusion still valid.

This supports honest defense.

---

# 258. DEFENSE TRACEABILITY

Question about:

method

should link to method section/evidence.

This supports scenario generation P11.

---

# 259. P9 CONTENT GRAPH

Add/ensure graph relations:

reading `supports` objective;

source `supports` writing task;

writing task `uses` academic function;

NIR section `requires` technical concepts;

defense question `tests` concept/claim;

figure `supports` result.

Use P3 graph conventions.

---

# 260. P9 SEARCH / INDEX

Derived indexes may support:

- academic function;
- writing pattern;
- report section;
- source type;
- defense question.

No second canonical truth.

---

# 261. P9 AUTHORING REQUIREMENTS

P12 later needs authoring fields for:

- source;
- task purpose;
- support mode;
- rubric;
- model policy;
- provenance;
- expected concepts;
- accepted output type.

P9 defines semantics.

---

# 262. P9 VALIDATORS

Potential automated validators:

- missing objective;
- source missing;
- rubric missing;
- unsupported technical concept ID;
- figure/table broken reference;
- abbreviation inconsistency;
- terminology inconsistency;
- numeric mismatch;
- abstract/result mismatch;
- conclusion/objective mismatch;
- duplicate template;
- model answer exposed in exam mode.

---

# 263. GOLDEN WRITING FIXTURES

Create representative known-good and known-bad examples for:

- email;
- paragraph;
- summary;
- technical explanation;
- lab report;
- abstract;
- method;
- result;
- conclusion;
- defense response.

Do not use learner private work as fixture without authorization.

---

# 264. WRITING VALIDATOR LIMITS

Automated validator cannot prove:

- originality;
- research quality;
- scientific novelty;
- factual truth outside known sources.

State limitations explicitly.

---

# 265. PEDAGOGICAL QA — READING

Sample tasks across:

- survival;
- university;
- technical;
- research.

Check:

target is comprehension, not hidden grammar quiz.

---

# 266. PEDAGOGICAL QA — WRITING

Check:

- objective;
- scaffold;
- independent production;
- feedback;
- revision;
- transfer.

---

# 267. PEDAGOGICAL QA — NIR

Check:

learner can produce integrated research narrative.

Not just fill blanks.

---

# 268. PEDAGOGICAL QA — VKR

Check:

writing

+ presentation

+ Q&A

are connected to one coherent project context.

---

# 269. INTEGRATION QA — P6

Presentation/defense tasks must:

record/speak correctly;

preserve first attempt;

handle mic unsupported fallback.

---

# 270. INTEGRATION QA — P4

Writing submit:

creates one attempt;

model answer not pre-revealed;

revision separate.

---

# 271. INTEGRATION QA — P5

Adaptive system can recommend:

reading remediation;

writing revision;

defense practice

without changing canonical task.

---

# 272. INTEGRATION QA — P7

Academic register/correctness stays within validated policy.

---

# 273. INTEGRATION QA — P8

Technical terms/concepts stay consistent.

No local redefinition.

---

# 274. PERFORMANCE QA

Long source/draft should not freeze browser.

P14 later hardens.

P9 records representative size baseline.

---

# 275. OFFLINE QA

Core source package + draft + submit flow should work offline according to platform contract.

External references may have offline fallback/metadata.

---

# 276. ACCESSIBILITY QA INPUTS

P9 content should provide:

- headings;
- semantic lists;
- text alternatives for meaningful figures;
- table headers;
- descriptive labels.

P13 implements final UI.

---

# 277. RISK REGISTER

Track:

- template overdependence;
- copied model answer;
- unsupported research claim;
- terminology inconsistency;
- source provenance gap;
- assessment ambiguity;
- technical truth drift;
- official-template assumptions;
- long-draft data loss;
- AI authorship confusion;
- plagiarism false positive.

---

# 278. BLOCKER EXAMPLES

BLOCKER:

- official writing assessment exposes full answer before first attempt;
- long draft can be silently lost;
- НИР/VKR template claimed official without evidence and used for scoring;
- canonical technical terms conflict with P8;
- source-based task includes fabricated citation as real;
- learner state overwrites first draft/attempt;
- assessment cannot distinguish multiple valid research answers.

---

# 279. CRITICAL EXAMPLES

CRITICAL:

- course trains copy/paste rather than production;
- summaries reward verbatim copying;
- AI-generated thesis text counted as learner mastery;
- method/result/conclusion terminology systematically wrong;
- defense Q&A entirely scripted;
- source attribution absent in research writing.

---

# 280. PILOT

Before full P9 migration, pilot:

### Pilot A
R11 academic email.

### Pilot B
R18 lab report.

### Pilot C
R22 НИР mini-report + presentation.

### Pilot D
R25 defense Q&A.

This tests short/long writing + speaking integration.

---

# 281. PILOT ACCEPTANCE

Pilot passes if:

- source/task/rubric linked;
- drafts durable;
- first attempt preserved;
- technical terminology valid;
- model support policy works;
- revision works;
- speaking evidence works;
- no duplicate owner;
- offline behavior defined.

---

# 282. MIGRATION ORDER

Recommended:

1. Reading taxonomy.
2. Note-taking.
3. Email/form writing.
4. Summary/paraphrase.
5. Technical explanation.
6. Lab/report writing.
7. Research foundation.
8. Literature/method.
9. НИР.
10. ВКР writing.
11. Slides/presentation.
12. Defense Q&A.
13. Integrated capstone.

---

# 283. BATCH RULE

Each batch:

baseline

→ define objective

→ source/provenance

→ task + scaffold

→ rubric

→ model policy

→ integrate canonical terminology

→ runtime

→ assessment

→ regression

→ evidence.

---

# 284. NO MASS TEMPLATE GENERATION

Do not generate 500 academic templates before pilot.

Better:

small validated function bank

+ reusable slots

+ production tasks.

---

# 285. SEMANTIC DIFF FOR P9

Report changes in:

- writing function;
- source;
- task;
- rubric;
- model;
- terminology;
- research structure;
- official-format claims.

Raw JSON diff insufficient.

---

# 286. BACKWARD COMPATIBILITY

Existing R19–R26 IDs/routes remain resolvable.

New units/micro-lessons map beneath them.

Learner history preserved.

---

# 287. OFFICIAL FORMAT CHANGE

If real Bauman requirements change:

update versioned institutional layer.

Do not rewrite general language curriculum unnecessarily.

---

# 288. REQUIRED DELIVERABLES — CORE

Create/maintain:

`subjects/russian/docs/p9/RUSSIAN_P9_EXECUTIVE_SUMMARY.md`

`RUSSIAN_READING_PROGRESSION.md`

`RUSSIAN_NOTE_TAKING_FRAMEWORK.md`

`RUSSIAN_PARAPHRASE_SUMMARY_SYNTHESIS_FRAMEWORK.md`

`RUSSIAN_WRITING_PROGRESSION.md`

`RUSSIAN_ACADEMIC_INTEGRITY_POLICY.md`

`RUSSIAN_SOURCE_BASED_WRITING_CONTRACT.md`

`RUSSIAN_WRITING_RUBRIC_MATRIX.md`.

---

# 289. REQUIRED DELIVERABLES — RESEARCH

Create/maintain:

`RUSSIAN_RESEARCH_WRITING_FRAMEWORK.md`

`RUSSIAN_LITERATURE_REVIEW_FRAMEWORK.md`

`RUSSIAN_METHOD_RESULT_DISCUSSION_FRAMEWORK.md`

`RUSSIAN_NIR_PRODUCTION_FRAMEWORK.md`

`RUSSIAN_VKR_PRODUCTION_FRAMEWORK.md`

`RUSSIAN_PRESENTATION_LANGUAGE_FRAMEWORK.md`

`RUSSIAN_DEFENSE_QA_FRAMEWORK.md`

`RUSSIAN_RESEARCH_TRACEABILITY_MATRIX.md`.

---

# 290. REQUIRED DELIVERABLES — QA

Create:

`RUSSIAN_P9_OFFICIAL_REQUIREMENTS_EVIDENCE.md`

`RUSSIAN_P9_VALIDATION_REPORT.md`

`RUSSIAN_P9_RISK_REGISTER.json`

`RUSSIAN_P9_EVIDENCE_INDEX.md`

`RUSSIAN_P10_INPUT_CONTRACT.md`.

Do not create ceremonial empty docs.

---

# 291. TEST MATRIX

Static/schema:

- IDs;
- source refs;
- rubric refs;
- terminology refs;
- model policy;
- support mode.

Content:

- source fidelity;
- technical accuracy;
- academic register;
- section consistency.

Runtime:

- read;
- annotate/note if supported;
- draft;
- autosave;
- submit;
- feedback;
- revise;
- reload.

Speaking:

- present;
- Q&A;
- fallback.

State:

- first attempt;
- draft vs submit;
- revision history.

Offline:

- source/draft durability.

---

# 292. BROWSER SAMPLE

Representative:

- R11 email;
- R14 notes;
- R18 report;
- R22 НИР;
- R23 ВКР;
- R24 figure/presentation;
- R25 defense.

Test desktop/mobile representative layouts where editing behavior differs.

P13 later owns full UX.

---

# 293. P9 FAIL CONDITIONS

P9 FAIL if:

- reading = translation only;
- note-taking = transcription only;
- paraphrasing = synonym replacement;
- summary rewards copying;
- source attribution absent;
- model answer visible before official first attempt;
- long writing has no durable draft behavior where required;
- technical terms diverge from P8;
- НИР/VKR structure claimed official without evidence;
- learner can pass research writing by filling fixed template;
- presentation = reading thesis paragraph;
- defense Q&A entirely scripted;
- AI-generated full text counts as learner production;
- conclusion introduces unsupported results;
- abstract contradicts main work;
- official writing score collapses all criteria into opaque number.

---

# 294. P9 PASS CONDITIONS

P9 PASS when:

1. Reading progression exists.
2. Reading tasks measure comprehension beyond translation.
3. Note-taking progression exists.
4. Note→reconstruction works.
5. Paraphrase framework preserves meaning.
6. Summary framework selects central content.
7. Multi-source synthesis exists.
8. Source attribution/integrity policy exists.
9. Email/university writing works.
10. Technical explanation writing works.
11. Lab/report writing works.
12. Result vs conclusion distinction is taught.
13. Literature review synthesis exists.
14. Method writing exists.
15. Results/discussion/limitations exist.
16. НИР integrated production exists.
17. ВКР writing progression exists.
18. Presentation language exists.
19. Figure/table oral explanation exists.
20. Defense Q&A is unscripted-capable.
21. Unknown/uncertain answer language exists.
22. Rubrics align P4.
23. Technical terms align P8.
24. Language/register align P7.
25. Speaking runtime aligns P6.
26. Adaptive scaffolding aligns P5.
27. Draft/submit states are distinct.
28. First attempt preserved.
29. Source-based tasks are grounded.
30. P10 receives stable AI-assistance boundaries.

---

# 295. P10 HANDOFF CONTRACT

P9 supplies P10:

- reading tasks;
- writing tasks;
- source packs;
- rubric criteria;
- model-answer policies;
- allowed support modes;
- academic integrity rules;
- research traceability;
- defense tasks.

P10 may add:

- explanation;
- coaching;
- temporary examples;
- feedback;
- roleplay.

P10 must not:

- fabricate sources;
- write learner's official thesis as canonical learner evidence;
- change technical truth;
- change rubric/mastery owner;
- reveal hidden model answer in official first attempt.

---

# 296. FINAL RESPONSE FORMAT

When P9 implementation completes:

`P9 STATUS: PASS / FAIL / BLOCKED`

`Base SHA:`

`Head SHA:`

`Reading progression: PASS / FAIL`

`Note-taking: PASS / FAIL`

`Paraphrase/summarization: PASS / FAIL`

`Source-based writing: PASS / FAIL`

`Academic integrity: PASS / FAIL`

`Technical writing: PASS / FAIL`

`Lab/report: PASS / FAIL`

`Literature review: PASS / FAIL`

`НИР: PASS / FAIL`

`ВКР: PASS / FAIL`

`Presentation: PASS / FAIL`

`Defense Q&A: PASS / FAIL`

`Official requirements evidence: VERIFIED / PARTIAL / GENERIC ONLY`

`P7 linguistic alignment: PASS / FAIL`

`P8 technical alignment: PASS / FAIL`

`P4 assessment alignment: PASS / FAIL`

`P6 speaking integration: PASS / FAIL`

`State/draft safety: PASS / FAIL`

`Offline behavior: PASS / FAIL`

`P10 readiness: READY / NOT READY`

`PR:`

`Merged SHA:`

`Production: UNCHANGED unless explicitly authorized`

End:

**P9 READING · WRITING · НИР · ВКР PRODUCTION COMPLETE**

---

# 297. EXECUTION RULE

When authorized:

`inspect current reading/writing/research content`

→ `reuse P7/P8 validated truth`

→ `audit official requirements evidence`

→ `baseline tasks`

→ `pilot`

→ `build reading/note/writing progression`

→ `build source-based transformations`

→ `integrate NIR/VKR`

→ `integrate presentation/defense`

→ `align P4 rubrics`

→ `test state/draft`

→ `run transfer tasks`

→ `document evidence`

→ `open PR`.

Do not generate a thesis template farm.

---

# 298. P9 FINAL PRINCIPLE

The goal is not:

> “learner can produce text that looks academic.”

The goal is:

> “learner can transform validated technical information into accurate, structured, independent Russian academic communication.”

For every advanced task ask:

- What did the learner read/hear?
- What did they understand?
- What did they select?
- What did they transform?
- What did they write/say independently?
- Which source supports the claim?
- Is technical meaning preserved?
- Is uncertainty represented honestly?
- Can they defend the result without reading a script?

If not:

the system is not research-ready.

**READ FOR MEANING.**
**WRITE FROM EVIDENCE.**
**PARAPHRASE WITHOUT DISTORTION.**
**PRESENT WITHOUT SCRIPT DEPENDENCE.**
**DEFEND WITHOUT FABRICATION.**


---

# P9 HARDENING ADDENDUM
## FINAL COMPLETENESS PASS BEFORE P10

This addendum closes the remaining edge cases that commonly appear only when real research documents, sources, revisions, supervisors and AI assistance enter the workflow.

It does not expand P9 into P10.

---

# 299. SOURCE VERSIONING

A research source may have:

- publication version;
- preprint;
- revised edition;
- software documentation version;
- standard version;
- course handout revision.

Where version affects meaning:

record it.

Do not silently mix claims from different versions as if identical.

---

# 300. SOURCE IDENTITY

A source record should distinguish:

- title;
- author/organization;
- publication;
- year/date when known;
- stable identifier/URL/DOI when applicable;
- version;
- source type.

Do not identify a source only by display title if duplicates are possible.

---

# 301. SOURCE CLAIM LINEAGE

For source-based writing, important claims should be traceable:

`SOURCE`

→ `EXTRACTED CLAIM`

→ `LEARNER NOTE`

→ `PARAPHRASE/SYNTHESIS`

→ `WRITING SECTION`.

This is especially valuable for НИР/ВКР.

It helps detect distortion and unsupported claims.

---

# 302. CLAIM IDENTITY

A claim is not the same as a source.

One source can support multiple claims.

One claim can be supported by multiple sources.

Do not store “source = claim”.

---

# 303. CLAIM STATUS

Possible internal claim statuses:

`SOURCE_REPORTED`

`LEARNER_INTERPRETATION`

`DERIVED_FROM_DATA`

`HYPOTHESIS`

`CONCLUSION`

`UNVERIFIED`.

This supports academic integrity.

---

# 304. SOURCE CONFLICT HANDLING

If two sources disagree:

learner should be able to represent:

- source A reports X;
- source B reports Y;
- methods/context differ;
- evidence is inconclusive.

Do not force one source to “win” unless task/evidence supports it.

---

# 305. SOURCE QUALITY METADATA

Optional educational metadata:

- textbook;
- peer-reviewed paper;
- official documentation;
- standard;
- institutional source;
- vendor documentation;
- blog;
- forum;
- generated synthetic.

Do not reduce source quality to a single numeric score.

---

# 306. DATE-SENSITIVE SOURCES

For fast-changing technical topics:

record date/version relevance.

A 10-year-old source may still be useful for theory but obsolete for current API behavior.

Do not conflate age with invalidity.

---

# 307. MULTILINGUAL SOURCES

Research may include:

- Russian;
- English;
- Vietnamese;
- other languages.

P9 must define whether task goal is:

- reading Russian;
- synthesizing multilingual sources into Russian;
- translating;
- technical research writing.

Do not silently penalize learner for source language choice if task permits it.

---

# 308. MULTILINGUAL TERMINOLOGY ALIGNMENT

When sources use multiple languages:

technical concept IDs from P8 should anchor terminology.

This prevents:

English term A

→ Russian term B in one section

→ different Russian term C elsewhere

without reason.

---

# 309. TRANSLATED SOURCE CLAIMS

If learner translates/paraphrases a non-Russian source into Russian:

preserve claim meaning.

Do not cite Russian wording as if it appeared verbatim in source.

---

# 310. QUOTE LANGUAGE LABEL

If quotation is translated:

distinguish:

original quote

from:

learner/official translation.

Formatting details depend on institutional requirements.

---

# 311. REFERENCE DUPLICATION

Detect duplicate sources entered as:

- DOI;
- URL;
- slightly different title;
- translated title.

Do not create two bibliography identities for one source.

---

# 312. SOURCE RETRACTION / CORRECTION

If source is corrected/retracted/superseded and system knows:

flag for review.

Do not silently continue teaching claim as strong evidence.

---

# 313. OFFLINE SOURCE SNAPSHOT BOUNDARY

Offline learning pack may store permitted excerpts/metadata.

Do not store entire copyrighted publication merely for convenience.

Use concise educational source packages.

---

# 314. SOURCE ACCESS FAILURE

If source link becomes unavailable:

task should remain understandable if local excerpt/metadata is sufficient.

Do not make core assessment depend on live external page.

---

# 315. RESEARCH NOTE PROVENANCE

A learner note should optionally retain:

- source ID;
- page/section/location;
- timestamp;
- note type.

This is learner artifact metadata, not canonical content.

---

# 316. NOTE TYPE

Possible:

`QUOTE`

`PARAPHRASE`

`SUMMARY`

`IDEA`

`QUESTION`

`DATA`

`METHOD`

`RESULT`

`LIMITATION`.

This helps avoid accidental plagiarism.

---

# 317. QUOTE → PARAPHRASE TRANSITION

Teaching sequence:

exact quote

→ identify meaning

→ hide quote

→ paraphrase

→ compare for semantic fidelity.

Do not paraphrase by thesaurus substitution.

---

# 318. SOURCE-TO-DRAFT TRACEABILITY

For advanced writing, learner should be able to inspect:

which notes/sources informed a paragraph.

Actual UI may be implemented later.

P9 defines the semantic contract.

---

# 319. SUPERVISOR FEEDBACK PROVENANCE

If supervisor/teacher feedback is imported:

store as feedback source distinct from:

AI feedback

and:

learner text.

Do not let AI rewrite supervisor comment silently.

---

# 320. FEEDBACK AUTHORITY

Possible feedback classes:

`TEACHER/SUPERVISOR`

`CANONICAL_RULE`

`AI_SUGGESTION`

`PEER`

`SELF_CHECK`.

Learner should be able to distinguish them.

---

# 321. CONFLICTING FEEDBACK

If AI suggestion conflicts with canonical rule or supervisor instruction:

canonical/institutional authority wins according to scope.

P10 must respect this.

---

# 322. DOCUMENT LIFECYCLE

Long-form research document states may include:

`OUTLINE`

`DRAFT`

`REVISED`

`SUBMITTED`

`REVIEWED`

`FINAL_FOR_STAGE`

`ARCHIVED`.

Do not interpret “FINAL” as immutable forever across academic lifecycle.

---

# 323. SECTION LIFECYCLE

A document can contain sections at different maturity.

Example:

method = stable

results = draft.

Avoid document-wide status hiding section reality.

---

# 324. DRAFT CONFLICT

If same draft is edited on multiple devices/sessions in future sync:

do not silently overwrite.

P14 later hardens sync/storage.

P9 defines:

conflict must preserve both versions until resolved.

---

# 325. AUTOSAVE CONFLICT

Autosave cannot overwrite a newer submitted/reviewed version without explicit policy.

---

# 326. SUBMISSION SNAPSHOT

Official submission should reference an immutable snapshot or content revision.

Later edits must not rewrite historical submitted evidence.

P4 owns official attempt identity.

---

# 327. FEEDBACK TARGETING

Feedback should attach to:

- document;
- section;
- paragraph;
- sentence;
- span;
- concept;

as appropriate.

Do not store all feedback as unstructured global comment if finer link is required.

---

# 328. FEEDBACK STALENESS

After learner edits text:

old span-level feedback may no longer apply.

Mark:

`RESOLVED`

`STALE`

`STILL_APPLICABLE`

rather than blindly repositioning it.

---

# 329. CHANGE TRACKING

For advanced research writing, semantic change tracking may be useful:

- inserted;
- deleted;
- rewritten;
- moved.

Do not require full word-level tracking for basic exercises.

---

# 330. REVISION INTENT

Learner may mark revision goal:

- grammar;
- structure;
- technical correctness;
- concision;
- source integration;
- supervisor request.

This improves targeted feedback.

---

# 331. WRITING SUPPORT DISCLOSURE

Official assessed/research output may need metadata indicating allowed support:

- no AI;
- spellcheck only;
- dictionary;
- AI language feedback;
- AI brainstorming;
- unrestricted practice.

Actual academic policy must come from institution/user context.

Do not invent policy.

---

# 332. AI-ASSISTED REVISION TRACE

If AI rewrites learner text:

do not automatically replace original.

Show:

original

→ suggestion

→ learner acceptance/edit

where product design supports it.

P10 owns AI interaction behavior.

---

# 333. LEARNER AUTHORSHIP PRESERVATION

The final submitted learner text should represent learner decisions.

AI suggestion acceptance should be explicit for substantial rewrites.

Do not silently transform whole document.

---

# 334. LANGUAGE CORRECTION VS CONTENT REWRITE

A correction request may mean:

- grammar fix;
- style improvement;
- technical correction;
- restructuring;
- content generation.

The system should distinguish these scopes.

P10 must not interpret “fix grammar” as “rewrite argument”.

---

# 335. PRESERVE TECHNICAL MEANING DURING LANGUAGE EDIT

Any language correction on technical text must preserve:

- variable;
- direction of effect;
- condition;
- numerical value;
- unit;
- algorithm step;
- result.

If uncertain:

flag rather than rewrite.

---

# 336. NUMERIC EDIT LOCK

AI/automatic language tools should not casually modify:

- values;
- percentages;
- dates;
- equation numbers;
- version numbers;
- citations.

Changes require explicit evidence.

---

# 337. FORMULA EDIT LOCK

Language correction must not alter formula semantics.

Math editing is separate capability.

---

# 338. CODE EDIT LOCK

Language correction must not modify code tokens unless user explicitly requests code changes.

---

# 339. CITATION EDIT LOCK

Language correction must not invent or replace citation identifiers.

---

# 340. CLAIM STRENGTH PRESERVATION

Editing must preserve modality:

“may indicate”

must not become:

“proves”.

“approximately”

must not become exact claim.

This is a critical research-language guardrail.

---

# 341. NEGATION PRESERVATION

Editing must not accidentally remove/add negation.

Create regression fixtures for technical sentences where negation changes meaning.

---

# 342. CONDITION PRESERVATION

Editing must preserve:

if/when/under condition/except.

Technical meaning often depends on conditions.

---

# 343. COMPARISON DIRECTION PRESERVATION

“higher than”

must not become:

“lower than”.

Include in golden writing fixtures.

---

# 344. REFERENCE RESOLUTION

Pronouns like:

“this method”

“this result”

should have clear antecedent in long text.

Flag ambiguity.

---

# 345. TABLE/FIGURE SOURCE

If a figure/table comes from external source:

track provenance/citation needs.

If generated from learner data:

track data origin.

Do not treat all figures as learner-created.

---

# 346. DERIVED FIGURE

A figure generated from learner data should link to:

data

→ transformation

→ figure.

This supports reproducibility.

---

# 347. RESULT REPRODUCIBILITY

If result can be recomputed:

retain inputs/analysis reference where practical.

P9 does not require full computational notebook architecture.

But claims should be traceable.

---

# 348. DOCUMENT EXPORT ENCODING

Export must preserve:

- Cyrillic;
- stress marks if intentionally used;
- formulas;
- tables;
- references;
- code.

Avoid encoding corruption.

P14 later hardens file/export engineering.

---

# 349. COPY/PASTE NORMALIZATION

Pasted Russian text may contain:

- non-breaking spaces;
- smart quotes;
- strange Unicode;
- combining accents.

Normalize safely without changing linguistic meaning.

---

# 350. PDF/DOC SOURCE EXTRACTION BOUNDARY

If source comes from PDF/DOC:

extracted text may be imperfect.

Do not treat extraction errors as source language errors.

Mark uncertain extraction.

Actual file processing belongs to tooling, not linguistic truth.

---

# 351. OCR BOUNDARY

OCR output is candidate text.

It requires validation before canonical use.

Do not silently correct source quote from uncertain OCR and then claim exact quotation.

---

# 352. EQUATION EXTRACTION BOUNDARY

Equation text extracted from documents needs separate validation.

Do not infer missing symbols casually.

---

# 353. TABLE EXTRACTION BOUNDARY

Tables extracted from documents can lose row/column relation.

Do not generate conclusions until structure is validated.

---

# 354. P9 GOLDEN RESEARCH REGRESSION SET

Create known-good fixtures covering:

- source extraction;
- paraphrase fidelity;
- summary;
- multi-source synthesis;
- technical paragraph;
- lab report;
- abstract;
- method;
- result;
- discussion;
- limitation;
- conclusion;
- citation attribution;
- numeric consistency;
- defense answer;
- unknown-answer response;
- AI-assisted revision boundary.

---

# 355. GOLDEN ERROR FIXTURES

Include examples with:

- source distortion;
- invented citation;
- overclaim;
- wrong number;
- reversed comparison;
- wrong limitation;
- conclusion unsupported;
- copied source text;
- ambiguous reference;
- AI rewrite changing technical meaning.

---

# 356. P9 REVALIDATION TRIGGERS

Revalidate relevant slice when:

- institutional requirements change;
- P7 academic style rule changes;
- P8 terminology changes;
- source package changes;
- rubric changes;
- AI assistance policy changes;
- long-form editor/storage behavior changes.

Do not rerun entire P9 for isolated typo correction.

---

# 357. P9 PROMPT COMPLETENESS GATE

P9 prompt is structurally complete only if it covers:

1. reading progression;
2. reading strategies;
3. note-taking;
4. source extraction;
5. paraphrase;
6. summary;
7. synthesis;
8. multilingual sources;
9. source lineage;
10. attribution;
11. academic integrity;
12. email/formal writing;
13. technical writing;
14. lab/report;
15. literature review;
16. method;
17. results;
18. discussion;
19. limitations;
20. conclusion;
21. abstract;
22. НИР;
23. ВКР;
24. slides/presentation;
25. defense Q&A;
26. revision/feedback;
27. draft/submission lifecycle;
28. AI-assistance boundary;
29. technical-meaning preservation;
30. source/figure/table/formula traceability;
31. validators;
32. golden regression;
33. official-requirements boundary;
34. P10 handoff.

If all are defined:

`P9 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P9 work has already PASSed.

---

# 358. P9 → P10 HARD HANDOFF

P10 receives:

- content/read/write task IDs;
- source-pack contract;
- academic integrity policy;
- support modes;
- rubric criteria;
- feedback classes;
- draft/revision semantics;
- model-answer policy;
- technical-meaning preservation rules;
- claim/source lineage;
- AI-assistance disclosure requirements.

P10 must not weaken these contracts.

If AI needs to violate a P9 boundary to perform a feature:

the feature must be redesigned or explicitly authorized with a higher-level contract change.

**P9 PROMPT HARDENING COMPLETE**

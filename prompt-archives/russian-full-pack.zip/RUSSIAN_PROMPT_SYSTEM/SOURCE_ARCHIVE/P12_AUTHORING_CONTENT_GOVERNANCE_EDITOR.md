# P12 — AUTHORING · CONTENT GOVERNANCE · EDITOR WORKFLOW CONSTITUTION
## NO-CODE CONTENT OPERATIONS · SCHEMA-AWARE EDITING · REVIEW · PROVENANCE · PREVIEW · IMPACT · ROLLBACK

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Execution mode:

**AUTONOMOUS · NO-CODE-FIRST · CANONICAL-OWNER-AWARE · SCHEMA-AWARE · REVIEWABLE · AUDITABLE · ROLLBACK-SAFE · LARGE-DATA-READY · TOKEN-EFFICIENT**

---

# P12 CHANGELOG

- 2026-09-30 — Full deep P12 constitution created.
- 2026-09-30 — Final hardening: reviewer conflict/quorum, permission drift, content freeze, emergency patching, source-of-truth drift, audit integrity, import quarantine, agent/API authoring and snapshot reproducibility.

---

# 0. MISSION

P12 builds the sustainable maintenance layer for the Russian learning system.

Its goal is:

> allow future content to be created, enriched, corrected, reviewed, previewed, migrated and activated without routine code surgery and without breaking canonical ownership.

P12 turns content maintenance from:

“edit random JSON/code manually”

into:

`DRAFT`
→ `VALIDATE`
→ `REVIEW`
→ `PREVIEW`
→ `IMPACT ANALYSIS`
→ `APPROVE`
→ `ACTIVATE`
→ `MONITOR`
→ `ROLLBACK/DEPRECATE`.

---

# 1. P12 DEPENDENCIES

P12 consumes:

### P0
- change classes;
- evidence;
- rollback;
- merge/release rules.

### P1
- actual files/owners/routes;
- generated vs source data.

### P2
- curriculum structure;
- lesson/module/unit semantics.

### P3
- schemas;
- canonical owner registry;
- stable IDs;
- graph relations;
- migrations.

### P4
- assessment/mast ery boundaries;
- first-attempt integrity;
- official scoring data.

### P5
- personalization metadata;
- planner ownership.

### P6
- media/audio/speaking content contracts.

### P7
- linguistic authority;
- provenance;
- validation;
- generated candidate lifecycle.

### P8
- technical concept/domain semantics.

### P9
- source-based writing/research semantics.

### P10
- AI authoring candidate rules;
- AI permissions.

### P11
- scenario/state/role/world authoring model.

P12 must not invent alternate content semantics.

---

# 2. P12 OWNERSHIP

P12 owns:

- authoring workflow;
- content lifecycle;
- author roles/permissions;
- schema-aware editor semantics;
- draft storage;
- review queue;
- validation orchestration;
- provenance entry;
- source attachment/reference workflow;
- content diff;
- semantic diff;
- impact analysis;
- dependency visualization semantics;
- preview/sandbox;
- staged activation;
- bulk import/export;
- duplicate detection workflow;
- merge/split/deprecate workflow;
- alias/migration authoring;
- concurrent editing/conflict resolution;
- audit log;
- rollback/restore content workflow;
- emergency disable;
- authoring AI integration;
- editor search/filter;
- content health/governance dashboards semantics.

P12 does NOT own:

- linguistic truth itself;
- technical truth;
- learner mastery;
- SRS;
- scenario runtime;
- AI provider;
- learner-facing navigation;
- production deployment.

---

# 3. CENTRAL RULE

> **NO AUTHORING ACTION MAY BYPASS CANONICAL OWNERSHIP.**

The editor must know:

- entity type;
- canonical owner;
- schema;
- references;
- downstream impact;
- validation requirements;
- activation rules.

No generic “edit any JSON” textbox as primary workflow.

---

# 4. NO-CODE-FIRST

Routine content operations should not require editing application code:

- add vocab;
- add phrase;
- edit grammar explanation;
- add lesson unit;
- add listening item;
- add speaking task;
- add dialogue;
- add scenario;
- add technical concept;
- add assessment item;
- deprecate outdated item.

Code changes remain necessary only for:

- new entity behavior;
- new schema capability;
- engine feature;
- migration logic not representable declaratively.

---

# 5. AUTHORING ≠ RUNTIME STATE

Editor operates on content/config.

It must never directly edit:

- learner mastery;
- attempt history;
- SRS queues;
- official scores;

unless a separate authorized admin state-repair tool exists.

Keep content administration distinct from learner data administration.

---

# 6. CONTENT LIFECYCLE

Recommended lifecycle:

`DRAFT`

`READY_FOR_VALIDATION`

`VALIDATION_FAILED`

`READY_FOR_REVIEW`

`CHANGES_REQUESTED`

`APPROVED`

`STAGED`

`ACTIVE`

`DEPRECATED`

`RETIRED`

`BLOCKED`.

Not every entity needs every intermediate status in storage.

But semantic lifecycle must exist.

---

# 7. DRAFT

Draft may be incomplete.

It can:

- fail schema partially;
- reference candidate entities;
- contain notes.

Draft cannot appear in production learner path by default.

---

# 8. READY_FOR_VALIDATION

Minimum fields present.

Automated validators can run.

---

# 9. VALIDATION_FAILED

Findings attached.

Author can repair.

Do not silently auto-activate after validator pass.

---

# 10. READY_FOR_REVIEW

Structural + automated checks pass.

Human/curated/domain review required according to risk.

---

# 11. APPROVED

Approved means content passed required reviewers.

It still may require preview/build/staging before ACTIVE.

---

# 12. STAGED

Staged content available to:

- preview;
- test;
- QA;
- internal users.

No official learner exposure unless feature/staging policy explicitly allows.

---

# 13. ACTIVE

Canonical production-eligible content.

Activation must be atomic enough to avoid half-updated dependency state.

---

# 14. DEPRECATED

No new recommendation/use by default.

Existing references/history remain resolvable.

---

# 15. RETIRED

Removed from active runtime package when safe.

Historical alias/state references remain supported as required.

---

# 16. BLOCKED

Known unsafe/invalid content.

Should not activate.

---

# 17. ENTITY RISK TIERS

Use P7/P10 concepts to classify:

`LOW`

`MEDIUM`

`HIGH`

`CRITICAL`.

Examples:

LOW:
description typo.

HIGH:
technical definition.

CRITICAL:
assessment answer key / canonical grammar rule / state-sensitive ID change.

Review requirements scale with risk.

---

# 18. ROLE MODEL

Potential authoring roles:

`VIEWER`

`CONTRIBUTOR`

`EDITOR`

`REVIEWER_LINGUISTIC`

`REVIEWER_DOMAIN`

`ASSESSMENT_REVIEWER`

`APPROVER`

`ADMIN`.

Exact roles depend on project needs.

Do not give all users ADMIN.

---

# 19. LEAST PRIVILEGE

Contributor can draft.

Reviewer can review assigned scope.

Approver activates according to policy.

No role should gain unrelated production/system permissions.

---

# 20. ROLE SCOPE

Permissions may be limited by:

- entity type;
- domain;
- stage;
- action;
- environment.

Example:

technical reviewer can review Control terms

without editing mastery or deploy config.

---

# 21. SELF-APPROVAL POLICY

High-risk content should not be both authored and final-approved by same actor/process unless explicitly justified.

AI-generated candidate cannot self-approve.

---

# 22. AUTOMATION APPROVAL BOUNDARY

Trusted deterministic validator may auto-approve only low-risk mechanical changes if governance permits.

Examples:

whitespace normalization.

Not:

stress;
translation;
answer key;
technical definition.

---

# 23. AUTHOR IDENTITY

Every meaningful change should record:

- actor;
- time;
- action;
- entity;
- revision.

Do not need personally identifying data beyond project identity needs.

---

# 24. AUDIT LOG

Audit log records:

- create;
- edit;
- validate;
- review;
- approve;
- activate;
- deprecate;
- rollback;
- import;
- bulk action.

Audit log is append-oriented.

Do not rewrite history casually.

---

# 25. CONTENT REVISION

Each canonical entity should support revision semantics.

Minor field edit:

same ID + revision.

Semantic identity change:

new entity/sense/ID as required by P3.

---

# 26. REVISION COMMENT

Meaningful change should include concise reason:

- typo;
- linguistic correction;
- technical update;
- source update;
- scenario branch change;
- assessment repair.

Avoid meaningless “update”.

---

# 27. DIFF

Editor should show field-level diff.

For rich text:

text diff.

For arrays/relations:

added/removed refs.

For state graph:

nodes/edges changed.

---

# 28. SEMANTIC DIFF

Raw diff is insufficient for high-risk changes.

Semantic categories:

- meaning;
- stress;
- grammar;
- terminology;
- answer key;
- objective;
- prerequisite;
- scenario topology;
- world fact;
- media;
- provenance;
- status.

---

# 29. IMPACT ANALYSIS

Before approval/activation, show dependents:

entity

→ lessons

→ tasks

→ assessments

→ scenarios

→ indexes

→ packs

→ learner state identity if relevant.

---

# 30. IMPACT SEVERITY

Classify:

`LOCAL`

`MULTI-LESSON`

`STAGE-WIDE`

`ASSESSMENT-AFFECTING`

`STATE-AFFECTING`

`ARCHITECTURAL`.

Review gate scales accordingly.

---

# 31. DEPENDENCY GRAPH

P12 editor consumes P3 graph.

Do not maintain a second manually curated dependency map.

---

# 32. UNKNOWN DEPENDENCY

If dependency graph incomplete:

do not claim “safe change”.

Mark impact uncertainty.

---

# 33. CONTENT LOCK

During high-risk review/activation:

entity may be locked against conflicting edits.

Avoid permanent pessimistic locking for normal authoring.

---

# 34. OPTIMISTIC CONCURRENCY

Default editor can use:

revision number / ETag equivalent.

On save conflict:

do not overwrite newer revision silently.

---

# 35. CONFLICT DETECTION

If base revision changed:

show:

- your draft;
- latest;
- diff.

Require merge/rebase decision.

---

# 36. FIELD-LEVEL MERGE

Safe when edits touch independent fields.

Do not auto-merge semantic conflicts.

---

# 37. ARRAY MERGE

References/tags may merge if non-conflicting.

Ordered curriculum arrays require special care.

---

# 38. RICH TEXT MERGE

Do not blindly auto-merge overlapping text edits.

---

# 39. SCENARIO GRAPH MERGE

State-machine changes require graph-aware conflict handling.

Node IDs stable.

Conflicting edge changes require review.

---

# 40. AUTOSAVE

Draft editor may autosave.

Autosave:

does not mean approved;
does not activate.

---

# 41. DRAFT RECOVERY

Browser reload/crash should recover draft where practical.

Do not overwrite canonical active content until explicit save/submit.

---

# 42. LOCAL DRAFT VS SERVER/REPO DRAFT

If architecture supports both:

define owner/sync.

Avoid two divergent draft truths.

---

# 43. DRAFT EXPIRY

Do not delete old draft silently if it contains meaningful work.

Archive or allow cleanup policy.

---

# 44. EDITOR FORM GENERATION

Editor UI should be schema-driven where possible:

- field type;
- enum;
- required;
- refs;
- validation;
- help text.

Avoid hand-coding separate editor for every simple entity.

---

# 45. CUSTOM EDITOR COMPONENTS

Use custom editor for complex types:

- stress;
- morphology;
- state graph;
- rubric;
- formula;
- scenario world;
- media timeline.

Schema-driven base + specialized components.

---

# 46. REQUIRED FIELD

Show required clearly.

Do not require meaningless empty data.

---

# 47. OPTIONAL FIELD

Hide advanced optional fields progressively.

Avoid overwhelming author with 80 fields.

---

# 48. FIELD HELP

Help text should explain semantic meaning.

Not just repeat field name.

---

# 49. ENUM

Use canonical enum source.

Do not duplicate enum lists in UI code.

---

# 50. REFERENCE PICKER

Entity references should use:

search by ID/title/lemma/domain.

Store ID, not title.

---

# 51. REFERENCE VALIDATION

Cannot save/activate dangling required ref.

Draft may temporarily allow unresolved candidate refs with explicit status.

---

# 52. REFERENCE PREVIEW

Author can inspect referenced entity without losing draft.

---

# 53. BACKLINKS

Show where entity is used.

Critical for safe edits.

---

# 54. CIRCULAR DEPENDENCY

Prevent invalid prerequisite cycles.

Graph validator.

---

# 55. ORDERING

For ordered curriculum:

drag/order editor may be used.

Persist stable IDs + explicit sequence.

Do not derive identity from array index.

---

# 56. BULK REORDER

Show impact before activation.

---

# 57. VOCAB EDITOR

Fields may include:

- lemma;
- stress;
- POS;
- senses;
- morphology;
- government;
- aspect;
- collocations;
- domain;
- level;
- provenance.

Do not expose raw 50-field JSON as primary UX if structured editor is feasible.

---

# 58. SENSE EDITOR

Each sense:

- stable sense ID;
- meaning;
- domain;
- register;
- examples.

Moving meaning between senses may affect references.

Impact analysis required.

---

# 59. STRESS EDITOR

Must prevent impossible stress position.

High-risk change requires P7 validation.

---

# 60. MORPHOLOGY EDITOR

Structured fields.

Do not allow free-form paradigm text as only source.

---

# 61. GOVERNMENT EDITOR

Structured pattern builder.

Head + preposition + case + sense.

---

# 62. ASPECT EDITOR

Link reciprocal relation with validation.

Do not force pair.

---

# 63. COLLOCATION EDITOR

Reference lexical IDs.

Add register/domain.

---

# 64. GRAMMAR EDITOR

Fields:

- function;
- form;
- patterns;
- examples;
- contrasts;
- prerequisites;
- common errors;
- tasks.

---

# 65. PHONETIC EDITOR

Fields:

- target;
- contrast;
- stress/audio;
- error patterns;
- examples.

P6 media refs.

---

# 66. LESSON/MODULE EDITOR

Structured hierarchy:

module

→ unit

→ micro-lesson

→ objective

→ refs.

Do not embed copied vocab/grammar.

---

# 67. OBJECTIVE EDITOR

Objective maps:

verb;
skill;
concept;
criterion;
context.

Assessment alignment visible.

---

# 68. ACTIVITY EDITOR

Support:

input;
practice;
retrieval;
production;
assessment;
remediation.

---

# 69. LISTENING EDITOR

Fields:

- audio;
- transcript;
- reveal policy;
- target concepts;
- tasks;
- source.

P6 contracts.

---

# 70. SPEAKING EDITOR

Fields:

- prompt;
- mode;
- support;
- target;
- evaluation config;
- evidence.

No direct mastery config.

---

# 71. DIALOGUE EDITOR

Structured:

roles;
turn pool;
functions;
variations;
repair.

P11 scenario may reference it.

---

# 72. DEEP SPEAKING EDITOR

Fields:

- task;
- prep;
- duration;
- rubric ref;
- follow-up;
- concepts.

---

# 73. READING EDITOR

Fields:

- source/provenance;
- text;
- type;
- objective;
- vocabulary;
- tasks;
- support.

P9 rules.

---

# 74. WRITING EDITOR

Fields:

- source pack;
- prompt;
- audience;
- register;
- support mode;
- rubric;
- model policy;
- provenance.

---

# 75. TECHNICAL CONCEPT EDITOR

Fields:

- domain;
- term refs;
- definitions;
- relations;
- examples;
- source;
- version/standard.

P8 validation.

---

# 76. ASSESSMENT EDITOR

High-risk editor.

Fields:

- objective;
- competency;
- skill;
- prompt;
- response schema;
- scoring;
- accepted variants;
- reveal policy;
- provenance.

Activation requires strongest review.

---

# 77. ANSWER KEY SEPARATION

Answer keys may be stored/permissioned separately from learner-visible prompt.

Editor preview must test leakage policy.

---

# 78. RUBRIC EDITOR

Criteria + observable descriptors.

No learner scores.

---

# 79. REMEDIATION EDITOR

Trigger

→ repair

→ retrieval

→ exit check.

---

# 80. SCENARIO EDITOR

Consumes P11 model:

- role;
- world;
- states;
- transitions;
- events;
- branches;
- success;
- fallback.

Must provide graph validation.

---

# 81. STATE GRAPH VISUAL EDITOR

If implemented:

node/edge canvas.

But canonical saved model remains declarative schema.

UI layout coordinates are presentation metadata, not domain truth.

---

# 82. WORLD VARIABLE EDITOR

Typed variables.

Validation/default/visibility.

---

# 83. ROLE KNOWLEDGE EDITOR

Matrix:

fact

× role visibility.

Prevents hidden leaks.

---

# 84. SCENARIO PREVIEW

Run draft in sandbox.

No official learner state.

Supports:

- fixed seed;
- state jump;
- mock AI;
- offline fallback.

---

# 85. MEDIA ASSET EDITOR

Manage:

- upload/reference;
- type;
- transcript;
- source;
- license/provenance;
- offline availability;
- variants.

---

# 86. MEDIA DUPLICATE DETECTOR

Hash/path/name similarity.

Do not upload same audio repeatedly.

---

# 87. MEDIA REPLACEMENT

Replace file while preserving media ID if semantic content unchanged.

If wording changes:

revision/impact analysis.

---

# 88. TRANSCRIPT EDITOR

Audio-text consistency check.

---

# 89. SOURCE/PROVENANCE EDITOR

Structured:

- source type;
- title;
- author/org;
- date;
- version;
- identifier;
- validation status;
- notes.

Avoid bare URL only.

---

# 90. SOURCE ATTACHMENT

One source can support multiple entities.

Use reference.

---

# 91. SOURCE UPDATE

If source revised:

show dependent entities.

Do not auto-change content.

---

# 92. LICENSE/COPYRIGHT METADATA

For media/text sources where needed:

record rights/license/use constraints.

Do not assume public URL means reusable.

---

# 93. GENERATED CONTENT CANDIDATE

AI-generated entity enters:

`GENERATED_DRAFT`.

It includes:

- generation context;
- target objective;
- schema;
- assumptions;
- validation requirements.

---

# 94. AI CANDIDATE REVIEW

Reviewer sees:

- generated fields;
- canonical refs;
- validation findings;
- provenance status;
- semantic diff if replacing existing content.

---

# 95. AI BULK CANDIDATES

Generate into batch.

Do not activate one-by-one automatically.

Batch quality sampling.

---

# 96. AI REWRITE BOUNDARY

AI can propose edit.

Author chooses accept/reject.

High-risk field may require stronger review.

---

# 97. NO AI SELF-APPROVAL

Invariant.

---

# 98. VALIDATION ORCHESTRATOR

P12 invokes relevant validators based on entity type/risk.

Examples:

vocab:

P7 lexical/stress/government.

technical concept:

P7 + P8.

writing task:

P7 + P9.

scenario:

P7/P8/P9/P11.

assessment:

P4 + P7 + domain.

---

# 99. VALIDATOR REGISTRY

Machine-readable registry:

validator ID;
applies to entity/risk;
blocking?;
output schema;
version.

---

# 100. VALIDATOR RESULT

Fields:

- validator;
- status;
- findings;
- severity;
- evidence;
- timestamp/revision.

Do not store only boolean pass.

---

# 101. BLOCKING FINDING

Must resolve or explicitly waive by authorized policy.

---

# 102. WAIVER

Rare exception.

Record:

- finding;
- reason;
- approver;
- scope;
- expiry/review trigger.

Do not use waiver as routine bypass.

---

# 103. REVIEW QUEUE

Queues may be organized by:

- risk;
- domain;
- stage;
- entity;
- source;
- validator failure;
- generated candidate.

---

# 104. REVIEW ASSIGNMENT

Reviewer gets scope.

Avoid duplicate review where not needed.

---

# 105. REVIEW STATUS

Possible:

`PENDING`

`IN_REVIEW`

`CHANGES_REQUESTED`

`APPROVED`

`REJECTED`

`ESCALATED`.

---

# 106. REVIEW COMMENT

Attach to:

entity;
field;
span;
relation;
finding.

---

# 107. RESOLUTION

Author responds:

fixed;
won't fix with rationale;
needs domain review.

---

# 108. DOMAIN ESCALATION

Use P7 `DOMAIN_REVIEW_REQUIRED`.

Do not block unrelated batch.

---

# 109. MULTI-REVIEWER

Critical changes may require:

linguistic

+ domain

+ assessment

review.

Governance matrix defines combinations.

---

# 110. APPROVAL POLICY

Examples:

low-risk:
one reviewer.

critical assessment:
linguistic + assessment approver.

Actual policy should be configurable.

---

# 111. ACTIVATION POLICY

Approval does not necessarily activate immediately.

May require:

- build;
- preview;
- staging test;
- scheduled release.

---

# 112. ACTIVATION TRANSACTION

For tightly coupled changes:

activate as one logical batch.

Avoid:

grammar active

but linked assessment still old.

---

# 113. CONTENT CHANGESET

Group coherent related revisions.

Examples:

fix Genitive government

+ examples

+ assessment variants.

Changeset has ID and rollback boundary.

---

# 114. CHANGESET DEPENDENCY

Changeset may depend on schema migration/content pack rebuild.

Show prerequisites.

---

# 115. ATOMICITY

If activation partially fails:

rollback whole changeset or mark failed safely.

Do not leave half-active set.

---

# 116. STAGING ENVIRONMENT

Staged content can be loaded by preview/test runtime.

No learner official progress.

---

# 117. PREVIEW MODES

- entity preview;
- lesson preview;
- scenario preview;
- assessment preview;
- offline/package preview.

---

# 118. PREVIEW USER

Use mock learner profiles:

A0;
A2;
B1;
B2;
weak speaking;
offline.

No real learner state needed.

---

# 119. PREVIEW ASSESSMENT

Can reveal answer/editor diagnostics.

But clearly author-only.

No production evidence.

---

# 120. PREVIEW DEPENDENCY SNAPSHOT

Preview should use coherent draft changeset.

Not mix draft entity with incompatible active dependency silently.

---

# 121. BUILD PREVIEW

Run derived index/package build on staged content.

Detect build errors before activation.

---

# 122. SEARCH PREVIEW

Test new content appears correctly in search/index.

---

# 123. OFFLINE PREVIEW

Test required asset pack.

---

# 124. RUNTIME PREVIEW

Open actual learner route with staged data where architecture permits.

---

# 125. CONTENT HEALTH DASHBOARD

Author/admin view may summarize:

- unvalidated;
- blocked;
- stale source;
- orphan;
- duplicate;
- deprecated;
- missing provenance;
- assessment-critical issues;
- scenario validation;
- media missing.

---

# 126. HEALTH METRIC ≠ QUALITY SCORE

Do not create fake single 95% quality.

Show actionable categories.

---

# 127. STALE CONTENT QUEUE

Items needing revalidation due to:

- source update;
- version;
- policy;
- dependency change.

---

# 128. ORPHAN QUEUE

Entity with no reachable use.

Reviewer classifies:

reference;
future;
dead;
broken link.

---

# 129. DUPLICATE QUEUE

Exact/near duplicate candidates.

Reviewer chooses:

keep;
merge;
link;
deprecate.

---

# 130. MERGE DUPLICATE

Need:

- canonical survivor;
- alias;
- reference migration;
- state impact;
- provenance merge;
- rollback.

---

# 131. SPLIT ENTITY

Example lexical sense split.

Need:

- new IDs;
- ref mapping;
- state/evidence analysis.

---

# 132. DEPRECATE

Preferred over delete.

Remove from new authoring/recommendation.

Keep historical resolution.

---

# 133. DELETE

Only when:

- no state/ref dependency;
- no historical need;
- backup/rollback;
- approved.

Rare for canonical IDs.

---

# 134. ALIAS EDITOR

Manage old ID → new ID.

Prevent alias cycles.

---

# 135. MIGRATION AUTHORING

For data/schema/state-sensitive changes:

P12 can prepare migration manifest.

Actual code migration may still require engineering.

---

# 136. MIGRATION PREVIEW

Run fixtures.

Show:

before

→ after

→ validation.

---

# 137. MIGRATION DRY RUN

No writes.

Report affected count/errors.

---

# 138. MIGRATION APPLY

Requires explicit approved changeset.

Idempotence tested.

---

# 139. BULK IMPORT

Support safe import formats as appropriate:

JSON;
CSV;
structured package.

Never raw arbitrary code.

---

# 140. IMPORT STAGING

Imported content always lands in draft/staging.

Not ACTIVE.

---

# 141. IMPORT SCHEMA DETECTION

Require declared schema/entity type.

Do not guess dangerously.

---

# 142. IMPORT MAPPING

Map source columns/fields to canonical schema.

Preview mapping.

---

# 143. IMPORT VALIDATION

Before commit:

- required fields;
- IDs;
- refs;
- duplicates;
- enums;
- provenance;
- language/domain validation where possible.

---

# 144. IMPORT ERROR REPORT

Row/entity-level findings.

Allow repair/reimport.

---

# 145. PARTIAL IMPORT

Prefer all-or-nothing per coherent batch for critical linked data.

For independent records, partial draft import may be allowed.

Never partially activate.

---

# 146. BULK EXPORT

Export canonical/draft entities with:

schema version;
IDs;
provenance;
references.

Do not export learner state in content export.

---

# 147. ROUND-TRIP

Import/export should preserve identity/content where supported.

Test.

---

# 148. CSV LIMITATION

CSV is weak for nested relations.

Use only suitable flat data.

Do not flatten rich schema destructively.

---

# 149. JSON PACKAGE

Preferred for complex entities.

Include manifest.

---

# 150. PACKAGE MANIFEST

Fields:

schema;
entity types;
counts;
source;
revision;
dependencies;
checksum if useful.

---

# 151. CHECKSUM

Can detect accidental file corruption.

Not semantic validation.

---

# 152. LARGE IMPORT

Process incrementally.

Do not freeze browser with 8,000 rich entries.

---

# 153. IMPORT RESUME

Large import may support resumable staging.

No duplicate records.

---

# 154. DUPLICATE ID

Block unless explicit update mode.

---

# 155. UPSERT POLICY

Do not use blind upsert.

Modes:

`CREATE_ONLY`

`UPDATE_EXISTING`

`MERGE_CANDIDATE`.

Author explicitly selects.

---

# 156. UPDATE EXISTING

Requires base revision to prevent stale overwrite.

---

# 157. BULK EDIT

Examples:

add domain tag;
change status;
assign stage.

Preview affected entities.

---

# 158. BULK EDIT SAFETY

Do not bulk change:

stress;
meaning;
answer key;
technical definition

without appropriate validation/review.

---

# 159. FIND & REPLACE

High risk in linguistic/technical content.

Default preview all matches.

Never global replace canonical text blindly.

---

# 160. STRUCTURED TRANSFORM

Prefer semantic transform by field/ID.

Example:

rename domain enum

with migration.

---

# 161. BATCH VALIDATION

Run validators incrementally and summary.

---

# 162. BATCH REVIEW SAMPLE

For large low/medium-risk batch:

risk-based sampling can supplement automation.

Critical records still need full required review.

---

# 163. CONTENT ISSUE INBOX

Receives reports from:

- learner;
- AI P10;
- tester;
- validator;
- admin.

---

# 164. ISSUE TYPES

- typo;
- wrong stress;
- wrong meaning;
- broken audio;
- technical error;
- bad answer;
- unnatural phrase;
- duplicate;
- outdated process;
- broken link;
- scenario bug.

---

# 165. ISSUE TRIAGE

Assign:

severity;
entity;
owner;
reviewer;
status.

---

# 166. ISSUE → CHANGESET

Confirmed issue produces linked changeset.

Do not patch without trace for high-risk item.

---

# 167. DUPLICATE ISSUE

Merge reports to one root issue.

Keep reporters/count if useful.

---

# 168. FALSE REPORT

Close with rationale.

Do not mutate content.

---

# 169. LEARNER-FACING ISSUE FEEDBACK

Optional:

status may be surfaced.

Do not expose internal sensitive review notes.

---

# 170. EMERGENCY DISABLE

For harmful/wrong content:

quickly mark BLOCKED/disable from learner path.

Then perform normal repair.

No need wait full release if content actively corrupts learning and safe feature flag/status exists.

---

# 171. EMERGENCY CHANGE AUDIT

Even emergency action logged.

Follow-up review required.

---

# 172. ROLLBACK

Every activated changeset should have rollback plan.

For content-only reversible changes:

previous revision.

For migration:

migration rollback/recovery.

---

# 173. ROLLBACK PREVIEW

Show what will revert.

Warn about newer dependent changes.

---

# 174. ROLLBACK CONFLICT

If later changes depend on current revision:

cannot blindly revert.

Need forward fix or coordinated rollback.

---

# 175. RESTORE OLD REVISION

Restoring content creates new revision pointing to prior content.

Do not erase history.

---

# 176. AUDIT HISTORY IMMUTABILITY

History remains.

---

# 177. CONTENT SNAPSHOT

Release/changeset may produce content snapshot/manifest.

Useful for reproducibility.

---

# 178. RELEASE CONTENT ID

P17 may map production deploy to content snapshot.

P12 supplies manifest semantics.

---

# 179. REPOSITORY INTEGRATION

If canonical content lives in Git:

editor changes may produce:

- branch/commit;
- PR;
- artifact.

Architecture should not require direct write to main.

---

# 180. GIT-BACKED AUTHORING

Possible workflow:

editor draft

→ generated files

→ validation

→ branch

→ PR

→ merge

→ build.

No assumption if repository uses different backend.

---

# 181. COMMIT MESSAGE

Generated commit should summarize entity/change set.

Avoid `update data`.

---

# 182. PR BODY

Include:

- entities changed;
- semantic diff;
- validation;
- reviewers;
- impact;
- migration;
- rollback.

---

# 183. BINARY MEDIA IN GIT

Large media may need external/object storage.

P12 must not force Git if inappropriate.

Media registry remains canonical reference.

---

# 184. CONTENT DB BACKEND

If editor uses database:

export/snapshot to reproducible build format where architecture requires.

Avoid invisible runtime-only content drift from repo.

---

# 185. SOURCE OF TRUTH

Exactly one canonical source per content type.

Editor is a frontend to that source.

Not a second source.

---

# 186. DUAL WRITE PROHIBITION

Do not write same content independently to:

Git JSON

and:

database

without explicit sync/transaction owner.

This creates drift.

---

# 187. SYNC STATUS

If architecture has sync:

show:

synced;
pending;
conflict;
failed.

---

# 188. FAILED WRITE

Editor must not claim saved/active if backend commit failed.

---

# 189. SAVE CONFIRMATION

Use actual persisted revision ID.

---

# 190. CONTENT LOCK DURING MIGRATION

Prevent incompatible edits during schema migration.

---

# 191. SCHEMA MIGRATION MODE

Editor may become read-only for affected entity type during migration.

---

# 192. SCHEMA EVOLUTION

When new schema field introduced:

- default/backfill;
- editor support;
- validator;
- migration;
- derived build.

No runtime/editor version mismatch.

---

# 193. UNKNOWN FIELD

Editor must preserve unknown forward-compatible fields if appropriate or explicitly reject.

Do not silently drop data.

---

# 194. DEPRECATED FIELD

Show migration guidance.

Do not continue authoring new data into deprecated field.

---

# 195. SCHEMA VERSION DISPLAY

Author/admin may see schema revision for debugging.

Learner does not need it.

---

# 196. ENUM EVOLUTION

Changing enum requires migration/alias.

Do not orphan old data.

---

# 197. REFERENCE TYPE CHANGE

High-risk schema change.

Must migrate references and validators.

---

# 198. CONTENT GRAPH UPDATE

Changes to references update graph.

Graph rebuild/validation before activation.

---

# 199. DERIVED INDEX BUILD

Search/knowledge/link indexes rebuild after canonical changes.

Author should not edit derived index manually.

---

# 200. DERIVED BUILD FAILURE

Block activation if required derived artifact fails.

---

# 201. PACKAGE BUILD FAILURE

Block activation for content requiring pack.

---

# 202. MEDIA MISSING

Block or degrade according to required/optional metadata.

---

# 203. OFFLINE IMPACT

Impact analysis shows:

- new asset size;
- pack changes;
- required offline asset.

P14 later optimizes.

---

# 204. PERFORMANCE IMPACT

Large batch can affect:

- startup;
- search index;
- pack size.

Show estimates/measurements where tooling exists.

---

# 205. AUTHORING PERFORMANCE

Editor must handle thousands of records using:

- search;
- pagination;
- virtualization;
- server/indexed filters.

Do not render 8,000 rich forms.

---

# 206. SEARCH AUTHORING

Search by:

- ID;
- title;
- lemma;
- stage;
- domain;
- status;
- validator finding;
- source.

---

# 207. SAVED FILTER

Optional productivity feature.

Not domain truth.

---

# 208. BULK SELECTION

Safe selection with visible count/scope.

Prevent accidental “select all hidden records” surprise.

---

# 209. DESTRUCTIVE CONFIRMATION

For bulk deprecate/delete:

clear impact.

No generic tiny confirm.

---

# 210. UNDO

Local draft field undo useful.

Activated content rollback is changeset revision, not simple UI undo.

---

# 211. KEYBOARD AUTHORING

Editor should support efficient keyboard use.

P13 owns final UX/accessibility.

P12 defines actions must be accessible.

---

# 212. ACCESSIBILITY

Authoring tools also need:

- labels;
- focus;
- keyboard;
- error association;
- graph alternatives where possible.

---

# 213. ERROR SUMMARY

Validation errors should be navigable.

Do not show 300 errors in one toast.

---

# 214. FIELD-LEVEL ERROR

Show near field.

---

# 215. BATCH ERROR

Group by rule/entity.

---

# 216. WARNING VS ERROR

Warning does not block unless policy says.

Clearly distinguish.

---

# 217. REVIEW DIFF UX SEMANTICS

Reviewer should see:

old;
new;
reason;
findings;
impact;
source.

P13 later designs visual implementation.

---

# 218. APPROVAL ACTION

Approver should know exactly what changeset is approved.

No hidden extra changes.

---

# 219. STALE REVIEW

If content changes after review:

invalidate affected approval.

Do not keep old approval automatically.

---

# 220. PARTIAL REVIEW

If only metadata changes after semantic review:

policy may preserve semantic approval if validator confirms scope.

Do not force unnecessary full review, but be conservative for high risk.

---

# 221. REVIEW SIGNATURE

Record reviewer + revision hash/ID.

---

# 222. APPROVAL EXPIRY

For version-sensitive content, approval may need revalidation trigger.

Not universal time expiry.

---

# 223. SOURCE FRESHNESS QUEUE

Use P7 triggers.

---

# 224. TECHNICAL VERSION QUEUE

Use P8 version-sensitive terms.

---

# 225. INSTITUTIONAL REQUIREMENT QUEUE

Use P9 official requirement versions.

---

# 226. AI CONFIG CHANGE QUEUE

If P10 prompt/model change affects generated-content validation assumptions:

revalidate relevant generation workflow.

---

# 227. SCENARIO COMPONENT CHANGE QUEUE

P11 reusable component changes list dependent scenarios.

---

# 228. AUTHORING AI MODE

Admin-only bounded AI may:

- propose entity;
- enrich metadata;
- generate examples;
- suggest variants;
- draft scenario.

Always candidate.

---

# 229. AUTHORING AI CONTEXT

Use:

schema;
target objective;
canonical refs;
source;
validation rules.

Do not give unrestricted repository context.

---

# 230. AUTHORING AI OUTPUT

Strict structured schema.

Unknown refs rejected.

---

# 231. AUTHORING AI SOURCE REQUIREMENT

For high-risk fact:

must provide/attach source or mark unverified.

---

# 232. AI DUPLICATE CHECK BEFORE GENERATE

Search existing canonical content.

Avoid creating duplicates.

---

# 233. AI BATCH GENERATION

Small pilot.

Quality report.

Then scale.

---

# 234. AI TEMPERATURE/VARIATION

Internal model config may vary by task.

Do not expose as content semantics.

---

# 235. AI FAILURE

Generated malformed/low-quality candidate:

discard/retry.

No canonical impact.

---

# 236. AI HALLUCINATION FINDING

Attach validator finding.

Do not auto-correct by same ungrounded generation loop indefinitely.

---

# 237. CONTENT TEMPLATE

Authoring templates can accelerate:

- vocab;
- unit;
- dialogue;
- scenario.

Templates provide structure.

Not canonical facts.

---

# 238. TEMPLATE VERSION

If template changes:

new drafts use new version.

Old active content need not migrate unless semantics require.

---

# 239. CLONE ENTITY

Clone is draft copy with new ID.

Must clear identity-specific provenance/relations as appropriate.

Prevent accidental duplicate canonical activation.

---

# 240. FORK SCENARIO VARIANT

Prefer scenario family variant before full clone if topology same.

---

# 241. CONTENT COPY WARNING

Copying content may duplicate:

- source;
- answer;
- media;
- IDs.

Editor must regenerate identity and review refs.

---

# 242. AUTHOR NOTES

Private/internal notes distinct from learner-visible content.

---

# 243. REVIEW NOTES

Internal.

Do not leak into runtime.

---

# 244. PUBLIC DESCRIPTION

Explicit learner-visible field.

---

# 245. INTERNAL TAGS

May support governance/search.

Not learner-facing unless intentionally mapped.

---

# 246. TAG GOVERNANCE

Avoid uncontrolled tag spelling explosion.

Use controlled vocabulary for key dimensions.

---

# 247. FREE TAG

May be allowed for internal notes.

Do not make critical logic depend on arbitrary free tags.

---

# 248. TAXONOMY EDITOR

For domains/stages/skills:

changes are high impact.

Requires schema/governance review.

---

# 249. CURRICULUM MOVE

Moving unit between modules affects:

- prerequisites;
- stage;
- recommendations;
- links.

Impact analysis required.

---

# 250. LESSON RETIREMENT

Preserve learner history.

Map replacement if one exists.

---

# 251. CONTENT ARCHIVE

Retired content can remain searchable to admin.

Not in learner navigation.

---

# 252. HISTORICAL VIEW

Admin can inspect old revision.

Useful for debugging old attempts.

---

# 253. CONTENT SNAPSHOT VIEW

Given production snapshot, reconstruct active content set.

---

# 254. ATTEMPT CONTENT RESOLUTION

Old learner attempt should resolve content revision used at attempt where architecture supports.

P4 owns attempt semantics.

---

# 255. CONTENT FIX IMPACT ON ATTEMPTS

P12 surfaces P7/P4 impact classification.

It does not silently recalculate scores.

---

# 256. ASSESSMENT EMERGENCY INVALIDATION

If wrong answer discovered:

block item from new official use quickly.

Then P4 handles existing attempt impact.

---

# 257. ASSESSMENT REPLACEMENT

New item gets new identity if semantic target changes materially.

---

# 258. QUESTION BANK BALANCE

Editor can show coverage by:

objective;
skill;
difficulty;
mode.

Do not auto-fill gaps with unvalidated AI.

---

# 259. COVERAGE DASHBOARD

Show curriculum/content coverage:

- module;
- skill;
- technical domain;
- assessment;
- scenario.

Diagnostic only.

---

# 260. COVERAGE GAP

Gap can create authoring task.

Not automatic generated content.

---

# 261. AUTHORING TASK QUEUE

Governance may create tasks:

- missing audio;
- unvalidated stress;
- no production task;
- stale technical term;
- missing scenario.

---

# 262. TASK ASSIGNMENT

Assign reviewer/author.

Separate from learner tasks.

---

# 263. DEADLINE

Optional project management metadata.

Not content truth.

---

# 264. CONTENT GOVERNANCE BOARD

If project expands to multiple maintainers, roles may coordinate high-risk policy.

Not required for single maintainer.

P12 should scale without forcing bureaucracy.

---

# 265. SINGLE-MAINTAINER MODE

Can simplify approvals while preserving:

- validation;
- diff;
- evidence;
- rollback.

Do not remove safety merely because one person maintains.

---

# 266. TRUSTED AUTOMATION

May auto-run:

- schema;
- references;
- duplicates;
- build;
- tests.

Cannot replace semantic review where required.

---

# 267. CI INTEGRATION

PR/content change runs:

- validators;
- build;
- tests;
- derived index.

P15 later full QA.

---

# 268. PRE-COMMIT CONTENT CHECK

Optional quick validator for authors.

---

# 269. SERVER-SIDE VALIDATION

Do not rely solely on client validation.

Canonical write path revalidates.

---

# 270. AUTHORIZATION SERVER-SIDE

UI-hidden button is not security.

Backend/action path enforces permissions.

P14 hardens security.

---

# 271. INPUT SANITIZATION

Imported/editor content treated as data.

No raw script execution.

---

# 272. RICH TEXT SANITIZATION

Allow safe formatting.

Reject dangerous HTML/script.

---

# 273. MARKDOWN

Store markdown only if renderer/sanitization contract is clear.

---

# 274. CODE BLOCK

Preserve technical code without rich-text mutation.

---

# 275. FORMULA

Use safe representation.

Do not evaluate arbitrary code.

---

# 276. URL FIELD

Validate protocol/source.

External content remains untrusted.

---

# 277. MEDIA UPLOAD SECURITY

Validate file type/size.

P14 later hardens storage/security.

---

# 278. FILE NAME

Do not trust filename as identity.

Use asset ID.

---

# 279. VIRUS/MALWARE SCAN

If upload infrastructure supports, P14/security may require.

P12 marks integration requirement.

---

# 280. AUTHORING OFFLINE

Not required for every deployment.

If offline authoring supported:

need conflict-safe sync.

Do not implement casually.

---

# 281. EDITOR SYNC

Pending local draft

→ server/repo.

Conflict detection.

---

# 282. AUTHORING BACKUP

Draft backup/recovery strategy.

---

# 283. DISASTER RECOVERY

Canonical content source needs backups/snapshots according to platform.

P14 owns infrastructure.

P12 defines recovery expectations.

---

# 284. CHANGESET BACKUP

Activated changeset references previous snapshot.

---

# 285. AUDIT EXPORT

Admin may export audit log subset for debugging.

Protect sensitive info.

---

# 286. CONTENT QA SAMPLE

Reviewer can sample random/risk records from batch.

---

# 287. BATCH QUALITY THRESHOLD

If sample defect rate high:

stop activation.

Expand review.

Do not “pass enough”.

---

# 288. REVIEW FATIGUE

Large batches should be chunked.

Avoid asking reviewer to approve thousands blindly.

---

# 289. DIFF COLLAPSE

Reviewer UI can collapse unchanged fields.

P13 designs.

---

# 290. HIGH-RISK HIGHLIGHT

Stress/answer/source/ID changes highlighted.

---

# 291. CONTENT COMMENT THREAD

Optional collaboration.

Comments tied to revision.

---

# 292. RESOLVED COMMENT

History retained.

---

# 293. AUTHORING NOTIFICATION

Optional:

review requested;
changes requested;
approved;
activation failed.

Not core content semantics.

---

# 294. WEBHOOK/AUTOMATION

If integrated with Git/CI:

events may trigger build/review.

P12 defines safe events; external connectors enforce auth.

---

# 295. NO HIDDEN PUBLISH

Saving draft must never publish.

Approving must not necessarily publish unless policy explicitly defines one-step action.

Use explicit verbs.

---

# 296. ACTION NAMING

Buttons/actions should say:

`Save draft`

`Submit for review`

`Approve`

`Stage`

`Activate`

`Deprecate`

not vague:

`Save`

for everything.

P13 final UX.

---

# 297. CONFIRMATION BOUNDARY

Confirm only meaningful destructive/high-impact actions.

Do not add modal fatigue to every save.

---

# 298. ACTIVATION SUMMARY

Before activation:

show:

- count;
- high-risk changes;
- failed warnings;
- impact;
- rollback.

---

# 299. PARTIAL ACTIVATION PROHIBITION

Critical coherent changeset should not activate subset accidentally.

---

# 300. ACTIVATION FAILURE

Status:

`ACTIVATION_FAILED`.

Draft/approved data remains.

Production active snapshot unchanged.

---

# 301. RETRY ACTIVATION

Idempotent.

---

# 302. POST-ACTIVATION VALIDATION

Run smoke:

- canonical load;
- search index;
- representative route;
- reference resolution.

P15/P17 later broader.

---

# 303. POST-ACTIVATION MONITOR

Look for:

- error;
- missing ref;
- build issue.

Content-specific monitoring.

---

# 304. QUICK ROLLBACK TRIGGER

Critical content regression.

---

# 305. ACTIVATION ENVIRONMENTS

Possible:

draft;
preview;
staging;
production.

Do not assume all deployments have each.

Semantics remain.

---

# 306. ENVIRONMENT BADGE

Author/admin clearly sees where change exists.

Avoid editing production unknowingly.

P13 UX.

---

# 307. PRODUCTION READ-ONLY DEFAULT

Direct production editing discouraged.

Use governed pipeline.

---

# 308. EMERGENCY PRODUCTION BLOCK

Status flag may remove bad content quickly.

Full repair still goes through pipeline.

---

# 309. CONTENT STATUS PROPAGATION

Derived indexes/packs respect:

ACTIVE/DEPRECATED/BLOCKED.

---

# 310. SEARCH DEPRECATED

Admin search can find.

Learner search normally hides unless historical context.

---

# 311. ALIAS RESOLUTION

Old links resolve replacement where possible.

---

# 312. BROKEN LINK REPORT

Authoring dashboard flags.

---

# 313. DEEP LINK PREVIEW

Test old/new route.

---

# 314. MEDIA LINK PREVIEW

Check asset exists.

---

# 315. SOURCE LINK CHECK

Can flag unreachable link.

But source validity not determined by HTTP alone.

---

# 316. CONTENT QUALITY REPORT

Per changeset:

- schema;
- refs;
- linguistic;
- technical;
- assessment;
- scenario;
- build.

---

# 317. AUTHORING GOLDEN FIXTURES

Create test content covering:

- valid entity;
- missing required;
- dangling ref;
- stale revision conflict;
- duplicate ID;
- semantic high-risk edit;
- bulk import error;
- assessment answer change;
- scenario graph conflict;
- rollback;
- deprecate/alias.

---

# 318. CONCURRENCY FIXTURES

Two editors:

same field conflict.

Different field safe merge.

Bulk update vs individual edit.

---

# 319. PERMISSION FIXTURES

Contributor cannot activate.

Reviewer cannot edit protected production state.

AI cannot self-approve.

---

# 320. PREVIEW FIXTURES

Draft lesson/scenario loads without official state writes.

---

# 321. ACTIVATION FIXTURES

Failed derived build prevents activation.

---

# 322. ROLLBACK FIXTURES

Restore previous revision and rebuild derived data.

---

# 323. IMPORT FIXTURES

Malformed CSV/JSON.

Duplicate.

Unknown enum.

Bad reference.

Mixed valid/invalid batch.

---

# 324. MIGRATION FIXTURES

Old schema

→ new schema

idempotent.

---

# 325. AUDIT FIXTURE

Every high-risk action recorded.

---

# 326. CONTENT INTEGRITY TEST

After activation:

no dangling required refs;
IDs unique;
owners consistent.

---

# 327. AUTHORING PERFORMANCE BASELINE

Measure:

- search;
- open record;
- save draft;
- validation;
- diff;
- bulk import;
- graph view.

No arbitrary target until baseline.

---

# 328. LARGE-DATA TEST

At least simulate:

8k vocab

+ thousands dialogue/scenario refs.

Editor remains usable.

---

# 329. VIRTUALIZATION TEST

No huge DOM for list/editor.

P13/P14 implementation detail.

---

# 330. TOKEN-EFFICIENT AI AUTHORING

AI authoring context uses:

- schema;
- target;
- relevant canonical refs.

Not whole repository.

---

# 331. AUTHORING SEARCH INDEX

Derived index for admin.

Can include:

status;
validation;
source;
domain.

---

# 332. CONTENT SNAPSHOT MANIFEST

Every activated set can produce:

- snapshot ID;
- timestamp;
- entity revisions;
- derived build revision;
- media manifest.

Useful for P17.

---

# 333. SNAPSHOT IMMUTABILITY

Once tied to release, preserve record.

---

# 334. RELEASE DIFF

Compare snapshots semantically.

---

# 335. P13 HANDOFF

P12 supplies P13:

- authoring actions;
- statuses;
- validation states;
- diff semantics;
- review workflow;
- error/warning hierarchy;
- preview modes;
- impact/dependency semantics;
- permission-aware actions.

P13 designs usable/accessibility UI.

P13 must not change governance meaning.

---

# 336. REQUIRED DELIVERABLES — CORE

Create/maintain:

`subjects/russian/docs/p12/RUSSIAN_P12_EXECUTIVE_SUMMARY.md`

`RUSSIAN_CONTENT_LIFECYCLE_CONTRACT.md`

`RUSSIAN_AUTHORING_ROLE_PERMISSION_MATRIX.md`

`RUSSIAN_EDITOR_SCHEMA_CONTRACT.md`

`RUSSIAN_REVIEW_APPROVAL_POLICY.md`

`RUSSIAN_CHANGESET_ACTIVATION_CONTRACT.md`

`RUSSIAN_CONTENT_IMPACT_ANALYSIS_CONTRACT.md`

`RUSSIAN_CONTENT_AUDIT_LOG_POLICY.md`.

---

# 337. REQUIRED DELIVERABLES — IMPORT/MIGRATION

Create:

`RUSSIAN_BULK_IMPORT_EXPORT_POLICY.md`

`RUSSIAN_DUPLICATE_MERGE_POLICY.md`

`RUSSIAN_DEPRECATION_ALIAS_POLICY.md`

`RUSSIAN_CONTENT_MIGRATION_AUTHORING_POLICY.md`

`RUSSIAN_CONTENT_ROLLBACK_POLICY.md`.

---

# 338. REQUIRED DELIVERABLES — AI/GOVERNANCE

Create:

`RUSSIAN_AI_AUTHORING_CANDIDATE_CONTRACT.md`

`RUSSIAN_VALIDATOR_REGISTRY.json`

`RUSSIAN_CONTENT_ISSUE_WORKFLOW.md`

`RUSSIAN_CONTENT_HEALTH_MODEL.md`.

---

# 339. REQUIRED DELIVERABLES — QA

Create:

`RUSSIAN_AUTHORING_GOLDEN_FIXTURES.json`

`RUSSIAN_P12_PERMISSION_TEST_MATRIX.md`

`RUSSIAN_P12_CONCURRENCY_TEST_REPORT.md`

`RUSSIAN_P12_IMPORT_TEST_REPORT.md`

`RUSSIAN_P12_ACTIVATION_ROLLBACK_REPORT.md`

`RUSSIAN_P12_RISK_REGISTER.json`

`RUSSIAN_P12_EVIDENCE_INDEX.md`

`RUSSIAN_P13_INPUT_CONTRACT.md`.

No empty ceremonial documents.

---

# 340. PILOT

Pilot with multiple entity types:

### Pilot A — Vocabulary
Edit stress/collocation/provenance.

### Pilot B — Lesson
Add micro-lesson referencing canonical entities.

### Pilot C — Assessment
Edit accepted variant.

### Pilot D — Scenario
Modify branch/world fact and preview.

### Pilot E — Bulk import
Small technical vocabulary batch.

---

# 341. PILOT ACCEPTANCE

Must prove:

- role/permission;
- draft;
- schema editor;
- validation;
- review;
- semantic diff;
- impact;
- preview;
- activation;
- derived rebuild;
- rollback;
- audit.

---

# 342. MIGRATION ORDER

Recommended:

1. Owner registry integration.
2. Entity schema registry.
3. Draft store.
4. Editor forms.
5. Validators.
6. Review workflow.
7. Diff/impact.
8. Preview.
9. Activation/rollback.
10. Bulk import/export.
11. AI authoring candidate.
12. Scenario graph editor.
13. Health/dashboard.
14. Retire manual ad hoc edit paths.

---

# 343. LEGACY MANUAL EDIT

Manual repository edits may still exist.

P12 should detect/sync them via canonical source.

Do not create permanent “editor-only” fork.

---

# 344. DIRECT JSON EDIT

Can remain emergency/expert fallback.

But must pass same validators/governance before activation.

---

# 345. NO-CODE SUCCESS CRITERION

After P12:

adding a normal new lesson/task/vocab/scenario should not require application-code modification.

If it does:

identify missing schema/editor capability.

---

# 346. P12 RISK REGISTER

Track:

- direct production write;
- permission bypass;
- stale overwrite;
- dual source truth;
- partial activation;
- invalid import;
- AI self-approval;
- lost provenance;
- broken refs;
- destructive delete;
- rollback failure;
- schema/editor mismatch;
- bulk edit blast radius;
- reviewer fatigue.

---

# 347. BLOCKER EXAMPLES

BLOCKER:

- editor can directly alter mastery;
- unauthorized contributor can activate;
- save draft writes production;
- stale editor silently overwrites new revision;
- activation can partially apply critical batch;
- AI candidate can auto-activate;
- canonical content dual-written independently;
- rollback cannot recover high-risk content change.

---

# 348. CRITICAL EXAMPLES

CRITICAL:

- stress/answer key can be bulk-edited without validation;
- source/provenance silently lost;
- delete removes IDs used by learner history;
- scenario graph activation has unreachable/deadlocked states;
- import creates duplicate IDs;
- approval remains valid after semantic edit;
- preview writes official learner evidence.

---

# 349. P12 FAIL CONDITIONS

P12 FAIL if:

- authoring still requires routine code edits;
- entity forms ignore schema;
- canonical owner unknown;
- no draft/review separation;
- no provenance workflow;
- no semantic diff;
- no impact analysis;
- no preview sandbox;
- no activation transaction;
- no rollback;
- no audit log;
- no conflict detection;
- no bulk import staging;
- AI can self-approve;
- derived indexes edited manually;
- deprecated/delete behavior breaks old refs;
- permissions enforced only in UI;
- P13 has no stable workflow semantics.

---

# 350. P12 PASS CONDITIONS

P12 PASS when:

1. Canonical owner registry drives editor.
2. Routine content is no-code authorable.
3. Draft/active states are distinct.
4. Roles/permissions are explicit.
5. Server/action authorization enforced.
6. Schema-aware editor exists.
7. References use stable IDs.
8. Backlinks/impact analysis work.
9. Optimistic concurrency prevents silent overwrite.
10. Semantic diff exists.
11. Validators orchestrate by entity/risk.
12. Review/approval lifecycle works.
13. Approval invalidates on semantic change.
14. Preview sandbox has no official state writes.
15. Changeset activation is safe.
16. Derived indexes rebuild.
17. Rollback works.
18. Audit log works.
19. Bulk import stages safely.
20. Duplicate/merge/deprecate/alias workflows exist.
21. Schema migration workflow exists.
22. AI authoring is candidate-only.
23. Content issue inbox works.
24. Emergency disable works.
25. Large-data editing remains usable.
26. Media/source provenance is supported.
27. Assessment editor respects P4/P7.
28. Scenario editor respects P11.
29. Content snapshot can support release reproducibility.
30. P13 receives complete UI semantics.

---

# 351. P12 PROMPT COMPLETENESS GATE

P12 prompt is structurally complete only if it covers:

1. lifecycle;
2. roles/permissions;
3. schema editor;
4. entity-specific editors;
5. provenance;
6. validators;
7. review;
8. diff;
9. impact;
10. concurrency;
11. preview;
12. staging;
13. activation;
14. rollback;
15. audit;
16. import/export;
17. bulk edit;
18. duplicate/merge;
19. deprecation/alias;
20. migration;
21. issue workflow;
22. emergency disable;
23. AI authoring;
24. media/source;
25. repo/backend source-of-truth;
26. large-data performance;
27. security/authorization boundary;
28. snapshot/release;
29. QA/golden fixtures;
30. P13 handoff.

If all are defined:

`P12 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P12 implementation has PASSed.

---

# 352. FINAL RESPONSE FORMAT

When P12 implementation completes:

`P12 STATUS: PASS / FAIL / BLOCKED`

`Base SHA:`

`Head SHA:`

`No-code authoring: PASS / FAIL`

`Owner registry integration: PASS / FAIL`

`Role/permission: PASS / FAIL`

`Draft/review lifecycle: PASS / FAIL`

`Schema-aware editor: PASS / FAIL`

`Validation orchestration: PASS / FAIL`

`Provenance: PASS / FAIL`

`Semantic diff: PASS / FAIL`

`Impact analysis: PASS / FAIL`

`Concurrency/conflict: PASS / FAIL`

`Preview sandbox: PASS / FAIL`

`Activation transaction: PASS / FAIL`

`Rollback: PASS / FAIL`

`Audit log: PASS / FAIL`

`Bulk import/export: PASS / FAIL`

`AI candidate boundary: PASS / FAIL`

`Scenario authoring: PASS / FAIL`

`Assessment authoring: PASS / FAIL`

`Large-data performance: PASS / FAIL`

`Content snapshot: PASS / FAIL`

`P13 readiness: READY / NOT READY`

`PR:`

`Merged SHA:`

`Production: UNCHANGED unless explicitly authorized`

End:

**P12 AUTHORING · CONTENT GOVERNANCE · EDITOR WORKFLOW COMPLETE**

---

# 353. EXECUTION RULE

When authorized:

`inventory current manual content-edit paths`

→ `confirm source-of-truth`

→ `connect schema/owner registries`

→ `build draft workflow`

→ `build base schema editor`

→ `add entity-specific editors`

→ `integrate validators`

→ `add review/approval`

→ `add semantic diff/impact`

→ `add preview sandbox`

→ `add changeset activation/rollback`

→ `add import/export`

→ `add AI candidate flow`

→ `pilot vocab/lesson/assessment/scenario`

→ `test permissions/concurrency`

→ `retire unsafe ad hoc paths`

→ `document evidence`

→ `open PR`.

Do not begin by building a visually elaborate CMS before the governance contract works.

---

# 354. FINAL P12 PRINCIPLE

A content editor is successful only if it makes content easier to change **without making truth easier to corrupt**.

For every authoring action ask:

1. Which canonical owner is being changed?
2. Which schema applies?
3. Who is allowed to change it?
4. What evidence/source supports the change?
5. Which validators must pass?
6. Which dependents are affected?
7. Can it be previewed safely?
8. Does it affect assessment or learner state?
9. Can it be rolled back?
10. Can we reconstruct who changed what and why?

If those cannot be answered:

the editor is only a prettier way to edit random JSON.

**NO-CODE DOES NOT MEAN NO-GOVERNANCE.**
**DRAFT BEFORE ACTIVE.**
**VALIDATE BEFORE APPROVE.**
**PREVIEW BEFORE ACTIVATE.**
**IMPACT BEFORE CHANGE.**
**ROLLBACK BEFORE RISK.**\n\n---\n\n# P12 HARDENING ADDENDUM\n## FINAL COMPLETENESS PASS BEFORE P13\n\nThis addendum closes the last governance/editor edge cases before the UX layer.\n\n# 355. REVIEW QUORUM\nHigh-risk changes may require linguistic + domain + assessment approval according to policy. Do not force the same quorum on low-risk metadata edits.\n\n# 356. REVIEWER CONFLICT\nIf reviewers disagree, use `REVIEW_CONFLICT`; preserve both positions/evidence and resolve explicitly. Do not let the last click win.\n\n# 357. REVIEWER RECUSAL\nA reviewer may abstain when outside expertise or evidence is insufficient.\n\n# 358. APPROVAL SCOPE\nApproval binds to a specific revision/changeset, not future edits.\n\n# 359. APPROVAL INVALIDATION\nAny semantic edit after approval invalidates affected approval. Metadata-only preservation requires explicit policy and impact proof.\n\n# 360. PERMISSION DRIFT\nRevoked or changed roles must take effect at protected action time. Cached permissions cannot continue to authorize activation.\n\n# 361. ACTION-TIME AUTHORIZATION\nHigh-impact actions re-check authorization server/action side. UI visibility is not security.\n\n# 362. CONTENT FREEZE\nMajor migration/release may freeze activation for affected entity types while reads and safe drafts continue.\n\n# 363. PARTIAL FREEZE\nFreeze the narrowest safe scope.\n\n# 364. EMERGENCY PATCH\nEmergency content block/fix still records actor, reason, diff, validation, rollback and post-review.\n\n# 365. TEMPORARY WORKAROUND\nEmergency workaround needs a review/removal trigger.\n\n# 366. SOURCE-OF-TRUTH DRIFT\nDetect Git/database/editor divergence and stop dual writes until canonical owner is restored.\n\n# 367. EXTERNAL MANUAL EDIT\nManual canonical changes outside the editor force refresh/rebase; stale draft may not overwrite them silently.\n\n# 368. EDITOR/SCHEMA DRIFT\nIf schema changes during an editor session, incompatible save must fail clearly and preserve draft.\n\n# 369. VALIDATOR VERSION DRIFT\nCritical validator fixes may require revalidation of affected previously approved content.\n\n# 370. AUDIT LOG INTEGRITY\nAudit history is append-oriented and not editable by ordinary content actions. Corrections are new records.\n\n# 371. AUTHORITATIVE TIME ORDER\nServer/repository sequence determines revision order, not client clock.\n\n# 372. CHANGESET BASE\nChangesets may pin a base snapshot/revision and must rebase if active content changed.\n\n# 373. CHANGESET SPLIT/MERGE\nLarge changesets may split into coherent dependent batches; governance history remains traceable even if commits are squashed.\n\n# 374. ROLLBACK GRANULARITY\nSupport entity, changeset or snapshot rollback. Prefer forward fix when later changes depend on the current revision.\n\n# 375. RECOVERY POINT\nCreate a verified recovery point before high-risk activation.\n\n# 376. IMPORT TRUST\nImported packages carry schema, source/provenance and optional checksum/signature. Unknown packages enter quarantine/draft.\n\n# 377. LARGE-BATCH REVIEW\nCombine deterministic validation, stratified sampling and full review of critical records. Do not review 8,000 items by scrolling.\n\n# 378. DEFECT-RATE ESCALATION\nIf sampled defect rate is high, stop activation and expand review.\n\n# 379. REVIEW WORKLOAD\nChunk large review queues and show reviewed/remaining/blocked/conflict counts.\n\n# 380. CONTENT OWNERSHIP TRANSFER\nMaintainer changes update governance owner, never canonical entity IDs.\n\n# 381. ORPHAN GOVERNANCE OWNER\nCritical entity types must always have a responsible governance owner.\n\n# 382. CONTENT SUNSET\nRetirement requires replacement/ref migration, learner-history resolution, derived rebuild and archive evidence.\n\n# 383. PRIVACY IN AUTHORING LOGS\nDo not store unrelated learner private data in content governance logs.\n\n# 384. SECRET DETECTION\nReject/redact accidental credentials/secrets from imported content/config.\n\n# 385. PREVIEW SANDBOX ISOLATION\nPreview must not inherit production write permissions or official learner-state writes.\n\n# 386. EXTERNAL CALLS IN PREVIEW\nMock/disable external actions by default; enable only deliberate integration tests.\n\n# 387. EDITOR FEATURE FLAG\nNew authoring capabilities can be rolled out/disabled independently without content corruption.\n\n# 388. OLD DRAFT COMPATIBILITY\nOld-schema drafts migrate, open read-only or export for recovery; never silently drop unknown fields.\n\n# 389. UNSAVED/AUTOSAVE STATE\nShow `saving`, `saved`, `failed`, `conflict`; never claim saved before persistence confirmation.\n\n# 390. OFFLINE AUTHORING\nIf supported, offline mode queues drafts only; production activation is never queued blindly offline.\n\n# 391. SYNC CONFLICT\nOffline reconnection requires conflict-safe merge/rebase.\n\n# 392. BULK DRY RUN\nHigh-impact bulk transform must show matched count, fields, exclusions and expected validators before apply.\n\n# 393. BULK AUDIT/ROLLBACK\nA bulk operation has one operation ID and a coherent rollback boundary where safe.\n\n# 394. FIND/REPLACE SAFETY\nPreview every semantic match; never global-replace technical/code content blindly.\n\n# 395. CUSTOM TRANSFORM SCRIPTS\nArbitrary scripts belong engineering/migration tooling with tests, not general editor execution.\n\n# 396. WAIVER VISIBILITY\nBlocking-validator waivers remain visible through activation and can have revalidation triggers.\n\n# 397. QUALITY DEBT\nWaived issues remain tracked as content debt.\n\n# 398. AUTHORING API CONTRACT\nWork/Codex/external tools use the same schema, permission, draft, validation and activation rules. No hidden privileged bypass.\n\n# 399. AGENT IDENTITY\nAutomated changes record tool/agent identity and authorization context.\n\n# 400. AGENT SAFE DEFAULT\nAgents may draft/validate/propose; activation follows governance.\n\n# 401. AGENT BULK SCOPE\nBulk agent changes need an explicit bounded changeset and idempotent retry semantics.\n\n# 402. CONTENT API VERSIONING\nSchema/API mismatch fails clearly.\n\n# 403. AUTHORING WEBHOOKS\nEvents such as review/approval/activation must be idempotent and avoid leaking unnecessary content.\n\n# 404. SNAPSHOT REPRODUCIBILITY\nA release content snapshot must be reproducible from canonical source and semantically diffable against adjacent snapshots.\n\n# 405. GOLDEN GOVERNANCE REGRESSION\nMaintain fixtures for permission revocation, approval invalidation, stale overwrite, validator recheck, emergency block, import quarantine, offline conflict, source-of-truth drift, rollback dependency and agent retry.\n\n# 406. P12 REVALIDATION TRIGGERS\nRevalidate affected workflows when schema registry, permission model, validator registry, authoring API, source backend, P13 editor UX contract or P14 security/storage semantics change materially.\n\n# 407. P12 PROMPT COMPLETENESS GATE — HARDENED\nP12 is COMPLETE/HARDENED only when lifecycle, authorization, concurrency, provenance, validation, review/conflict, preview isolation, activation, emergency action, rollback, audit integrity, bulk/import, agent/API authoring, snapshot reproducibility and P13 handoff are all defined.\n\n**P12 PROMPT HARDENING COMPLETE**\n
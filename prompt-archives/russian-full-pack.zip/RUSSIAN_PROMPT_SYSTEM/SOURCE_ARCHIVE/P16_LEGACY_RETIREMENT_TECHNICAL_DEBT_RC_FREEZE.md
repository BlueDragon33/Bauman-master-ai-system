# P16 — LEGACY RETIREMENT · TECHNICAL DEBT CLOSURE · RELEASE CANDIDATE FREEZE CONSTITUTION
## ONE RUNTIME PATH · ONE OWNER · DEBT CLOSURE · REPRODUCIBLE RC · FINAL P17 HANDOFF

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Execution mode:

**AUTONOMOUS · DELETE-WITH-EVIDENCE · SINGLE-OWNER · NO-NEW-FEATURES · RC-FREEZE · REPRODUCIBLE · ROLLBACK-SAFE · TOKEN-EFFICIENT**

---

# P16 CHANGELOG

- 2026-09-30 — Full deep P16 constitution created.
- 2026-09-30 — Final hardening: artifact promotion, build/runtime config drift, production DB/migration identity, OAuth/DNS/TLS/CDN readiness, service-worker release boundary, isolated production smoke, canary/blue-green optionality, rollback decision matrix and production drift verification.

---

# 0. MISSION

P16 is the closure layer before production.

P16 exists to transform an accepted but historically evolved codebase into one coherent Release Candidate.

Its job is to:

- remove obsolete paths;
- retire duplicate owners;
- close release-relevant technical debt;
- eliminate dead/unsafe compatibility shims;
- freeze code/content/config/dependencies;
- prove reproducibility;
- assemble final release documentation;
- hand one exact candidate to P17.

P16 is not a feature-building phase.

The central rule is:

> **AFTER P16, THERE MUST BE ONE CLEAR ACTIVE PATH FOR EACH CRITICAL RESPONSIBILITY.**

---

# 1. HARD ENTRY GATE

P16 may begin deep cleanup only when:

- P15 final acceptance is PASS or PASS with explicitly non-blocking risks;
- exact candidate SHA is known;
- content snapshot is known;
- blocker count = 0;
- critical residuals are resolved or explicitly governed by release policy;
- rollback evidence exists.

If not:

`P16 STATUS: BLOCKED`.

---

# 2. P16 AUTHORITY

P16 can:

- remove verified dead code;
- retire legacy routes;
- remove duplicate adapters;
- remove obsolete feature flags;
- remove deprecated content/runtime paths;
- simplify compatibility layers;
- update documentation;
- pin/freeze dependencies;
- create RC manifest;
- rerun affected regression.

P16 cannot:

- add unrelated features;
- change curriculum goals;
- relax P15 gates;
- silently redefine mastery;
- replace working architecture for elegance;
- delete historical state needed for compatibility.

---

# 3. CORE OUTCOME

P16 produces:

`ONE CODE CANDIDATE`

+ `ONE CONTENT SNAPSHOT`

+ `ONE CONFIG PROFILE`

+ `ONE DEPENDENCY LOCK`

+ `ONE MIGRATION SET`

+ `ONE ROLLBACK TARGET`

+ `ONE ACCEPTANCE EVIDENCE PACKAGE`.

That package becomes P17 input.

---

# 4. NO MOVING TARGET

Once RC freeze starts:

no unrelated feature work.

Only:

- blocker/critical fix;
- RC documentation;
- required cleanup;
- deterministic release metadata.

Any semantic runtime change triggers P15 revalidation.

---

# 5. LEGACY DEFINITION

Legacy means an older path retained from previous architecture, such as:

- old route;
- old data owner;
- old service;
- compatibility adapter;
- deprecated API;
- duplicate UI;
- old migration;
- old feature flag;
- obsolete cache name;
- stale content file;
- dead fallback.

Not all old code is safe to remove.

Evidence first.

---

# 6. TECHNICAL DEBT DEFINITION

Technical debt includes:

- duplicate responsibilities;
- brittle workaround;
- TODO/FIXME in release-critical path;
- ignored test;
- deprecated dependency;
- stale config;
- dead code;
- undocumented migration;
- warning suppression;
- unsafe type bypass;
- manual-only release step;
- non-reproducible generated artifact.

P16 closes release-relevant debt, not every aesthetic imperfection.

---

# 7. DEBT CLASSIFICATION

`RELEASE_BLOCKING`

`RC_REQUIRED`

`POST_RELEASE_ACCEPTABLE`

`INTENTIONAL_COMPATIBILITY`

`FALSE_POSITIVE / NO_ACTION`.

Every deferred item must be explicit.

---

# 8. LEGACY INVENTORY

Build inventory from:

- P1 forensic findings;
- P15 runtime observations;
- repository search;
- dependency graph;
- route map;
- service map;
- config/env;
- feature flags;
- generated artifacts;
- old content files.

Do not start deleting from memory.

---

# 9. INVENTORY RECORD

Each candidate legacy item should include:

- ID/path;
- owner/responsibility;
- current references;
- runtime evidence;
- historical reason if known;
- replacement;
- learner-state dependency;
- rollback need;
- proposed action.

---

# 10. LEGACY ACTION ENUM

`KEEP_REQUIRED`

`MIGRATE_THEN_REMOVE`

`DEPRECATE`

`REMOVE_NOW`

`ARCHIVE`

`UNKNOWN_NEEDS_EVIDENCE`.

---

# 11. UNKNOWN IS NOT REMOVE

If usage cannot be proven absent:

investigate.

Do not delete simply because search looks empty; dynamic/config references may exist.

---

# 12. DEAD CODE EVIDENCE

Use multiple signals where useful:

- static references;
- route registration;
- build output;
- runtime coverage;
- feature flags;
- tests;
- P15 journeys.

No single signal is universal.

---

# 13. DEAD CONTENT EVIDENCE

Content entity may have no direct route but remain needed by:

- historical attempt;
- alias;
- search;
- offline pack;
- migration.

Check graph/state.

---

# 14. DELETE VS ARCHIVE

Delete only when history/compatibility does not require resolution.

Archive when forensic value remains.

---

# 15. HISTORICAL STATE PROTECTION

Never break ability to interpret:

- old attempt;
- old score;
- old scenario session history;
- old writing submission;
- prior content snapshot

within supported retention model.

---

# 16. CANONICAL OWNER AUDIT

For every critical responsibility verify exactly one active owner:

- content schema;
- vocab;
- grammar;
- assessment;
- mastery;
- SRS;
- Today planner;
- audio/speech;
- AI;
- scenario;
- authoring;
- service worker/cache;
- active snapshot.

---

# 17. DUPLICATE OWNER

If two active paths can independently mutate same domain truth:

P16 cannot freeze.

Resolve:

select owner

→ migrate callers

→ test

→ remove/deactivate duplicate.

---

# 18. READ DUPLICATION

Multiple derived read views may exist if they reference same owner.

Not all duplication is harmful.

---

# 19. WRITE DUPLICATION

Multiple independent writers to same canonical state is high risk.

Must resolve.

---

# 20. DUAL SOURCE OF TRUTH

Examples:

- Git JSON + DB independently editable;
- local state + server both authoritative;
- scenario state in UI + engine;
- AI score + deterministic score.

Must be eliminated or explicit one-way sync owner defined.

---

# 21. LEGACY ROUTE AUDIT

Inventory:

- active routes;
- redirects;
- old deep links;
- admin paths;
- duplicate feature pages.

---

# 22. ROUTE ACTION

For old route:

`REDIRECT`

`ALIAS`

`DEPRECATE`

`REMOVE`

depending on compatibility.

---

# 23. REDIRECT SAFETY

No loops.

Preserve query/state where required.

---

# 24. OLD DEEP LINK

Should resolve to replacement if historical/user links likely exist.

---

# 25. 404 CLEANUP

Removed route gets intentional 404/redirect, not broken lazy chunk.

---

# 26. DUPLICATE UI AUDIT

Find old/new versions of:

- lesson page;
- speaking page;
- admin editor;
- dashboard;
- scenario view.

One active route/component owner.

---

# 27. PRESENTATION DUPLICATE

If duplicate UI wraps same engine:

remove old wrapper after route migration/test.

---

# 28. HIDDEN DOMAIN LOGIC IN LEGACY UI

Before deleting old component:

ensure any unique domain logic moved to canonical engine.

P13 rule.

---

# 29. LEGACY STORE AUDIT

Identify old:

- Redux/store slices;
- localStorage keys;
- IndexedDB stores;
- singleton services.

---

# 30. STORE MIGRATION

Migrate required data before removing old store reader/writer.

---

# 31. LEGACY STORAGE KEY

Options:

- migrate once;
- read fallback for support window;
- remove after verified cutoff.

---

# 32. STORAGE KEY CLEANUP

Do not remove unknown user data until migration evidence exists.

---

# 33. OLD INDEXEDDB STORE

Dropping store is schema migration.

Needs P14 tests.

---

# 34. OLD CACHE AUDIT

Remove obsolete service worker cache names after safe update.

---

# 35. CACHE COMPATIBILITY WINDOW

Old clients may still use old cache.

Avoid deleting server asset immediately if old tabs need it during rollout.

P17 deployment policy coordinates.

---

# 36. LEGACY API AUDIT

Find:

- deprecated endpoint;
- old request shape;
- duplicate client;
- obsolete adapter.

---

# 37. API CONSUMER MAP

Before endpoint removal:

all callers migrated.

---

# 38. API DEPRECATION

If external consumer may exist:

use formal deprecation window.

If purely internal and all callers proven migrated:

remove after tests.

---

# 39. ADAPTER RETIREMENT

Compatibility adapter can be removed when:

- all active data migrated;
- no caller remains;
- old supported version window ended;
- regression passes.

---

# 40. LEGACY AI PATH

Audit direct model calls.

There should be one P10-governed facade/contract.

Remove bypass paths.

---

# 41. LEGACY SCENARIO CHAT

Static/free chat path that bypasses P11 state engine:

migrate or retire.

---

# 42. LEGACY ASSESSMENT PATH

Any old evaluator that bypasses P4:

retire before RC.

---

# 43. LEGACY AUTHORING PATH

Direct production JSON editor/bypass publish:

remove/lock behind expert recovery if still needed.

---

# 44. LEGACY SERVICE WORKER

Exactly one registered production worker strategy.

Unregister old scopes if safe.

---

# 45. LEGACY FEATURE FLAG

For each flag:

- permanent ON?
- permanent OFF?
- still rollout?
- emergency kill switch?

Remove stale flags.

---

# 46. FLAG PERMANENT ON

Fold into code after evidence.

---

# 47. FLAG PERMANENT OFF

Remove code path if no compatibility need.

---

# 48. KILL SWITCH FLAG

Keep intentionally.

Document owner/default.

---

# 49. FLAG DEPENDENCY

Avoid nested stale flag combinations.

---

# 50. CONFIG CLEANUP

Inventory:

- env vars;
- config files;
- build flags;
- runtime flags.

Remove obsolete.

---

# 51. SECRET CLEANUP

Remove unused secrets from environment/secret store.

Rotate if historical leakage suspected.

---

# 52. DEFAULT CONFIG FREEZE

RC records exact safe defaults.

---

# 53. CONFIG VALIDATION

No unknown/unused critical variable silently accepted.

---

# 54. ENVIRONMENT PARITY REVIEW

Document deliberate differences:

preview/staging/production.

P17 must know.

---

# 55. DEPENDENCY CLEANUP

Inventory direct dependencies.

For each:

- used?
- duplicated?
- deprecated?
- vulnerable?
- heavy?
- build-only?

---

# 56. UNUSED DEPENDENCY

Remove + build/test.

---

# 57. DUPLICATE LIBRARY

Examples:

two date libs;
two icon sets;
two state clients

may be debt.

Remove only if safe and worth release risk.

Do not refactor broadly for aesthetics at RC.

---

# 58. DEPRECATED DEPENDENCY

Upgrade/remove if release risk justifies.

Major refactor deferred if safer and non-blocking with documented debt.

---

# 59. SECURITY DEPENDENCY

No release-blocking vulnerability remains.

---

# 60. LOCKFILE FREEZE

RC lockfile is part of candidate identity.

No casual package update after freeze.

---

# 61. TOOLCHAIN FREEZE

Record:

runtime;
package manager;
build tool;
critical generators.

---

# 62. GENERATED FILE AUDIT

Determine which generated artifacts should be committed vs built.

No hand-edited generated truth.

---

# 63. STALE GENERATED ARTIFACT

Regenerate and compare.

---

# 64. DERIVED INDEX

Ensure generated from canonical snapshot.

No manual divergence.

---

# 65. GENERATED MANIFEST

Record generator revision/tool if relevant.

---

# 66. BUILD WARNING AUDIT

Classify:

- release blocking;
- actionable debt;
- benign known.

Do not ship with unexplained severe warnings.

---

# 67. TYPE ERROR

Production build should not ignore release-critical type errors.

---

# 68. LINT ERROR

Critical correctness/security lint errors resolved.

Pure style warnings may be deferred explicitly.

---

# 69. TODO/FIXME AUDIT

Search.

Classify each in critical scope.

Do not remove comments without solving issue.

---

# 70. `@ts-ignore` / SUPPRESSION AUDIT

Review suppressions in critical code.

Keep only justified.

---

# 71. CATCH-ALL ERROR SWALLOW

Remove unsafe empty catches in critical paths.

---

# 72. CONSOLE LOG AUDIT

Remove:

- secrets;
- noisy debug;
- huge payload logs.

Keep structured intentional logging.

---

# 73. DEBUG FLAG AUDIT

Production debug features disabled/restricted.

---

# 74. TEST-ONLY CODE

Ensure mocks/test bypass not shipped active in production.

---

# 75. DEMO DATA

No demo/test learner data in production canonical dataset unless intentionally public sample.

---

# 76. PLACEHOLDER TEXT

Remove accidental:

Lorem ipsum;
TODO;
test@example;
dummy IDs

from learner-facing production content unless explicit example.

---

# 77. DEAD ASSET AUDIT

Remove unused:

- images;
- audio;
- videos;
- fonts;
- icons;
- bundles

when safe.

---

# 78. ASSET REFERENCE CHECK

Before removal:

search manifest/content/dynamic refs.

---

# 79. LARGE UNUSED ASSET

Priority cleanup due bundle/storage.

---

# 80. MEDIA DUPLICATE

Use canonical media ID/file where semantics identical.

---

# 81. FONT CLEANUP

Keep only required weights/styles.

Do not break Cyrillic/Vietnamese glyph support.

---

# 82. CSS CLEANUP

Remove obsolete legacy styles after visual regression.

---

# 83. GLOBAL CSS RISK

Do not perform broad selector rewrite late unless defect requires.

---

# 84. COMPONENT DEBT

Remove duplicate components where:

- behavior same;
- migration small;
- regression covered.

Avoid large design-system rewrite at RC.

---

# 85. DEAD EXPORT

Remove unused module exports if safe.

---

# 86. CIRCULAR DEPENDENCY

Resolve release-relevant cycles causing:

- initialization risk;
- bundle duplication;
- test fragility.

---

# 87. BUNDLE DUPLICATION

Inspect duplicated large libraries/chunks.

Optimize only if P14/P15 shows impact.

---

# 88. CODE SPLIT REVIEW

Ensure cleanup did not merge heavy admin code into learner bundle.

---

# 89. SOURCE MAP POLICY FREEZE

Production policy documented.

---

# 90. MINIFICATION

Production build expected minification/tree-shaking configured.

Do not prioritize tiny size over debuggability/security.

---

# 91. SECURITY HEADER FREEZE

Final expected headers/config handed to P17.

---

# 92. CSP FREEZE

Record exact intended production CSP.

P17 verifies actual deployed header.

---

# 93. CORS FREEZE

Record intended origins.

---

# 94. AUTH CALLBACK FREEZE

Production callback/redirect settings documented.

---

# 95. DOMAIN / ORIGIN MAP

P17 receives:

- frontend;
- API;
- media;
- OAuth;
- CDN

expected origins.

---

# 96. DATABASE MIGRATION FREEZE

All required migrations finalized.

No experimental migration script left ambiguous.

---

# 97. MIGRATION ORDER

Explicit.

---

# 98. MIGRATION REVERSIBILITY

Document:

- reversible;
- forward-fix only;
- backup required.

---

# 99. DATA BACKFILL

Complete before RC if required for candidate behavior.

---

# 100. BACKFILL IDEMPOTENCY

Test.

---

# 101. OLD COLUMN / FIELD REMOVAL

Only after no supported code uses it.

If risky:

defer contraction post-release with debt record.

---

# 102. EXPAND-CONTRACT

Prefer safe staged schema retirement.

P16 may intentionally retain old field for one release if needed.

---

# 103. CONTENT SCHEMA FREEZE

P3/P12 schema revisions frozen for RC.

---

# 104. CONTENT SNAPSHOT FREEZE

Exact active snapshot from P15.

---

# 105. CONTENT CHANGES DURING P16

Only blocker/critical correction.

Requires:

new snapshot;
P15 affected revalidation.

---

# 106. CONTENT DEPRECATED CLEANUP

Remove from active packs/navigation, preserve historical resolution.

---

# 107. CONTENT ORPHAN CLEANUP

Only after graph/history confirms unused.

---

# 108. ALIAS CLEANUP

Remove alias only when no supported historic reference needs it.

---

# 109. MIGRATION CLEANUP

Old migration may remain for supported upgrade path.

Do not delete just because latest state is current.

---

# 110. MINIMUM SUPPORTED VERSION

Define supported upgrade baseline.

This determines which migrations/compatibility layers must remain.

---

# 111. OLD VERSION SUPPORT WINDOW

Project policy should be explicit.

P16 cannot guess.

---

# 112. PWA OLD CLIENT SUPPORT

If old installed clients may remain:

P17 rollout must serve compatible assets/update path.

---

# 113. BROWSER SUPPORT FREEZE

Record supported matrix from P15.

---

# 114. UNSUPPORTED BROWSER

P13/P17 message/fallback defined.

---

# 115. KNOWN LIMITATION REGISTER

Every non-blocking limitation has:

- ID;
- description;
- affected users;
- workaround;
- severity;
- owner;
- post-release plan.

---

# 116. TECHNICAL DEBT REGISTER

Separate from user-visible known limitations.

---

# 117. DEBT OWNER

Each deferred debt has owner.

No orphan TODO.

---

# 118. DEBT PRIORITY

`NEXT_RELEASE`

`BACKLOG`

`MONITOR`

`INTENTIONAL`.

---

# 119. DEBT EXPIRY

Some compatibility debt has explicit removal trigger.

---

# 120. RELEASE NOTE CANDIDATES

Collect from:

- P15 fixes;
- behavior changes;
- migration;
- known limitations.

---

# 121. RELEASE NOTE STYLE

User-facing:

what changed;
what matters.

Technical details separate.

---

# 122. BREAKING CHANGE

If any:

explicit.

P17 deployment must account.

---

# 123. MIGRATION NOTE

Document user/admin impact.

---

# 124. OFFLINE UPDATE NOTE

If pack/cache reset required:

state clearly.

---

# 125. SECURITY NOTE

Do not expose exploit details unnecessarily before/at release.

Internal security record separate.

---

# 126. DOCUMENTATION INVENTORY

Required operator/developer docs:

- architecture overview;
- source-of-truth map;
- setup;
- env/config;
- migration;
- offline/cache;
- backup/restore;
- rollback;
- release;
- known limitations.

---

# 127. README CLEANUP

Remove stale setup instructions.

---

# 128. ENV EXAMPLE

Contains placeholders only.

No real secret.

---

# 129. SETUP REPRODUCTION

Fresh environment can install/build/test using docs.

---

# 130. BUILD COMMAND

One canonical documented path.

---

# 131. TEST COMMAND

Document quick vs full suites.

---

# 132. CONTENT BUILD COMMAND

Canonical.

---

# 133. MIGRATION COMMAND

Canonical and safety notes.

---

# 134. RELEASE COMMAND / WORKFLOW

P17 consumes.

P16 does not necessarily execute production deploy.

---

# 135. RUNBOOKS

At minimum:

- rollback;
- restore;
- content emergency block;
- AI outage;
- service worker/update issue.

---

# 136. ON-CALL / OWNER

If project has no formal on-call:

document maintainer/owner concept without inventing organization.

---

# 137. RC MANIFEST

Create machine/human-readable RC manifest containing:

- RC ID;
- source SHA;
- content snapshot;
- lockfile hash;
- build artifact ID/hash;
- schema versions;
- migration set;
- browser support;
- known limitations;
- rollback target;
- P15 acceptance report reference.

---

# 138. RC ID

Stable identifier.

Example format may include date/build, but avoid manual ambiguity.

---

# 139. RC IMMUTABILITY

Once declared:

RC manifest does not change.

A fix produces RC2/new manifest.

---

# 140. RC TAG

Repository tag/branch may mark candidate if workflow uses Git.

Do not move tag after freeze.

---

# 141. SIGNED TAG

Optional if repo policy supports.

Not mandatory.

---

# 142. RC BRANCH

If used:

protected from feature merges.

---

# 143. RELEASE ARTIFACT

Build from exact RC source.

---

# 144. ARTIFACT HASH

Record where feasible.

---

# 145. CONTENT MANIFEST HASH

Record.

---

# 146. LOCKFILE HASH

Record.

---

# 147. CONFIG PROFILE ID

Record non-secret config revision/profile.

Do not put secret values in manifest.

---

# 148. MIGRATION MANIFEST

List required migrations.

---

# 149. FEATURE FLAG MANIFEST

List flags + intended production values.

---

# 150. EXTERNAL DEPENDENCY MANIFEST

AI/API/CDN/auth dependencies + expected endpoints/config IDs.

---

# 151. ROLLBACK TARGET

Exact last known-good:

- SHA;
- content snapshot;
- compatible DB/schema state;
- deployment artifact if available.

---

# 152. ROLLBACK LIMITATION

If DB migration irreversible:

document restore/forward-fix plan.

---

# 153. ROLLBACK DRILL

P15 evidence should exist.

If P16 cleanup changes rollback path:

rerun.

---

# 154. RELEASE FREEZE

Freeze categories:

- code;
- content;
- schema;
- dependencies;
- config;
- translations.

Only release-blocking fixes after freeze.

---

# 155. FREEZE EXCEPTION

Requires:

- issue ID;
- reason;
- minimal diff;
- affected tests;
- new RC identity.

---

# 156. RC CHANGE CONTROL

Any change after RC:

new RC revision.

No silent artifact replacement.

---

# 157. REPRODUCIBLE BUILD CHECK

Fresh clean checkout/build should produce functionally identical candidate.

---

# 158. CLEAN ROOM BUILD

Use no developer machine hidden state.

---

# 159. BUILD CACHE

Can be used if deterministic/integrity verified.

For forensic RC proof, at least one clean build is valuable.

---

# 160. UNTRACKED FILE AUDIT

Check required build does not rely on untracked local files.

---

# 161. GIT DIRTY CHECK

RC source tree clean.

---

# 162. GENERATED SOURCE CHECK

Generated files up to date.

---

# 163. SUBMODULE / EXTERNAL SOURCE

If any, pin exact revision.

---

# 164. PACKAGE REGISTRY

Lockfile/resolved integrity intact.

---

# 165. NODE/RUNTIME VERSION

Recorded.

---

# 166. ENVIRONMENT SECRET PRESENCE

P16 verifies required secret names exist in target configuration, not values.

P17 checks actual deploy.

---

# 167. OPTIONAL ENV

Document defaults.

---

# 168. CONFIG UNKNOWN KEY

Warn/fail according P14 config schema.

---

# 169. RELEASE BUILD MODE

Ensure production mode optimizations/security toggles active.

---

# 170. DEV-ONLY CODE

Not reachable in production.

---

# 171. TEST BYPASS

Disabled.

---

# 172. MOCK PROVIDER

Production points to intended real/fallback provider config, not CI mock.

---

# 173. ANALYTICS DEBUG

No verbose debug mode.

---

# 174. SOURCE MAP ACCESS

Final policy.

---

# 175. ERROR REPORT ENDPOINT

Configured.

---

# 176. HEALTH CHECK

Configured.

---

# 177. OBSERVABILITY VERSION TAG

Logs/errors identify RC/release.

---

# 178. CONTENT SNAPSHOT TAG

Logs identify active content snapshot.

---

# 179. MIGRATION OBSERVABILITY

Can detect migration failure during P17 deploy.

---

# 180. FEATURE KILL SWITCH READINESS

Document how to disable:

- AI;
- bad scenario family;
- bad content snapshot;
- optional heavy feature

where supported.

---

# 181. KILL SWITCH AUTHORIZATION

Privileged and auditable.

---

# 182. CONTENT ROLLBACK READINESS

P12 snapshot rollback route documented.

---

# 183. SERVICE WORKER EMERGENCY RECOVERY

Runbook for bad cached release:

- new fixed worker;
- cache invalidation strategy;
- user recovery instruction if necessary.

---

# 184. OLD ASSET RETENTION

During deploy, retain assets long enough for old tabs/worker if platform strategy requires.

P17 enforces.

---

# 185. CHUNK COMPATIBILITY

Avoid immediate deletion causing old-tab chunk 404 if deploy platform can retain.

---

# 186. CDN INVALIDATION

Document when needed.

Do not purge immutable hashed assets unnecessarily.

---

# 187. CACHE CONTROL FREEZE

Expected headers per resource.

P17 verifies actual.

---

# 188. DNS/TLS

P17 production validation, but P16 records expected domain/certificate ownership if known.

---

# 189. OAUTH PRODUCTION CONFIG

Expected client/callback identifiers documented without secrets.

---

# 190. DATABASE PRODUCTION CONFIG

Expected database/branch/environment identity documented without credentials.

---

# 191. PREVIEW CONFIG CLEANUP

No preview callback/domain accidentally shipped as production default.

---

# 192. FEATURE FLAG DEFAULT PRODUCTION

Explicit.

---

# 193. ADMIN ACCESS POLICY

Document intended production roles.

---

# 194. CONTENT AUTHORING PRODUCTION POLICY

Direct production editing disabled/governed according P12.

---

# 195. DEMO / SEED ACCOUNT

No insecure default admin credential.

---

# 196. TEST ACCOUNT

Remove/disable production test accounts unless intentionally managed.

---

# 197. SEED DATA

Production seed must not overwrite real data on deploy.

---

# 198. MIGRATION SEED SEPARATION

Schema migration is not demo-data reset.

---

# 199. BACKUP BEFORE RELEASE

If DB/content change risk warrants:

P17 runbook includes latest backup/snapshot checkpoint.

---

# 200. BACKUP ID

Record in release evidence if performed.

---

# 201. RC VALIDATION AFTER CLEANUP

Every P16 runtime-affecting cleanup triggers affected P15 tests.

---

# 202. PURE DOCUMENTATION CHANGE

Does not require full P15 re-run, unless release commands/config semantics changed.

---

# 203. DEAD CODE REMOVAL TEST

At minimum build + relevant smoke.

---

# 204. DEPENDENCY REMOVAL TEST

Build + affected runtime.

---

# 205. FEATURE FLAG REMOVAL TEST

Both former branches considered; intended active behavior tested.

---

# 206. ROUTE REMOVAL TEST

Old link redirect/404 + new route.

---

# 207. STORAGE COMPATIBILITY REMOVAL TEST

Supported old state migration still passes.

---

# 208. CACHE CLEANUP TEST

Old client/update path still passes.

---

# 209. API REMOVAL TEST

No active caller.

---

# 210. WARNING CLEANUP TEST

Do not “fix” warning by suppressing real error.

---

# 211. P16 DOES NOT CHASE ZERO WARNINGS BLINDLY

A known benign third-party warning can remain documented.

Focus on meaningful debt.

---

# 212. CODE BEAUTIFICATION BOUNDARY

Formatting/refactor with no release value is deferred during RC unless it reduces risk.

---

# 213. ARCHITECTURAL REWRITE BOUNDARY

No major rewrite in P16.

If architecture still needs rewrite to be safe:

return to earlier phase, not RC freeze.

---

# 214. FEATURE REQUEST DURING P16

Record backlog.

Do not implement unless release-blocking requirement was missing.

---

# 215. CONTENT ENRICHMENT DURING P16

Defer.

Only correctness/blocker fixes.

---

# 216. UI POLISH DURING P16

Only critical/high usability fixes.

Cosmetic polish deferred.

---

# 217. DEBT BURNDOWN REPORT

Summarize:

- opened by P15;
- closed;
- deferred;
- intentional compatibility.

---

# 218. LEGACY BURNDOWN REPORT

Summarize each removed/kept path.

---

# 219. DUPLICATE OWNER REPORT

Final list should show:

critical responsibility

→ canonical owner

→ duplicate path status.

---

# 220. ROUTE MAP FINAL

Final active learner/admin routes.

---

# 221. DATA OWNER MAP FINAL

Final:

content;
learner state;
SRS;
scenario;
AI;
authoring;
cache/storage.

---

# 222. STORAGE MAP FINAL

What is stored where.

---

# 223. CACHE MAP FINAL

Cache names/owners/lifecycle.

---

# 224. FEATURE FLAG MAP FINAL

Only intentional flags remain.

---

# 225. DEPENDENCY MAP FINAL

Direct production dependencies + purpose.

---

# 226. ENV MAP FINAL

Required environment variables + public/private classification.

No values.

---

# 227. MIGRATION MAP FINAL

Supported old versions → RC.

---

# 228. CONTENT SNAPSHOT MAP FINAL

RC content snapshot + schema.

---

# 229. TEST SUITE MAP FINAL

Which suite runs:

PR;
main;
RC;
post-deploy smoke.

---

# 230. OPERATIONS MAP FINAL

Monitor;
alert;
rollback;
backup.

---

# 231. DOCUMENTATION CONSISTENCY

Docs must match actual commands/paths.

Test by fresh setup where possible.

---

# 232. BROKEN LINK DOC AUDIT

No dead internal links in critical runbooks.

---

# 233. STALE SCREENSHOT DOC

Avoid relying on old screenshot for critical release action if UI changed.

---

# 234. RUNBOOK DRY RUN

Walk through:

- deploy preview;
- migration;
- rollback;
- content block.

---

# 235. RELEASE CHECKLIST

Machine/human checklist derived from RC manifest and P17 handoff.

---

# 236. CHECKLIST ≠ EVIDENCE

Each critical item links actual evidence.

---

# 237. OWNER ACKNOWLEDGEMENT

If multiple maintainers:

responsible owners acknowledge unresolved risks.

If single maintainer:

document explicitly; do not invent signatories.

---

# 238. FINAL KNOWN RISK REVIEW

Review each residual risk:

- still non-blocking?
- mitigation valid?
- changed since P15?

---

# 239. RISK ESCALATION

If new evidence makes risk critical:

unfreeze;
fix;
P15 revalidate.

---

# 240. RELEASE NOTE FINALIZATION

Separate:

### Learner-facing
what changed.

### Admin/maintainer
migration/config/known issues.

---

# 241. CHANGELOG

Use meaningful changes, not every commit.

---

# 242. VERSION LABEL

Internal RC/release identity may exist without cluttering learner UI.

Do not expose internal version unless product needs it.

---

# 243. BUILD ID DEBUG

May be available in admin/about/debug view.

Not prominent learner content.

---

# 244. RC SMOKE AFTER FREEZE

Run exact frozen artifact:

- app open;
- subject open;
- lesson;
- review;
- one write;
- one media;
- admin protected route;
- content snapshot.

---

# 245. RC OFFLINE SMOKE

Install/cache current pack

→ offline lesson/review

→ reconnect.

---

# 246. RC MIGRATION SMOKE

At least representative supported prior state.

---

# 247. RC SECURITY SMOKE

- no client secret;
- authorization;
- sanitizer fixture;
- security headers in staging/production-like.

---

# 248. RC PERFORMANCE SMOKE

No regression after cleanup.

---

# 249. RC ACCESSIBILITY SMOKE

Core keyboard journey.

---

# 250. RC ROLLBACK SMOKE

Verify rollback target/reference still valid.

---

# 251. RC HASH VERIFICATION

Manifest hashes match artifact.

---

# 252. P17 INPUT PACKAGE

P16 hands off:

- RC manifest;
- source SHA/tag;
- build artifact;
- content snapshot;
- lockfile hash;
- migration manifest;
- environment/config schema;
- feature flags;
- security headers/CSP expected;
- domain/origin map;
- known limitations;
- release notes;
- rollback target;
- backup requirement;
- monitoring/alert plan;
- P15 acceptance evidence.

---

# 253. P17 AUTHORITY BOUNDARY

P17 may:

- deploy;
- migrate;
- activate;
- verify;
- observe;
- rollback.

P17 must not redesign/fix broad architecture during release.

If blocker appears:

rollback/fix upstream/new RC.

---

# 254. PRODUCTION CHANGE WINDOW

If project uses a release window:

P16 documents prerequisites.

Do not invent operational organization.

---

# 255. POST-DEPLOY SMOKE PLAN

P16 defines exact smoke P17 will run.

---

# 256. POST-DEPLOY OBSERVATION PLAN

Metrics/signals:

- startup errors;
- API errors;
- migration;
- content load;
- sync;
- AI optional health;
- performance.

---

# 257. ROLLBACK TRIGGERS

Predefine examples:

- data corruption;
- auth failure;
- widespread blank app;
- content snapshot broken;
- official submissions fail;
- severe security issue.

---

# 258. FORWARD-FIX VS ROLLBACK

For each migration class note whether rollback safe.

P17 chooses according runbook/evidence.

---

# 259. P16 PILOT

Before full cleanup, trial on a representative legacy slice:

- one duplicate route;
- one stale flag;
- one unused dependency;
- one compatibility shim.

Prove inventory → removal → regression workflow.

---

# 260. PILOT ACCEPTANCE

Must demonstrate:

- evidence item unused/replaced;
- clean removal;
- build green;
- relevant P15 tests green;
- rollback/revert possible.

---

# 261. CLEANUP ORDER

Recommended:

1. Freeze baseline candidate identity.
2. Inventory legacy/debt.
3. Resolve duplicate owners.
4. Remove unsafe bypass paths.
5. Remove stale flags/config/secrets.
6. Remove dead routes/components.
7. Remove unused dependencies/assets.
8. Close release-critical warnings/TODOs.
9. Freeze migrations/schema/content.
10. Finalize docs/runbooks.
11. Build clean RC.
12. Rerun P15 affected gates.
13. Create immutable RC manifest.
14. P17 handoff.

---

# 262. WHY DUPLICATE OWNERS FIRST

Duplicate writer paths threaten integrity more than unused CSS.

Prioritize by risk, not cosmetic cleanliness.

---

# 263. WHY DOCS BEFORE P17

Production deployment without accurate migration/rollback docs is not release-ready.

---

# 264. WHY FREEZE AFTER CLEANUP

Cleaning after freeze would invalidate acceptance.

Freeze only when runtime-affecting cleanup complete.

---

# 265. P16 TEST MATRIX — LEGACY

Test:

- old route;
- old storage;
- old API;
- old flags;
- old service worker;
- historical state.

---

# 266. TEST MATRIX — DEBT

Test affected:

- dependency removal;
- warnings;
- suppressions;
- duplicate stores.

---

# 267. TEST MATRIX — RC

Test:

- clean build;
- exact snapshot;
- install;
- migration;
- offline;
- security;
- rollback.

---

# 268. TEST MATRIX — DOCS

Fresh setup commands.

Runbook steps.

---

# 269. TEST MATRIX — MANIFEST

All IDs/hashes resolve.

---

# 270. LEGACY RETIREMENT BLOCKER

Cannot remove if:

- active caller exists;
- supported historic state depends;
- rollback depends;
- P15 evidence shows use;
- replacement not tested.

---

# 271. TECHNICAL DEBT BLOCKER

P16 cannot freeze if debt creates:

- data integrity ambiguity;
- security critical;
- migration uncertainty;
- duplicate source of truth;
- production deploy ambiguity.

---

# 272. RC FREEZE BLOCKER

Cannot freeze if:

- SHA dirty/unknown;
- snapshot unknown;
- lockfile changed after tests;
- migrations not final;
- blocker defect open;
- rollback target unknown;
- acceptance evidence stale.

---

# 273. P16 FAIL CONDITIONS

P16 FAIL if:

- known duplicate canonical writer remains;
- active legacy route bypasses new architecture;
- production feature flag state ambiguous;
- unused secret/config with security risk remains;
- release-critical TODO/suppression unexplained;
- generated artifacts stale;
- content snapshot not frozen;
- migration set not frozen;
- build not reproducible enough for release;
- RC artifact identity unknown;
- rollback target incompatible;
- P15 evidence invalidated without retest;
- runbooks stale;
- P17 handoff incomplete.

---

# 274. P16 PASS CONDITIONS

P16 PASS when:

1. P15 mandatory gates are valid for final RC.
2. Exact source SHA is frozen.
3. Exact content snapshot is frozen.
4. Lockfile/toolchain identity is frozen.
5. Required migrations are frozen.
6. Critical responsibility owners are singular.
7. Duplicate write paths are eliminated.
8. Legacy routes/APIs are retired or intentionally compatible.
9. Old storage/cache paths have safe migration/retirement.
10. AI bypass paths are removed.
11. Scenario bypass paths are removed.
12. Assessment bypass paths are removed.
13. Authoring production bypasses are removed/controlled.
14. Stale feature flags are cleaned.
15. Obsolete config/secrets are cleaned.
16. Release-blocking dependency/security debt is closed.
17. Dead large assets/dependencies are removed where safe.
18. Generated indexes/manifests are current.
19. Release-critical warnings/TODOs are resolved or documented.
20. Known limitations register is complete.
21. Technical debt register is complete.
22. Setup/build/test docs match reality.
23. Migration/rollback runbooks are current.
24. Clean-room RC build succeeds.
25. Affected P15 suites pass after cleanup.
26. RC smoke/offline/security/performance checks pass.
27. RC manifest is immutable and complete.
28. Rollback target is exact and verified.
29. Release notes are prepared.
30. P17 receives complete deployment/verification package.

---

# 275. P16 PROMPT COMPLETENESS GATE

P16 prompt is structurally complete only if it covers:

1. entry gate;
2. legacy inventory;
3. debt classification;
4. canonical owner audit;
5. route retirement;
6. UI/store/API retirement;
7. AI/scenario/assessment/authoring bypass removal;
8. service-worker/cache legacy;
9. feature flags;
10. config/secrets;
11. dependencies;
12. generated artifacts;
13. warnings/TODO/suppressions;
14. dead assets;
15. schema/migrations;
16. content snapshot;
17. compatibility window;
18. known limitations;
19. documentation/runbooks;
20. RC manifest;
21. source/content/lock/config hashes;
22. freeze/change control;
23. clean-room build;
24. rollback target;
25. post-cleanup revalidation;
26. release notes;
27. post-deploy smoke plan;
28. rollback triggers;
29. P17 handoff;
30. PASS/FAIL gates.

If all are defined:

`P16 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P16 cleanup/freezing has PASSed.

---

# 276. REQUIRED DELIVERABLES — LEGACY/DEBT

Create/maintain:

`subjects/russian/docs/p16/RUSSIAN_P16_EXECUTIVE_SUMMARY.md`

`RUSSIAN_LEGACY_INVENTORY.md`

`RUSSIAN_CANONICAL_OWNER_FINAL_MAP.md`

`RUSSIAN_ROUTE_API_RETIREMENT_MAP.md`

`RUSSIAN_STORAGE_CACHE_RETIREMENT_MAP.md`

`RUSSIAN_FEATURE_FLAG_FINAL_MAP.md`

`RUSSIAN_TECHNICAL_DEBT_REGISTER.md`

`RUSSIAN_DEPENDENCY_FINAL_AUDIT.md`.

---

# 277. REQUIRED DELIVERABLES — RC

Create:

`RUSSIAN_RC_MANIFEST.json`

`RUSSIAN_RC_CONTENT_MANIFEST.md`

`RUSSIAN_RC_MIGRATION_MANIFEST.md`

`RUSSIAN_RC_CONFIG_ENV_SCHEMA.md`

`RUSSIAN_RC_KNOWN_LIMITATIONS.md`

`RUSSIAN_RC_RELEASE_NOTES.md`

`RUSSIAN_RC_ROLLBACK_RUNBOOK.md`

`RUSSIAN_RC_POST_DEPLOY_SMOKE_PLAN.md`

`RUSSIAN_RC_OBSERVATION_PLAN.md`.

---

# 278. REQUIRED DELIVERABLES — EVIDENCE

Create:

`RUSSIAN_P16_CLEANUP_REGRESSION_REPORT.md`

`RUSSIAN_P16_CLEAN_BUILD_REPORT.md`

`RUSSIAN_P16_RC_SMOKE_REPORT.md`

`RUSSIAN_P16_RISK_REGISTER.json`

`RUSSIAN_P16_EVIDENCE_INDEX.md`

`RUSSIAN_P17_INPUT_CONTRACT.md`.

No empty ceremonial documents.

---

# 279. FINAL RESPONSE FORMAT

When P16 implementation completes:

`P16 STATUS: PASS / FAIL / BLOCKED`

`RC ID:`

`Source SHA/tag:`

`Content snapshot:`

`Lockfile hash:`

`Build artifact:`

`Schema versions:`

`Migration set:`

`Duplicate owners: 0 / unresolved`

`Legacy bypass paths: 0 / unresolved`

`Stale feature flags: 0 / unresolved`

`Release-blocking debt: 0 / unresolved`

`Known non-blocking debt:`

`Known limitations:`

`Clean build: PASS / FAIL`

`P15 revalidation after cleanup: PASS / FAIL`

`Offline smoke: PASS / FAIL`

`Security smoke: PASS / FAIL`

`Performance smoke: PASS / FAIL`

`Rollback target verified: PASS / FAIL`

`RC manifest: COMPLETE / INCOMPLETE`

`P17 readiness: READY / NOT READY`

End:

**P16 LEGACY RETIREMENT · TECHNICAL DEBT CLOSURE · RELEASE CANDIDATE FREEZE COMPLETE**

---

# 280. EXECUTION RULE

When authorized:

`load exact P15 accepted candidate`

→ `inventory legacy/debt using evidence`

→ `resolve duplicate owners/bypasses first`

→ `retire old routes/stores/APIs safely`

→ `clean stale flags/config/secrets`

→ `remove safe unused dependencies/assets`

→ `close release-critical warnings/TODOs`

→ `freeze schema/migrations/content`

→ `fresh clean build`

→ `rerun affected P15 gates`

→ `finalize docs/runbooks`

→ `create immutable RC manifest`

→ `verify rollback target`

→ `prepare P17 deployment package`.

No unrelated feature work.

---

# 281. FINAL P16 PRINCIPLE

P16 succeeds only when the system has stopped being a collection of historical implementations and has become one release candidate with one explainable active path.

For every legacy/debt item ask:

1. Is it still called?
2. Is it still needed for supported history?
3. Does another owner already replace it?
4. Can it mutate canonical state?
5. What breaks if removed?
6. Which test proves removal safe?
7. Does rollback still need it?
8. Does an old installed client still need it?
9. Is keeping it riskier than removing it?
10. If deferred, who owns its removal?

For the RC ask:

1. Which exact SHA?
2. Which exact content snapshot?
3. Which exact lockfile/toolchain?
4. Which migrations?
5. Which production flags/config profile?
6. Which known limitations?
7. Which rollback target?
8. Which P15 evidence proves it?
9. Which smoke does P17 run?
10. What condition forces rollback?

If any of these are ambiguous:

the release candidate is not frozen.

**ONE OWNER.**
**ONE ACTIVE PATH.**
**NO HIDDEN LEGACY BYPASS.**
**NO MOVING RC.**
**FREEZE WHAT WAS ACTUALLY TESTED.**
**HAND P17 AN EXACT, ROLLBACK-SAFE CANDIDATE.**


---

# P16 HARDENING ADDENDUM
## FINAL COMPLETENESS PASS BEFORE P17

This addendum closes the last Release Candidate edge cases that often appear only at the boundary between a frozen candidate and a real production deployment.

It does not deploy anything.

---

# 282. RC ARTIFACT PROMOTION

Production must receive the exact artifact accepted by P15/P16 where the platform supports artifact promotion.

Avoid:

accepted source

→ rebuild differently at production

if the build can instead promote the verified artifact.

If rebuilding is unavoidable:

toolchain/config identity and integrity must be revalidated.

---

# 283. BUILD-TIME VS RUNTIME CONFIG

Separate:

`BUILD_TIME_CONFIG`

from:

`RUNTIME_CONFIG`.

A runtime variable change after RC can materially change behavior even if SHA is identical.

Therefore P17 handoff records both.

---

# 284. CONFIG FREEZE HASH

Create a non-secret normalized configuration fingerprint where practical.

Never include secret values.

This helps detect configuration drift between acceptance and production.

---

# 285. SECRET PRESENCE CHECK ≠ SECRET VALUE RECORD

P16 may verify:

required secret exists.

It must not write secret value into:

- RC manifest;
- logs;
- Markdown;
- release notes.

---

# 286. ENVIRONMENT DRIFT GATE

Before P17:

compare expected production config profile with staging/accepted profile.

Classify differences:

`EXPECTED`

`RISK_REVIEW_REQUIRED`

`BLOCKING`.

---

# 287. PRODUCTION DATABASE IDENTITY

P17 input must identify the intended production database/project/branch logically without exposing credentials.

Do not deploy migration against an ambiguous database target.

---

# 288. DATABASE MIGRATION LOCK READINESS

If migration can run concurrently from multiple deploy instances:

P16 must define the locking/one-run mechanism.

P17 must not guess.

---

# 289. DATABASE MIGRATION PRECHECK

Define before production:

- current schema version;
- expected predecessor version;
- migration prerequisites;
- backup/snapshot requirement;
- estimated operational impact if known.

---

# 290. FORWARD-ONLY MIGRATION

If migration is not safely reversible:

RC manifest must mark:

`FORWARD_ONLY`.

Rollback then may require:

- application compatibility with new schema;
- restore from backup;
- forward fix.

Do not label normal code rollback as sufficient.

---

# 291. EXPAND-CONTRACT RELEASE BOUNDARY

If old and new app versions may coexist during rollout:

database/schema changes must support both until rollout complete.

P17 must know when contraction is safe.

---

# 292. CONTENT ACTIVATION ORDER

If release includes:

application build

+ content snapshot,

P16 defines the compatibility order:

- app first;
- content first;
- atomic activation;
- dual-compatible period.

Do not improvise at deploy time.

---

# 293. FEATURE FLAG ACTIVATION ORDER

A feature can be:

deployed disabled

→ smoke tested

→ enabled.

If this is the intended strategy, manifest must say so.

---

# 294. AUTH/OAUTH PRODUCTION READINESS

Before P17, record expected:

- client/app identifier;
- callback URL;
- allowed origin;
- logout URL if relevant.

No secret values.

---

# 295. CALLBACK MISMATCH BLOCKER

If production callback/origin differs from accepted config and has not been verified:

P17 readiness is NOT READY.

---

# 296. DNS READINESS

Record expected:

- production host;
- required records;
- target platform/domain.

P17 verifies actual DNS resolution.

P16 does not modify DNS unless release workflow explicitly includes it.

---

# 297. TLS READINESS

Record:

- expected HTTPS domain;
- certificate handling model/platform;
- HSTS expectations if applicable.

P17 verifies actual certificate/HTTPS.

---

# 298. CDN READINESS

If CDN is used:

record:

- cache-control strategy;
- immutable assets;
- HTML/content invalidation rules.

P17 should not purge blindly.

---

# 299. OLD-ASSET RETENTION WINDOW

If old clients/tabs may request old hashed assets after deployment:

ensure platform retains them long enough or rollout strategy handles refresh.

---

# 300. SERVICE WORKER RELEASE BOUNDARY

P16 handoff must specify:

- current worker identity;
- new worker identity/build;
- activation strategy;
- incompatible cache names;
- emergency recovery.

---

# 301. BAD SERVICE WORKER ESCAPE HATCH

P17 must have a documented recovery method if new worker:

- crashes app shell;
- traps stale assets;
- loops updates;
- blocks content.

---

# 302. CONTENT PACK RELEASE BOUNDARY

If new pack format/version ships:

P17 must verify:

- manifest;
- checksum;
- download;
- old pack compatibility;
- cleanup path.

---

# 303. OFFLINE CLIENT UPGRADE PATH

Installed/offline clients must have a deterministic path from previous supported version to RC.

If not:

P16 cannot claim production readiness for PWA/offline support.

---

# 304. PRODUCTION DATA SEED BOUNDARY

P17 must never run destructive development seed/reset.

P16 manifest lists:

`MIGRATIONS_ALLOWED`

and:

`SEED_RESET_FORBIDDEN`

where applicable.

---

# 305. PRE-DEPLOY BACKUP CHECKPOINT

If release changes persistent production data:

P17 input must define whether a backup/snapshot checkpoint is mandatory.

If mandatory and unavailable:

deployment blocked.

---

# 306. BACKUP RESTORE IDENTITY

Record backup/snapshot ID after it is created during release.

Do not include credentials.

---

# 307. RELEASE APPROVAL INPUTS

Before P17 can start, all required approval inputs should be explicit:

- P15 PASS;
- P16 PASS;
- RC manifest;
- rollback target;
- migration plan;
- production authority if required by project workflow.

No implicit “probably approved”.

---

# 308. RELEASE AUTHORITY SCOPE

Authority should bind to the exact RC SHA/artifact/snapshot where project process supports.

A materially changed RC requires renewed release decision.

---

# 309. PRODUCTION FREEZE VIOLATION

Any code/content/config change after final RC manifest creation triggers:

`RC INVALIDATED`.

Return to affected P15/P16 validation.

---

# 310. RELEASE MANIFEST IMMUTABILITY

Do not edit existing RC manifest to reflect a changed artifact.

Create a new RC manifest.

---

# 311. LAST-MINUTE HOTFIX

If a blocker appears immediately before production:

minimal fix

→ new SHA/artifact

→ impacted P15 regression

→ new P16 RC manifest

→ then P17.

No “just deploy this one-line fix”.

---

# 312. PRODUCTION SMOKE DATA

Define safe smoke test accounts/data.

Smoke tests must not:

- pollute learner production data;
- submit fake official work into real learner records;
- modify canonical content unintentionally.

---

# 313. PRODUCTION ADMIN SMOKE

Use privileged test only if safe.

Prefer read-only verification for production administration unless a controlled reversible action is defined.

---

# 314. PRODUCTION WRITE SMOKE

If testing real state write is necessary:

use isolated test account/entity.

Record cleanup.

Do not use real learner account.

---

# 315. CANARY READINESS

If platform supports gradual rollout:

P16 may define:

- canary percentage/group;
- observation period;
- rollback trigger.

Do not require canary if platform/workflow cannot support it.

---

# 316. BLUE/GREEN READINESS

If architecture uses blue/green:

record:

- active environment;
- candidate environment;
- switch method;
- rollback switch.

---

# 317. PREVIEW → PRODUCTION PROMOTION

If deployment platform supports promotion:

prefer promotion of tested artifact over fresh unverified build.

---

# 318. RELEASE TELEMETRY BASELINE

Before deploy, record recent normal baseline for:

- error rate;
- latency;
- availability;
- key journey failures

if observability exists.

Post-deploy comparison needs a reference.

---

# 319. FALSE ALERT BOUNDARY

P17 observation plan should distinguish:

- known baseline noise;
- release-induced regression.

Do not rollback because of unrelated pre-existing event.

---

# 320. ROLLBACK DECISION MATRIX

For each trigger define:

- automatic/manual;
- rollback code;
- rollback content;
- disable feature;
- forward-fix;
- restore DB.

Avoid one generic rollback for all failures.

---

# 321. CODE ROLLBACK

Safe only if new persistent schema remains compatible.

---

# 322. CONTENT ROLLBACK

May be sufficient when:

- bad lesson/assessment/source snapshot;
- app itself healthy.

---

# 323. FEATURE KILL SWITCH

May be preferred when:

- optional AI;
- scenario family;
- non-core feature

fails without state corruption.

---

# 324. DATABASE RESTORE

Highest impact.

Use only according to runbook/evidence.

Do not casually overwrite valid post-deploy user writes.

---

# 325. FORWARD FIX

May be safer than rollback after irreversible migration.

Must be explicitly known before release.

---

# 326. RELEASE STOP CONDITIONS

P17 must stop progression when:

- migration verification fails;
- app health fails;
- auth fails;
- content snapshot mismatches;
- official submission broken;
- data integrity uncertainty;
- serious security issue.

Do not continue “to see if it stabilizes”.

---

# 327. OBSERVATION WINDOW

P16 may define minimum observation phases rather than arbitrary one fixed duration:

- immediate;
- short-term;
- sustained.

Exact timing depends on traffic/usage and is P17 operational policy.

---

# 328. LOW TRAFFIC LIMITATION

If production has little usage:

absence of errors is weak evidence.

Use synthetic smoke + targeted checks.

---

# 329. REAL USER DATA PROTECTION DURING OBSERVATION

Diagnostics must not expose raw private learner content unnecessarily.

---

# 330. POST-DEPLOY CONTENT VERIFY

P17 verifies representative:

- lesson;
- vocab;
- assessment;
- scenario;
- search

against frozen snapshot.

---

# 331. POST-DEPLOY CACHE VERIFY

Verify response headers/cache behavior for:

- HTML;
- hashed assets;
- content;
- media;
- service worker.

---

# 332. POST-DEPLOY AUTH VERIFY

Verify:

- login;
- logout;
- protected admin route;
- role boundary.

---

# 333. POST-DEPLOY AI VERIFY

Optional AI feature:

- provider reachable;
- grounding path;
- no secret exposed.

AI failure alone need not rollback core release if kill switch/fallback works.

---

# 334. POST-DEPLOY OFFLINE VERIFY

If PWA/offline is supported:

- install/load;
- cache current pack;
- offline open;
- update path.

At least representative production verification.

---

# 335. POST-DEPLOY MIGRATION VERIFY

Check actual production schema/data version after migration.

Do not assume deployment command succeeded because exit code = 0.

---

# 336. POST-DEPLOY BACKUP VERIFY

If backup checkpoint taken:

confirm ID/status recorded.

---

# 337. POST-DEPLOY BUILD ID

Expose/read internal build ID through safe admin/debug endpoint or asset metadata where available.

Compare to RC.

---

# 338. POST-DEPLOY CONTENT ID

Compare active content snapshot ID to RC.

---

# 339. POST-DEPLOY CONFIG FINGERPRINT

Compare non-secret config fingerprint if architecture supports.

---

# 340. RELEASE DRIFT DETECTION

If deployed SHA/build/snapshot/config differs:

P17 FAIL until explained/corrected.

---

# 341. RC CLEANLINESS FINAL CHECK

Before handoff ensure:

- working tree clean;
- no untracked required file;
- generated assets current;
- manifest current;
- ZIP/artifact current.

---

# 342. P16 GOLDEN RC HANDOFF FIXTURES

Include scenarios:

- last-minute hotfix invalidates RC;
- migration marked forward-only;
- config drift;
- callback mismatch;
- bad service worker recovery;
- content-only rollback;
- optional AI kill switch;
- production smoke isolated account;
- artifact promotion mismatch;
- rollback decision selection.

---

# 343. P16 REVALIDATION TRIGGERS

P16 status becomes `NEEDS_REVALIDATION` if:

- source changes;
- content snapshot changes;
- lockfile/toolchain changes;
- migration changes;
- production config profile changes materially;
- P15 acceptance changes;
- rollback target becomes unavailable;
- release manifest changes.

---

# 344. P16 PROMPT COMPLETENESS GATE — HARDENED

P16 is fully hardened only if it covers:

1. exact artifact promotion;
2. build/runtime config;
3. config fingerprint/drift;
4. DB identity/migration lock;
5. forward-only migration;
6. app/content activation order;
7. feature flag activation;
8. OAuth callback/origin;
9. DNS/TLS/CDN;
10. service-worker release;
11. offline-client upgrade;
12. backup checkpoint;
13. release authority scope;
14. RC invalidation;
15. production smoke isolation;
16. canary/blue-green optionality;
17. telemetry baseline;
18. rollback decision matrix;
19. code/content/feature/DB rollback distinctions;
20. release stop conditions;
21. post-deploy verify contract;
22. release drift detection;
23. golden RC handoff;
24. P17 exact input package.

If all are defined:

`P16 PROMPT STATUS: COMPLETE / HARDENED / READY TO EXECUTE`.

**P16 PROMPT HARDENING COMPLETE**

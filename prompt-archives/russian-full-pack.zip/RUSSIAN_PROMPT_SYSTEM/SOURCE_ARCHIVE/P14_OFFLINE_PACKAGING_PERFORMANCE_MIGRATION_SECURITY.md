# P14 — OFFLINE · PACKAGING · PERFORMANCE · MIGRATION · SECURITY HARDENING CONSTITUTION
## RESILIENCE · DATA INTEGRITY · PWA · CACHE · STORAGE · SUPPLY CHAIN · OBSERVABILITY · FAILURE RECOVERY

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Execution mode:

**AUTONOMOUS · EVIDENCE-FIRST · FAILURE-FIRST · SECURITY-FIRST · DATA-INTEGRITY-FIRST · PERFORMANCE-BUDGETED · OFFLINE-SAFE · MIGRATION-SAFE · ROLLBACK-SAFE · TOKEN-EFFICIENT**

---

# P14 CHANGELOG

- 2026-09-30 — Full deep P14 constitution created.
- 2026-09-30 — Final hardening: IndexedDB/versionchange, storage eviction, pack repair, offline-assessment identity, downgrade safety, service-worker races, account isolation, build reproducibility, SBOM/license audit, config drift and engineering golden regression.

---

# 0. MISSION

P14 hardens the application after the product and learning contracts have been defined.

Its purpose is not to add learning features.

Its purpose is to ensure that existing features remain correct under:

- slow devices;
- poor networks;
- offline use;
- stale service workers;
- interrupted downloads;
- storage pressure;
- schema changes;
- content migrations;
- browser differences;
- concurrent tabs;
- malformed content;
- dependency failures;
- provider outages;
- hostile inputs;
- deployment mistakes.

The central rule is:

> **NO PERFORMANCE, OFFLINE OR SECURITY OPTIMIZATION MAY CORRUPT DOMAIN TRUTH OR LEARNER STATE.**

---

# 1. UPSTREAM DEPENDENCIES

P14 consumes:

### P0
- phase orchestration;
- authority;
- rollback;
- release rules.

### P1
- actual runtime architecture;
- build/deploy stack;
- storage;
- service worker;
- network paths.

### P3
- canonical schemas;
- IDs;
- content revisions;
- migrations.

### P4
- learner state;
- attempt integrity;
- mastery;
- offline sync boundaries.

### P5
- planner/SRS state.

### P6
- media/audio runtime;
- recording;
- offline fallback.

### P10
- AI provider/tool boundaries;
- secrets;
- failure fallback.

### P11
- scenario persistence;
- seed/revision/event identity.

### P12
- content snapshot;
- authoring activation;
- migration/snapshot semantics.

### P13
- critical UX journeys;
- error/offline states;
- responsive/device matrix.

P14 must preserve these contracts.

---

# 2. P14 OWNERSHIP

P14 owns:

- offline runtime architecture;
- PWA/service worker behavior;
- caching policy;
- cache versioning;
- content pack delivery;
- package integrity;
- asset versioning;
- update strategy;
- storage quotas/cleanup;
- local persistence hardening;
- sync resilience;
- migration execution safety;
- schema/data version compatibility;
- performance budgets;
- startup/loading performance;
- lazy loading/code splitting;
- memory pressure;
- media performance;
- network resilience;
- retry/idempotency infrastructure;
- secrets handling;
- security headers;
- XSS/content sanitization;
- CSP;
- CSRF/session boundary where applicable;
- auth/session transport hardening where applicable;
- dependency/supply-chain review;
- upload/import hardening;
- runtime integrity checks;
- error boundaries;
- observability/telemetry;
- backup/restore integration;
- disaster recovery engineering;
- non-functional release gates.

P14 does NOT own:

- learning content;
- mastery semantics;
- AI pedagogy;
- scenario pedagogy;
- authoring governance;
- visual redesign;
- production release decision.

---

# 3. NON-GOALS

P14 is not:

- a new UI redesign;
- a new curriculum phase;
- a feature expansion phase;
- a reason to rewrite working architecture without evidence;
- a blanket optimization pass with no baseline.

Do not “optimize” before measuring.

---

# 4. HARDENING PRINCIPLE

For every subsystem ask:

1. What is the source of truth?
2. What can fail?
3. What can become stale?
4. What can be retried?
5. What must be idempotent?
6. What must survive reload?
7. What can be cached?
8. What must never be cached?
9. What happens offline?
10. How do we recover without corrupting state?

---

# 5. FAILURE MODEL

Classify failures:

`NETWORK`

`CACHE`

`STORAGE`

`MIGRATION`

`SCHEMA`

`MEDIA`

`AI_PROVIDER`

`AUTH/SESSION`

`CONTENT_INTEGRITY`

`DEPENDENCY`

`SECURITY`

`RESOURCE_PRESSURE`

`DEPLOYMENT`

`BROWSER_CAPABILITY`.

Every critical journey needs defined behavior for relevant classes.

---

# 6. FAILURE ≠ LEARNER FAILURE

Technical failure must not automatically:

- mark answer wrong;
- consume attempt;
- reduce mastery;
- break streak;
- mark scenario fail.

P4 semantics win.

---

# 7. OFFLINE MODES

Define at least conceptually:

`ONLINE`

`DEGRADED_NETWORK`

`OFFLINE_CACHED`

`OFFLINE_PARTIAL`

`SYNC_PENDING`

`SYNC_CONFLICT`.

UI semantics come from P13.

---

# 8. OFFLINE CAPABILITY MATRIX

For each feature determine:

- works fully offline;
- works read-only;
- works with queued writes;
- unavailable;
- fallback.

At minimum audit:

- roadmap;
- lesson;
- vocab;
- grammar;
- SRS review;
- assessment practice;
- official assessment;
- listening;
- speaking recording;
- speech recognition;
- AI Mentor;
- scenario;
- writing;
- authoring/admin.

---

# 9. OFFLINE CORE

Core learning should continue offline when local pack/state permits:

- canonical lesson content;
- vocabulary;
- grammar;
- deterministic practice;
- SRS;
- downloaded media;
- draft writing;
- deterministic scenario fallback.

AI/external-service features may degrade.

---

# 10. ONLINE-ONLY FEATURE LABEL

If a feature truly requires network:

state it clearly.

Do not let learner discover after completing half a task.

---

# 11. SERVICE WORKER OWNERSHIP

Exactly one canonical service worker/update strategy.

Avoid:

- multiple competing service workers;
- old registration paths;
- duplicate cache logic.

Audit existing code first.

---

# 12. SERVICE WORKER VERSION

Service worker build/version should be traceable to application release/build.

Do not use random manual cache names without lifecycle strategy.

---

# 13. SERVICE WORKER UPDATE

New worker should not silently break an active:

- assessment;
- recording;
- long draft;
- scenario.

Prefer safe activation point where architecture permits.

---

# 14. SKIP WAITING BOUNDARY

Do not use aggressive `skipWaiting`/reload behavior blindly.

Evaluate active-session risk.

---

# 15. CLIENT CLAIM

Likewise, new worker claiming tabs must not mix incompatible runtime/data versions.

---

# 16. CACHE CATEGORIES

Separate caches conceptually:

`APP_SHELL`

`STATIC_ASSETS`

`CANONICAL_CONTENT`

`MEDIA`

`OFFLINE_PACK`

`RUNTIME_NETWORK`

`DERIVED_INDEX`

`TEMPORARY`.

Do not use one giant cache.

---

# 17. CACHE KEY

Cache identity may require:

- resource URL;
- content revision;
- pack revision;
- locale/support language;
- media revision.

Do not cache mutable content only by pretty URL if revision matters.

---

# 18. APP SHELL CACHE

Use for stable shell assets.

Must invalidate on incompatible build.

---

# 19. CANONICAL CONTENT CACHE

Tie to content snapshot/revision.

Avoid mixing lesson from snapshot A with assessment from snapshot B if contract requires coherence.

---

# 20. MEDIA CACHE

Large media should use appropriate strategy:

- explicit pack download;
- LRU cleanup;
- on-demand cache.

Do not fill storage uncontrollably.

---

# 21. DERIVED INDEX CACHE

Search/index artifacts can be rebuilt.

They are not source of truth.

Corruption should trigger rebuild/fallback.

---

# 22. TEMPORARY CACHE

AI responses/preview data should not pollute long-term canonical cache.

---

# 23. CACHE STRATEGY

Choose per resource:

`CACHE_FIRST`

`NETWORK_FIRST`

`STALE_WHILE_REVALIDATE`

`NETWORK_ONLY`

`CACHE_ONLY`

based on semantics.

Do not apply one strategy globally.

---

# 24. CACHE-FIRST USE

Appropriate for immutable hashed assets.

Less appropriate for rapidly changing state.

---

# 25. NETWORK-FIRST USE

Appropriate for fresh content/status when offline fallback exists.

Need timeout.

---

# 26. STALE-WHILE-REVALIDATE

Use only when stale display is acceptable and revision mismatch cannot corrupt state.

---

# 27. NETWORK-ONLY

Use for sensitive operations that must not replay from stale cache.

Examples may include protected admin actions.

---

# 28. CACHE-ONLY

Useful for explicitly downloaded offline packs.

---

# 29. CACHE POISONING

Treat network content as untrusted until response/content type/integrity checks pass where applicable.

Do not cache error HTML as JSON content.

---

# 30. RESPONSE VALIDATION

Before caching canonical JSON:

- successful status;
- expected content type;
- schema/basic parse;
- revision identity.

---

# 31. CACHE ERROR RESPONSE

Never cache:

- 401 login page;
- 404 HTML;
- provider error;

under canonical data key.

---

# 32. STALE AUTH CACHE

Protected admin/API responses must not be exposed from shared/public cache incorrectly.

Use appropriate cache-control/private boundaries.

---

# 33. CACHE CLEANUP

On new release:

remove obsolete caches safely.

Do not delete active offline pack still required unless incompatible and migration strategy exists.

---

# 34. CACHE MIGRATION

If cache format changes:

migrate or invalidate deterministically.

Do not leave orphaned gigabytes.

---

# 35. STORAGE LAYERS

Possible:

- memory;
- localStorage;
- IndexedDB;
- Cache Storage;
- backend;
- file/object storage.

Each has defined ownership.

---

# 36. LOCALSTORAGE BOUNDARY

Use only for small non-critical/preferences where appropriate.

Do not store large canonical datasets or long drafts casually.

---

# 37. INDEXEDDB

Suitable for structured offline state/content where architecture uses it.

Need schema/version migration.

---

# 38. CACHE STORAGE

For request/response assets.

Not a generic database.

---

# 39. STORAGE QUOTA

Detect/handle quota pressure.

Do not wait for random write failure.

---

# 40. STORAGE PRESSURE POLICY

Cleanup priority:

1. disposable temporary cache;
2. regenerable derived data;
3. old media packs;
4. old inactive content packs;

protect:

- unsynced learner work;
- attempts;
- drafts;
- required current pack.

---

# 41. NEVER DELETE UNSYNCED WORK SILENTLY

Invariant.

---

# 42. STORAGE ESTIMATE

If browser API supports:

estimate usage/quota.

Use as advisory.

Do not assume exact values cross-browser.

---

# 43. OFFLINE PACK

A content pack should define:

- pack ID;
- content snapshot;
- assets;
- media;
- size;
- dependencies;
- checksum/integrity metadata;
- schema version.

---

# 44. PACK MANIFEST

Machine-readable.

Do not infer package contents from folder listing at runtime.

---

# 45. PACK VERSION

Stable and comparable.

---

# 46. PACK ATOMICITY

Avoid partially installed pack appearing complete.

Use staging:

download

→ verify

→ commit active.

---

# 47. INTERRUPTED DOWNLOAD

Resume or restart safely.

No corrupted active pack.

---

# 48. PACK CHECKSUM

Verify downloaded files where supported/appropriate.

Checksum proves bytes, not semantic correctness.

---

# 49. PACK DEPENDENCY

Example:

stage pack may depend on core pronunciation assets.

Manifest makes explicit.

---

# 50. PACK SIZE

Measure.

Do not ship all 8,000 vocab + all audio/video eagerly if unnecessary.

---

# 51. PACK GRANULARITY

Possible:

- core app;
- current stage;
- domain pack;
- media pack.

Balance:

too large

vs

too fragmented.

---

# 52. PACK UPDATE

Diff/incremental update if architecture supports and complexity justified.

Otherwise safe replace.

---

# 53. PACK ROLLBACK

Keep last known-good pack metadata where storage allows.

---

# 54. CONTENT SNAPSHOT COHERENCE

Offline pack should use one coherent content snapshot.

Do not mix arbitrary revisions.

---

# 55. CONTENT SNAPSHOT ID

Tie to P12 activation/release snapshot.

---

# 56. APP VERSION / CONTENT VERSION

Separate:

application build version

from:

content snapshot version.

Content may update without app binary.

---

# 57. SCHEMA COMPATIBILITY

App declares which content schema versions it can read.

---

# 58. FORWARD INCOMPATIBILITY

If content schema too new:

do not attempt partial parse.

Show update required/fallback.

---

# 59. BACKWARD COMPATIBILITY

Maintain where practical across supported window.

Do not carry indefinite legacy forever; P16 retires.

---

# 60. DATA MIGRATION

Migration classes:

`CONTENT_SCHEMA`

`LEARNER_STATE`

`SRS_STATE`

`SCENARIO_STATE`

`DRAFT_STATE`

`CACHE/PACK`

`SETTINGS`.

Each has separate risk.

---

# 61. MIGRATION INVARIANTS

Migration must preserve:

- stable IDs or aliases;
- first attempts;
- official scores;
- learner drafts;
- SRS due semantics;
- scenario history;
- content provenance.

Unless explicit correction/migration policy says otherwise.

---

# 62. MIGRATION VERSION

Persist current schema/state version.

Do not guess migration need from field existence only.

---

# 63. MIGRATION CHAIN

Prefer:

v1 → v2 → v3

or verified direct migration.

No ambiguous jumps.

---

# 64. MIGRATION IDEMPOTENCY

Running migration twice must not duplicate/corrupt.

---

# 65. MIGRATION TRANSACTION

Where storage supports:

atomic transaction.

Otherwise staged copy + verify + swap.

---

# 66. MIGRATION BACKUP

Before destructive local-state migration:

snapshot/backup where feasible.

---

# 67. MIGRATION DRY RUN

For backend/content migration:

report affected records/errors.

---

# 68. MIGRATION RESUME

Interrupted migration should resume or safely restart.

---

# 69. MIGRATION FAILURE

Do not continue app with half-migrated critical state.

Enter recovery/read-only/fallback state.

---

# 70. MIGRATION TELEMETRY

Record:

from;
to;
success/failure;
duration;
error class.

Avoid raw private content.

---

# 71. CONTENT ID MIGRATION

Use aliases/mapping from P3/P12.

---

# 72. LEARNER STATE MIGRATION

Must not inflate/erase mastery.

P4 owns semantic mapping.

P14 implements safely.

---

# 73. SRS MIGRATION

Preserve:

due;
interval;
history

according to P5 policy.

---

# 74. SCENARIO STATE MIGRATION

Use P11 revision mapping.

If impossible:

preserve history;
restart session safely.

---

# 75. DRAFT MIGRATION

Never silently drop long writing draft.

---

# 76. SETTINGS MIGRATION

Unknown/removed preference falls back safely.

---

# 77. PERFORMANCE BASELINE

Before optimization measure representative:

- cold load;
- warm load;
- route navigation;
- lesson open;
- search;
- SRS open;
- audio start;
- recorder start;
- scenario load;
- writing editor;
- authoring list;
- bulk import preview.

---

# 78. DEVICE BASELINE

At least:

- lower/mid mobile;
- typical desktop/laptop;
- tablet where relevant.

Use realistic throttling/device profile where tools allow.

---

# 79. NETWORK BASELINE

Test:

- fast;
- slow;
- high latency;
- intermittent;
- offline.

---

# 80. PERFORMANCE BUDGET

Define after baseline/product needs.

Possible dimensions:

- JS initial;
- CSS;
- app shell;
- content payload;
- route chunks;
- memory;
- media;
- interaction latency.

Do not invent arbitrary numbers before measurement.

---

# 81. CORE WEB VITALS / USER-CENTRIC METRICS

Where browser/web stack supports, observe:

- LCP;
- INP;
- CLS;
- TTFB.

But do not optimize metrics while breaking learning correctness.

---

# 82. FIRST MEANINGFUL LEARNING ACTION

Also measure product-specific:

time until learner can start current task.

This may matter more than generic page complete.

---

# 83. CODE SPLITTING

Split:

- admin/editor;
- scenario editor;
- research workspace;
- heavy charts;

from learner initial bundle if not needed.

---

# 84. ROUTE LAZY LOADING

Load route-specific code on demand.

Provide loading state.

---

# 85. DATA LAZY LOADING

Do not preload:

4,000 dialogues;
1,000 deep speaking items;
all technical packs.

Use index + targeted load.

---

# 86. VOCAB INDEX

Search/index can load compact metadata.

Full lexical details on demand.

---

# 87. IMAGE OPTIMIZATION

Use appropriate:

size;
format;
responsive source;
lazy load.

Do not degrade instructional diagrams.

---

# 88. VIDEO OPTIMIZATION

Streaming/download strategy based on offline policy.

Avoid autoplay large video.

---

# 89. AUDIO OPTIMIZATION

Preload current/next segments where useful.

Do not preload entire course audio.

---

# 90. FONT PERFORMANCE

Avoid excessive webfont variants.

Ensure fallback supports Cyrillic/Vietnamese.

Do not flash invisible text excessively.

---

# 91. ICON PERFORMANCE

Use coherent icon system.

Avoid loading giant unused sets.

---

# 92. THIRD-PARTY SCRIPT

Audit every third-party script.

Remove unused.

Defer noncritical.

---

# 93. ADMIN BUNDLE

Admin dependencies should not inflate learner bundle.

---

# 94. AI SDK BUNDLE

Keep server/provider SDK out of browser where secret/server use required.

---

# 95. TREE SHAKING

Verify rather than assume.

---

# 96. MEMORY PRESSURE

Long sessions/scenarios/editors can leak memory.

Test:

- route change;
- audio objects;
- recording streams;
- event listeners;
- AI stream;
- editor models.

---

# 97. MEDIA RESOURCE CLEANUP

Stop/release:

MediaStream;
AudioContext if appropriate;
object URLs;
timers.

---

# 98. EVENT LISTENER CLEANUP

No duplicate listeners after route remount.

---

# 99. SUBSCRIPTION CLEANUP

State/store/websocket subscriptions disposed.

---

# 100. ABORT CONTROLLER

Cancel stale fetches/AI requests where appropriate.

---

# 101. VIRTUALIZED LISTS

Use for:

- vocab;
- content admin;
- logs;
- large review queue.

---

# 102. LONG WRITING PERFORMANCE

Do not re-render whole document on every keystroke.

---

# 103. SEARCH PERFORMANCE

Index/query should remain responsive with thousands of entries.

---

# 104. SCENARIO GRAPH PERFORMANCE

Admin graph can lazy/render visible subset if large.

---

# 105. BUILD PERFORMANCE

Content build/validator should be incremental where possible.

P14 may optimize CI but correctness first.

---

# 106. NETWORK REQUEST BUDGET

Avoid N+1 fetches.

Batch/aggregate where semantic boundaries allow.

---

# 107. REQUEST DEDUPLICATION

Concurrent identical content fetch can share request/cache.

Do not dedupe state-changing POST blindly.

---

# 108. PREFETCH

Prefetch likely next route/content cautiously.

Do not waste mobile data/storage.

---

# 109. PRIORITY

Current task resources > analytics/decorative assets.

---

# 110. RETRY POLICY

Classify operations:

`SAFE_TO_RETRY`

`IDEMPOTENT_WITH_KEY`

`DO_NOT_AUTORETRY`.

---

# 111. GET RETRY

Network read can retry with backoff if appropriate.

---

# 112. STATE WRITE RETRY

Use idempotency key / revision check.

---

# 113. ASSESSMENT SUBMIT

Must not duplicate official attempt.

---

# 114. AUTHORING ACTIVATION

Must not duplicate activation.

---

# 115. AI REQUEST

Retry may be safe for response generation, but no duplicate downstream state write.

---

# 116. EXPONENTIAL BACKOFF

Use bounded backoff/jitter where appropriate.

Do not retry infinitely.

---

# 117. TIMEOUT

Every external request class should have reasonable timeout/fallback.

---

# 118. CIRCUIT BREAKER

For repeatedly failing external service where architecture supports.

---

# 119. OFFLINE DETECTION

Do not trust `navigator.onLine` alone.

Use actual request outcomes.

---

# 120. SYNC QUEUE

Offline writes may queue only where semantics permit.

Each queue item:

- operation ID;
- base revision;
- payload;
- timestamp;
- retry state.

---

# 121. SYNC ORDER

Respect dependencies.

Example:

create draft

before:

attach comment.

---

# 122. SYNC CONFLICT

On server revision conflict:

stop automatic overwrite.

Surface conflict.

---

# 123. SYNC DUPLICATE

Idempotency prevents duplicate attempt/draft event.

---

# 124. SYNC DEAD LETTER

Repeated failure moves to recoverable failed queue.

Do not discard silently.

---

# 125. BACKGROUND SYNC

Use if browser/support fits.

Not required.

Foreground recovery path still needed.

---

# 126. SECURITY THREAT MODEL

At minimum consider:

- XSS;
- stored XSS;
- DOM XSS;
- CSRF where relevant;
- auth/session misuse;
- secret leakage;
- insecure direct object reference;
- privilege escalation;
- malicious import;
- malicious media;
- prompt injection;
- supply-chain compromise;
- dependency vulnerability;
- cache poisoning;
- clickjacking;
- unsafe redirects;
- path traversal/file handling;
- log injection;
- sensitive data leakage.

---

# 127. TRUST BOUNDARIES

Identify:

- learner input;
- author input;
- imported file;
- external source;
- AI output;
- backend response;
- repository data;
- browser storage.

Do not call all internal-looking data trusted.

---

# 128. XSS

Any user/imported/generated rich text must be sanitized/escaped.

Default render as text.

---

# 129. STORED XSS

Admin-authored content can still be malicious/accidental.

Sanitize at write/render boundaries.

---

# 130. MARKDOWN SECURITY

Use safe Markdown renderer/config.

Disable unsafe raw HTML unless explicitly sanitized.

---

# 131. CODE BLOCK

Render inert.

Never execute.

---

# 132. FORMULA RENDERER

Keep safe configuration.

No arbitrary script execution.

---

# 133. URL SANITIZATION

Allow safe protocols.

Reject:

`javascript:`

or equivalent dangerous schemes.

---

# 134. EXTERNAL LINKS

Use appropriate:

`rel="noopener noreferrer"`

where target blank/external.

---

# 135. IFRAME

Avoid arbitrary iframe embeds.

If required:

sandbox and allowlist.

---

# 136. CONTENT SECURITY POLICY

Define CSP appropriate to architecture.

Prefer:

- no unsafe-inline where feasible;
- restricted script sources;
- connect-src for required APIs;
- media/img/font sources explicit.

Do not deploy broken overly broad CSP and call it security.

---

# 137. CSP REPORTING

Optional report-only phase before enforce.

Validate no critical legitimate flows blocked.

---

# 138. SECURITY HEADERS

Audit where hosting permits:

- Content-Security-Policy;
- X-Content-Type-Options;
- Referrer-Policy;
- Permissions-Policy;
- frame-ancestors;
- HSTS where HTTPS/domain policy supports.

Do not cargo-cult headers without environment knowledge.

---

# 139. CLICKJACKING

Use CSP frame-ancestors / X-Frame-Options where applicable.

---

# 140. HTTPS

Production external traffic must use HTTPS except local development.

---

# 141. MIXED CONTENT

No HTTP media/API on HTTPS page.

---

# 142. SECRET MANAGEMENT

Secrets never committed to:

- repo;
- frontend bundle;
- static JSON;
- logs.

Use environment/secret store.

---

# 143. CLIENT ENV VAR

Any environment variable embedded in frontend is public.

Name conventions do not make it secret.

---

# 144. SECRET ROTATION

If secret leaked:

rotate.

Do not merely remove from latest commit.

---

# 145. GIT HISTORY SECRET

If sensitive secret committed:

treat as compromised.

Rotate first.

History cleanup as appropriate.

---

# 146. PROVIDER KEYS

AI/API private keys server-side.

P10 provider adapter uses secure boundary.

---

# 147. DATABASE URL

Do not expose privileged DB connection string to browser.

---

# 148. AUTH SECRET

Server-only.

---

# 149. LOG REDACTION

Redact:

- tokens;
- auth headers;
- secrets;
- sensitive learner data where unnecessary.

---

# 150. ERROR MESSAGE SECURITY

Learner-facing error should not expose:

- stack;
- file system paths;
- secrets;
- raw DB query.

Admin logs can hold bounded technical detail.

---

# 151. AUTHORIZATION

All privileged actions validated server/action-side.

UI hiding is not authorization.

---

# 152. IDOR

Author/admin APIs must verify access to requested resource.

Do not trust arbitrary entity/user ID.

---

# 153. ROLE ESCALATION

Role changes require privileged path.

Content fields cannot grant themselves permissions.

---

# 154. CSRF

If using cookie-authenticated state-changing web requests:

apply framework-appropriate CSRF/SameSite/origin defenses.

If token architecture differs, document relevant threat.

---

# 155. SESSION COOKIE

Where cookie auth used:

Secure;
HttpOnly;
SameSite appropriate.

---

# 156. TOKEN STORAGE

Avoid storing long-lived high-privilege tokens in localStorage when safer architecture exists.

---

# 157. SESSION EXPIRY

State/drafts recover safely after re-auth.

---

# 158. LOGOUT

Revoke/clear sensitive local auth state.

Do not delete offline learner content unnecessarily unless policy requires.

---

# 159. CORS

Restrict origins/methods/headers.

Do not use wildcard with credentials.

---

# 160. API INPUT VALIDATION

Validate:

type;
length;
enum;
refs;
authorization.

Never trust frontend.

---

# 161. OUTPUT ENCODING

Escape appropriately for context.

---

# 162. RATE LIMIT

Protect:

- auth;
- AI proxy;
- expensive search/import;
- content activation.

Do not rate-limit normal offline/local interaction unnecessarily.

---

# 163. ABUSE BOUNDARY

P14 hardens infrastructure.

P10 governs AI behavior.

---

# 164. FILE UPLOAD

Validate:

- size;
- type;
- extension;
- content/MIME where possible;
- filename;
- storage path.

---

# 165. FILE NAME

Generate safe storage identity.

Preserve display name separately.

---

# 166. PATH TRAVERSAL

Never concatenate untrusted filename into file system path without safe handling.

---

# 167. ARCHIVE UPLOAD

Zip/package import must prevent:

- zip slip;
- decompression bomb;
- excessive file count/size.

---

# 168. CSV INJECTION

If exporting CSV intended for spreadsheet tools:

protect against formula injection where relevant.

---

# 169. JSON IMPORT

Limit size/depth.

Validate schema.

---

# 170. XML

Avoid unless needed.

If used, disable unsafe external entity behavior.

---

# 171. MEDIA METADATA

Do not trust media metadata blindly.

---

# 172. MIME SNIFFING

Use safe content type handling.

---

# 173. OBJECT URL

Revoke after use.

---

# 174. DOWNLOAD CONTENT-DISPOSITION

Safe filenames/headers.

---

# 175. DEPENDENCY INVENTORY

Create list of production dependencies.

Identify:

- direct;
- transitive;
- build-only;
- runtime.

---

# 176. UNUSED DEPENDENCY

Remove if truly unused after test.

Reduces attack/bundle surface.

---

# 177. VERSION PINNING

Use lockfile.

Do not use unbounded dependency ranges for production builds casually.

---

# 178. LOCKFILE INTEGRITY

Commit canonical lockfile according to package manager.

---

# 179. VULNERABILITY SCAN

Run dependency/security audit.

Classify real exploitability.

Do not blindly upgrade everything and break app.

---

# 180. CRITICAL CVE

Patch/mitigate promptly.

Verify compatibility/regression.

---

# 181. TRANSITIVE VULNERABILITY

Assess reachable usage.

Document accepted temporary risk if unavoidable.

---

# 182. SUPPLY CHAIN

Prefer reputable maintained packages.

Avoid adding package for trivial helper.

---

# 183. INSTALL SCRIPTS

Review risky package install/postinstall behavior where relevant.

---

# 184. PACKAGE PROVENANCE

Use registry integrity/lockfile.

Optional stronger provenance if CI supports.

---

# 185. BUILD SCRIPT

Audit for secret exposure and unexpected network action.

---

# 186. CI SECURITY

Secrets only in required jobs.

Untrusted PRs should not gain production secrets.

---

# 187. ENVIRONMENT SEPARATION

Development/staging/production configs distinct.

Do not point local tests accidentally to production DB.

---

# 188. PREVIEW ENVIRONMENT

Preview should use safe data/secrets.

No production write access by default.

---

# 189. PRODUCTION CREDENTIAL

Least privilege.

---

# 190. DATABASE SECURITY

If backend DB exists:

- parameterized queries/ORM safe bindings;
- least-privilege user;
- TLS as appropriate;
- migrations controlled.

---

# 191. DATA CONSTRAINTS

Use DB constraints where possible for:

- unique IDs;
- foreign keys;
- enum/checks;
- revision uniqueness.

Application validation alone insufficient.

---

# 192. TRANSACTION

Critical multi-write operation uses transaction where datastore supports.

---

# 193. BACKUP

Define backup for server-side learner/content data where applicable.

---

# 194. BACKUP FREQUENCY

Based on recovery objective.

Do not invent unsupported SLA.

---

# 195. RESTORE TEST

A backup not tested for restore is not fully trusted.

---

# 196. RPO/RTO

If production requirements define:

Recovery Point Objective;
Recovery Time Objective.

If not defined:

record as open operational policy rather than inventing numbers.

---

# 197. DISASTER RECOVERY

Document:

- database restore;
- content snapshot restore;
- deployment rollback;
- offline client recovery.

---

# 198. DATA CORRUPTION DETECTION

Use:

- schema constraints;
- checks;
- content revision;
- invariant tests.

---

# 199. INVARIANT MONITOR

Examples:

- duplicate canonical ID;
- dangling ref;
- impossible mastery enum;
- invalid SRS due date;
- scenario unknown state.

---

# 200. SELF-HEAL BOUNDARY

Automatically rebuild:

- derived index;
- disposable cache.

Do not self-heal official learner evidence by guessing.

---

# 201. ERROR BOUNDARY

UI/application should isolate component/route crashes.

One broken optional widget should not blank entire app.

---

# 202. GLOBAL ERROR

Have final fallback.

Preserve local work where possible.

---

# 203. RECOVERY ACTION

Error boundary can offer:

retry;
reload;
go home;
report.

---

# 204. CRASH LOOP

If repeated crash after update:

detect/fallback to safe route/rollback hint.

---

# 205. FEATURE FLAG

High-risk optional features can be disabled independently.

---

# 206. KILL SWITCH

AI;
scenario family;
editor feature;
bad content snapshot

can be disabled without full shutdown where architecture supports.

---

# 207. OBSERVABILITY LAYERS

Observe:

- application errors;
- network failures;
- sync failures;
- migration failures;
- AI/provider failures;
- performance;
- content integrity;
- activation/build failures.

---

# 208. LOG LEVEL

`ERROR`

`WARN`

`INFO`

`DEBUG`.

Production debug disabled/restricted by default.

---

# 209. STRUCTURED LOG

Include:

- event;
- request ID;
- build;
- content snapshot;
- route/subsystem;
- error code.

Avoid raw private content.

---

# 210. CORRELATION ID

Trace request across client/backend/service where useful.

---

# 211. USER ID PRIVACY

Use pseudonymous/internal ID if needed for diagnostics.

Do not log unnecessary personal profile.

---

# 212. ERROR FINGERPRINT

Group recurring crashes.

---

# 213. PERFORMANCE TELEMETRY

Sample rather than flood.

---

# 214. OFFLINE TELEMETRY

Queue only bounded non-sensitive events if needed.

Do not grow unlimited.

---

# 215. OBSERVABILITY FAILURE

Analytics/logging outage must not break learning.

---

# 216. ALERTING

Alert on actionable production conditions:

- high error rate;
- migration failures;
- broken content snapshot;
- provider outage;
- severe performance regression.

Do not alert on every individual typo.

---

# 217. HEALTH CHECK

Backend/service health endpoints as appropriate.

Do not expose sensitive details publicly.

---

# 218. READINESS CHECK

Deploy environment can verify required dependencies before serving production.

---

# 219. LIVENESS

Use carefully; avoid restart loops masking dependency issue.

---

# 220. CONTENT HEALTH CHECK

Verify active snapshot:

- manifest readable;
- key refs resolve;
- index available.

---

# 221. MEDIA HEALTH

Sample required media accessible.

---

# 222. AI HEALTH

Provider reachability can be observed, but core app health should not be “down” solely because AI optional feature unavailable.

---

# 223. OFFLINE HEALTH

Build/test that offline core actually loads.

---

# 224. BROWSER SUPPORT MATRIX

Define supported browsers based on actual audience/architecture.

At minimum likely test modern:

- Chromium;
- Edge;
- Safari/mobile Safari where relevant;
- Firefox if supported.

Do not claim support without test.

---

# 225. CAPABILITY DETECTION

Use feature detection for:

- IndexedDB;
- service worker;
- MediaRecorder;
- speech recognition;
- install prompt;
- storage estimate.

Do not browser-sniff when avoidable.

---

# 226. UNSUPPORTED CAPABILITY

Fallback per P13 UX.

---

# 227. SAFARI/IOS OFFLINE QUIRKS

Test separately if supporting iOS.

Do not assume Chromium PWA behavior.

---

# 228. PRIVATE/INCOGNITO MODE

Storage/service-worker constraints may differ.

Fail gracefully.

---

# 229. MULTI-TAB

Test:

- simultaneous SRS;
- draft;
- assessment;
- scenario;
- content update.

Avoid cross-tab state corruption.

---

# 230. BROADCAST CHANNEL / STORAGE EVENTS

Use if needed for coordination.

Do not overengineer if backend revision checks suffice.

---

# 231. TAB LEADER

Only if background sync requires.

Otherwise avoid unnecessary leader-election complexity.

---

# 232. CLOCK SKEW

Do not rely on client clock for authoritative ordering where server exists.

SRS local-only mode may need explicit local-time semantics.

---

# 233. TIMEZONE

Store timestamps in unambiguous format.

Display local.

P4/P5 due-date semantics remain authoritative.

---

# 234. DAYLIGHT SAVING

Russian/Vietnamese contexts differ.

Use timezone-aware libraries/logic.

Do not hard-code +7 globally for all learners.

---

# 235. LOCALE

Formatting separate from data semantics.

---

# 236. DATE MIGRATION

Old local date strings must be parsed deterministically.

---

# 237. ENCODING

UTF-8 throughout.

Test:

- Cyrillic;
- Vietnamese;
- combining stress;
- mathematical symbols.

---

# 238. UNICODE NORMALIZATION

Choose normalization policy.

Do not break canonical stress/search.

---

# 239. HOMOGLYPH

Admin/security-sensitive IDs should not rely on visually confusable user text.

Canonical IDs use safe character set.

---

# 240. CONTENT TEXT SIZE LIMIT

Set reasonable limits for:

- title;
- example;
- note;
- AI response;
- draft chunk.

Long documents handled as documents, not one unbounded field.

---

# 241. REQUEST SIZE LIMIT

Protect backend/import.

---

# 242. RESPONSE SIZE

Paginate/stream/chunk large datasets.

---

# 243. COMPRESSION

Use HTTP compression appropriately.

Do not compress already compressed media needlessly.

---

# 244. CDN

If used:

cache immutable static/media appropriately.

Protected/user data not public-cacheable.

---

# 245. ETAG / LAST-MODIFIED

Can support efficient revalidation.

Tie to actual content revision.

---

# 246. HTTP CACHE CONTROL

Define per resource.

Do not let browser cache old mutable HTML forever while JS expects new API.

---

# 247. HTML CACHE

Usually revalidate/current shell strategy.

Avoid stale entry point pointing to removed chunks.

---

# 248. HASHED ASSETS

Long immutable cache.

---

# 249. CHUNK NOT FOUND

After deploy, old tab may request old chunk.

Handle:

reload/update prompt;
keep old assets during transition if deployment platform supports.

Do not crash silently.

---

# 250. DEPLOY ATOMICITY

Application assets/HTML/content should transition coherently.

Avoid serving mixed build where possible.

---

# 251. CONTENT ACTIVATION ATOMICITY

P12 changeset/snapshot activates coherently.

---

# 252. APP/CONTENT COMPATIBILITY GATE

Before activating content snapshot:

verify current app supports schema/version.

---

# 253. ROLLBACK COMPATIBILITY

Old app build must know which content snapshot it can read.

Release metadata should record.

---

# 254. DATABASE MIGRATION DEPLOY ORDER

If backend:

expand-compatible migration

→ deploy new code

→ contract later

when zero-downtime needed.

Do not drop old column before old code stops using it.

---

# 255. FEATURE FLAG DEPLOY ORDER

Ship code disabled

→ validate

→ enable.

Useful high-risk change.

---

# 256. MIGRATION LOCK

Prevent two instances running same non-idempotent migration concurrently.

---

# 257. SECURITY SCAN TYPES

Where available:

- dependency audit;
- static analysis;
- secret scan;
- build artifact scan;
- headers/CSP check;
- dynamic basic security smoke.

No single scanner proves security.

---

# 258. SECRET SCAN

Repository + build output.

---

# 259. SOURCE MAP

Production source maps can aid debugging but may expose source.

Choose access policy.

Do not publish sensitive source map accidentally.

---

# 260. DEBUG ENDPOINT

Disable/restrict production debug routes.

---

# 261. ADMIN ROUTE

Auth + authorization.

Do not rely on obscure URL.

---

# 262. CLIENT FEATURE FLAG

Cannot protect secret/admin API alone.

Server enforces.

---

# 263. OPEN REDIRECT

Validate redirect targets.

---

# 264. LOGIN CALLBACK

Allowlisted/validated.

---

# 265. OAUTH STATE/PKCE

If OAuth used:

follow provider/framework secure flow.

P14 audits, not reinvents crypto.

---

# 266. CRYPTO

Use standard platform/library primitives.

Do not build custom encryption.

---

# 267. PASSWORD

If app manages passwords:

use proven auth provider/library.

Do not store plaintext.

If app does not own auth, do not invent password system.

---

# 268. PII MINIMIZATION

Store only learner/admin data required.

---

# 269. DATA EXPORT/DELETE

If product supports account data management, ensure offline/local data behavior is defined.

Not a P14 invention if platform owns it.

---

# 270. TELEMETRY CONSENT

Follow platform/product policy.

P14 does not assume unlimited analytics.

---

# 271. MEDIA RECORDING PRIVACY

P6 recordings:

clear retention/storage path.

Avoid background upload not required.

---

# 272. LOCAL RECORDING

If only local practice:

keep local where architecture intends.

---

# 273. UPLOAD RECORDING

Use explicit task/consent semantics.

Secure transport/storage.

---

# 274. RESEARCH DOCUMENT PRIVACY

Long P9 documents may contain confidential material.

Avoid sending to external AI/storage without authorized path.

---

# 275. BACKEND ENCRYPTION

Use provider/platform encryption-at-rest where available.

Do not make unsupported guarantees.

---

# 276. SECURITY INCIDENT LOG

Record:

time;
subsystem;
impact;
mitigation.

Do not log exploit payload broadly if it contains secrets/private data.

---

# 277. INCIDENT SEVERITY

`SEV0/1/2/3`

or project equivalent.

Define based on:

data loss;
privacy;
availability;
integrity.

---

# 278. INCIDENT RESPONSE

Contain

→ preserve evidence

→ rollback/disable

→ root cause

→ patch

→ regression

→ restore

→ postmortem.

---

# 279. DATA LOSS INCIDENT

Highest priority if learner official work lost/corrupted.

---

# 280. CONTENT INTEGRITY INCIDENT

Wrong active assessment/content can also be severe even without server outage.

---

# 281. SECURITY INCIDENT

Credential leak/security compromise may require:

- secret rotation;
- session revocation;
- deploy;
- log review.

---

# 282. PERFORMANCE INCIDENT

Severe regression can feature-flag/rollback heavy feature.

---

# 283. ERROR BUDGET

Optional operational concept.

Do not invent SLO if project has none.

---

# 284. SLO

If defined later, metrics should reflect user journeys.

---

# 285. P14 PILOT

Pilot hardening on representative slices:

### Pilot A — Offline lesson/SRS
Download → offline → review → reload → sync.

### Pilot B — Long writing draft
Edit → offline → reload → reconnect → conflict-safe sync.

### Pilot C — Scenario
AI unavailable → deterministic fallback → resume.

### Pilot D — Content update
old snapshot → staged new pack → verify → activate → rollback.

### Pilot E — Security
malicious Markdown/import + secret scan + admin permission test.

---

# 286. PILOT ACCEPTANCE

Must prove:

- no state loss;
- no duplicate attempt;
- no stale pack corruption;
- migration safe;
- XSS blocked;
- secrets absent from client bundle;
- fallback works;
- performance measured;
- rollback works.

---

# 287. P14 REQUIRED DELIVERABLES — ARCHITECTURE

Create/maintain:

`subjects/russian/docs/p14/RUSSIAN_P14_EXECUTIVE_SUMMARY.md`

`RUSSIAN_OFFLINE_CAPABILITY_MATRIX.md`

`RUSSIAN_SERVICE_WORKER_CACHE_CONTRACT.md`

`RUSSIAN_CONTENT_PACK_CONTRACT.md`

`RUSSIAN_STORAGE_OWNERSHIP_MAP.md`

`RUSSIAN_SYNC_IDEMPOTENCY_CONTRACT.md`

`RUSSIAN_MIGRATION_SAFETY_CONTRACT.md`.

---

# 288. REQUIRED DELIVERABLES — PERFORMANCE

Create:

`RUSSIAN_PERFORMANCE_BASELINE.md`

`RUSSIAN_PERFORMANCE_BUDGET.md`

`RUSSIAN_BUNDLE_DATA_LOADING_AUDIT.md`

`RUSSIAN_MEDIA_PERFORMANCE_AUDIT.md`

`RUSSIAN_MEMORY_LEAK_AUDIT.md`.

---

# 289. REQUIRED DELIVERABLES — SECURITY

Create:

`RUSSIAN_SECURITY_THREAT_MODEL.md`

`RUSSIAN_TRUST_BOUNDARY_MAP.md`

`RUSSIAN_SECRET_MANAGEMENT_AUDIT.md`

`RUSSIAN_SECURITY_HEADERS_CSP_AUDIT.md`

`RUSSIAN_IMPORT_UPLOAD_SECURITY_AUDIT.md`

`RUSSIAN_DEPENDENCY_SUPPLY_CHAIN_AUDIT.md`.

---

# 290. REQUIRED DELIVERABLES — RELIABILITY

Create:

`RUSSIAN_ERROR_RECOVERY_CONTRACT.md`

`RUSSIAN_OBSERVABILITY_CONTRACT.md`

`RUSSIAN_BACKUP_RESTORE_READINESS.md`

`RUSSIAN_DISASTER_RECOVERY_RUNBOOK.md`

`RUSSIAN_P14_RISK_REGISTER.json`

`RUSSIAN_P14_EVIDENCE_INDEX.md`

`RUSSIAN_P15_INPUT_CONTRACT.md`.

No empty ceremonial docs.

---

# 291. TEST MATRIX — OFFLINE

Test:

- first install;
- warm offline;
- downloaded pack;
- missing optional media;
- storage pressure;
- update pending;
- reconnect.

---

# 292. TEST MATRIX — CACHE

Test:

- stale app shell;
- stale content;
- corrupt response;
- 404 cached incorrectly;
- old cache cleanup;
- mixed version prevention.

---

# 293. TEST MATRIX — MIGRATION

Test:

- current → next;
- interrupted;
- repeat;
- corrupt old state;
- unsupported future schema;
- rollback/recovery.

---

# 294. TEST MATRIX — PERFORMANCE

Test representative:

- cold;
- warm;
- mobile;
- low memory;
- large data;
- long session.

---

# 295. TEST MATRIX — SECURITY

Test:

- XSS;
- stored XSS;
- malicious Markdown;
- dangerous URL;
- unauthorized admin action;
- stale/revoked permission;
- secret exposure;
- malicious import/archive;
- CSV injection where applicable.

---

# 296. TEST MATRIX — NETWORK

Test:

- offline;
- slow;
- timeout;
- 500;
- 429;
- DNS/fetch fail;
- partial media download.

---

# 297. TEST MATRIX — CONCURRENCY

Test:

- multi-tab draft;
- double submit;
- sync conflict;
- two activations;
- migration lock.

---

# 298. TEST MATRIX — DEPLOY

Test:

- old tab after deploy;
- missing chunk;
- content/app version mismatch;
- rollback.

---

# 299. TEST MATRIX — PRIVACY

Test:

- logs redact;
- client bundle secrets;
- external AI context minimization;
- offline local data isolation.

---

# 300. P14 BLOCKERS

BLOCKER examples:

- learner work can be silently lost;
- official attempt duplicates after retry;
- stale service worker serves incompatible app/data;
- secret present in client bundle/repo;
- admin API authorization missing;
- stored XSS possible through content/editor;
- migration can partially corrupt learner state;
- content pack can activate before integrity verification;
- rollback cannot restore last known-good release/snapshot.

---

# 301. P14 CRITICAL RISKS

CRITICAL examples:

- entire course preloaded causing unusable mobile startup;
- media cache fills storage with no cleanup;
- AI outage breaks core lesson;
- logs contain sensitive document contents unnecessarily;
- dependency with exploitable critical vulnerability;
- old tab silently submits against incompatible schema;
- content activation mixes snapshots.

---

# 302. P14 FAIL CONDITIONS

P14 FAIL if:

- offline behavior is undefined;
- service worker/cache ownership duplicated;
- cache versioning absent;
- downloaded pack can be partially active;
- unsynced work can be evicted;
- migration lacks version/idempotency/recovery;
- no performance baseline;
- all large data loads eagerly;
- secrets exposed;
- privileged actions rely only on UI hiding;
- imported/generated HTML can execute;
- dependency/supply-chain not audited;
- no error recovery;
- no rollback;
- no observability for critical failures;
- app/content compatibility undefined;
- P15 lacks complete non-functional test contract.

---

# 303. P14 PASS CONDITIONS

P14 PASS when:

1. Offline capability matrix exists.
2. Service worker ownership is singular.
3. Cache categories/strategies are explicit.
4. Cache poisoning/error caching is prevented.
5. Content packs are manifest-based and atomic.
6. Storage cleanup protects unsynced work.
7. App/content/schema compatibility is explicit.
8. Migration versioning exists.
9. Migration is idempotent/recoverable.
10. Learner state invariants are preserved.
11. SRS/scenario/draft migrations are safe.
12. Performance baseline exists.
13. Performance budgets are evidence-based.
14. Large datasets lazy-load appropriately.
15. Media loading is bounded.
16. Long-session memory leaks are checked.
17. Retry/idempotency contracts exist.
18. Sync conflict handling exists.
19. XSS/stored-XSS protections exist.
20. CSP/security headers are audited.
21. Secrets are absent from client bundle/repo.
22. Authorization is server/action-side.
23. Upload/import handling is hardened.
24. Dependency/supply-chain audit exists.
25. Build/deploy compatibility is verified.
26. Error boundaries/fallbacks exist.
27. Observability covers critical failures.
28. Backup/restore readiness is tested where relevant.
29. Representative offline/security/performance pilots pass.
30. P15 receives complete system-hardening evidence.

---

# 304. P14 PROMPT COMPLETENESS GATE

P14 prompt is structurally complete only if it covers:

1. offline modes;
2. service worker;
3. cache;
4. packs;
5. storage;
6. sync;
7. versioning;
8. migration;
9. performance baseline;
10. bundle/data loading;
11. memory;
12. media;
13. retry/idempotency;
14. security threat model;
15. XSS/sanitization;
16. CSP/headers;
17. secrets;
18. auth/authorization;
19. file/import security;
20. dependency/supply chain;
21. CI/environment separation;
22. DB/data integrity where relevant;
23. observability;
24. backup/restore;
25. disaster recovery;
26. browser/capability matrix;
27. deployment compatibility;
28. rollback;
29. test matrices;
30. P15 handoff.

If all are defined:

`P14 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P14 implementation has PASSed.

---

# 305. P15 HANDOFF CONTRACT

P14 supplies P15:

- offline capability matrix;
- cache/update contracts;
- migration fixtures;
- performance baseline/budgets;
- browser/device support;
- security findings/mitigations;
- dependency audit;
- failure/recovery semantics;
- observability;
- backup/restore evidence;
- known limitations;
- critical non-functional risks.

P15 must test the whole system against these contracts.

---

# 306. FINAL RESPONSE FORMAT

When P14 implementation completes:

`P14 STATUS: PASS / FAIL / BLOCKED`

`Base SHA:`

`Head SHA:`

`Offline core: PASS / FAIL`

`Service worker/cache: PASS / FAIL`

`Content packs: PASS / FAIL`

`Storage/sync: PASS / FAIL`

`Migration: PASS / FAIL`

`Performance baseline: PASS / FAIL`

`Performance budget: PASS / FAIL`

`Large-data loading: PASS / FAIL`

`Memory/media: PASS / FAIL`

`Retry/idempotency: PASS / FAIL`

`XSS/content sanitization: PASS / FAIL`

`CSP/security headers: PASS / FAIL`

`Secrets: PASS / FAIL`

`Authorization: PASS / FAIL`

`Import/upload security: PASS / FAIL`

`Dependencies/supply chain: PASS / FAIL`

`Observability: PASS / FAIL`

`Backup/restore: PASS / PARTIAL / N/A`

`Rollback readiness: PASS / FAIL`

`P15 readiness: READY / NOT READY`

`PR:`

`Merged SHA:`

`Production: UNCHANGED unless explicitly authorized`

End:

**P14 OFFLINE · PACKAGING · PERFORMANCE · MIGRATION · SECURITY HARDENING COMPLETE**

---

# 307. EXECUTION RULE

When authorized:

`audit actual build/runtime/storage/service worker`

→ `baseline performance`

→ `inventory cache/storage/data paths`

→ `map app/content/schema versions`

→ `harden service worker/cache`

→ `harden offline packs`

→ `harden sync/idempotency`

→ `test migrations`

→ `optimize measured bottlenecks`

→ `audit secrets/auth/security`

→ `audit imports/dependencies`

→ `add observability/recovery`

→ `pilot offline + migration + security`

→ `run regression`

→ `document evidence`

→ `open PR`.

Do not begin with speculative rewrites.

---

# 308. FINAL P14 PRINCIPLE

P14 succeeds only when the application behaves correctly not just on the happy path, but under degradation.

For every critical feature ask:

- What if the network disappears?
- What if the tab reloads?
- What if the service worker is old?
- What if storage is full?
- What if a request retries twice?
- What if two tabs act at once?
- What if content schema changes?
- What if an imported file is malicious?
- What if an AI/provider is down?
- What if the latest deploy is bad?
- What learner work must never be lost?

If those questions have no concrete answer:

the system is not hardened.

**OFFLINE WITHOUT CORRUPTION.**
**CACHE WITHOUT STALENESS LIES.**
**MIGRATE WITHOUT DATA LOSS.**
**OPTIMIZE AFTER MEASUREMENT.**
**SECURE EVERY TRUST BOUNDARY.**
**ROLLBACK BEFORE RELEASE.**


---

# P14 HARDENING ADDENDUM
## FINAL COMPLETENESS PASS BEFORE P15

This addendum closes the remaining engineering edge cases that usually appear only after real browser upgrades, storage eviction, background sync, content rollback, deployment races and supply-chain changes.

It does not expand P14 into P15.

---

# 309. INDEXEDDB VERSIONCHANGE

If IndexedDB schema changes while another tab keeps an old connection, handle `versionchange` / blocked upgrade explicitly.

Do not allow one stale tab to indefinitely block required migration without user-visible recovery.

---

# 310. INDEXEDDB BLOCKED UPGRADE UX CONTRACT

Expose a recoverable state such as `DATABASE_UPGRADE_BLOCKED` to P13.

User may need to close/reload stale tabs.

Do not silently hang startup.

---

# 311. INDEXEDDB TRANSACTION ABORT

Any transaction abort affecting learner draft, attempt, SRS state or scenario state must surface failure and preserve retry/recovery.

Never show `Saved` after an aborted authoritative transaction.

---

# 312. STORAGE EVICTION CLASSES

Classify local data as:

`REGENERABLE`

`RE-DOWNLOADABLE`

`SYNCED_RECOVERABLE`

`UNSYNCED_CRITICAL`.

Storage cleanup must protect `UNSYNCED_CRITICAL` data first.

---

# 313. PERSISTENT STORAGE

Where browser support and offline product value justify it, request persistent storage only through a deliberate flow.

Do not assume the browser grants it.

---

# 314. STORAGE EVICTION DETECTION

If an expected pack/state disappears, distinguish:

- user removal;
- browser eviction;
- migration;
- corruption.

Recovery differs by cause.

---

# 315. CACHE/DB CROSS-CHECK

If pack metadata says an asset is installed but Cache Storage lacks it, mark the pack degraded.

Do not report full installation.

---

# 316. PACK REPAIR

A degraded pack may repair only missing/invalid assets when architecture supports it.

Verify again before restoring `READY` state.

---

# 317. PACK INSTALL JOURNAL

Large pack installation should track staged steps so crash/reload can resume or clean incomplete staging safely.

Staged files are never active files.

---

# 318. PACK UNINSTALL

Uninstall removes pack-owned disposable assets but preserves:

- learner state;
- shared assets still referenced;
- audit/history metadata where required.

---

# 319. SHARED-ASSET OWNERSHIP

Use manifest/dependency information so removal of one pack cannot delete an asset still needed by another.

---

# 320. CONTENT DOWNGRADE

If application code rolls back, the older build must not load incompatible newer local state/content blindly.

Compatibility gate first.

---

# 321. BACKWARD MIGRATION BOUNDARY

Do not guess destructive backward migrations.

Prefer compatible forward schema, last-known-good snapshot or read-only recovery.

---

# 322. SERVICE-WORKER RACE

Test:

- first load during deploy;
- two tabs controlled by different worker generations;
- worker activation during pack download;
- old HTML with new chunks;
- new HTML with stale cache.

No mixed-version corruption.

---

# 323. BACKGROUND SYNC IS OPTIONAL

Core correctness cannot depend on Background Sync or Periodic Sync support.

A foreground recovery path is mandatory.

---

# 324. BACKGROUND-SYNC DUPLICATE DELIVERY

Queued operations may execute more than once.

Use idempotency for authoritative writes.

---

# 325. AUTH EXPIRY DURING SYNC

If queued operation reaches server after auth expires:

preserve it;

mark `REAUTH_REQUIRED`;

resume after authorization.

Do not discard the learner work.

---

# 326. OFFLINE OFFICIAL-ASSESSMENT POLICY

Explicitly define whether official assessment may start/submit offline.

If allowed, require:

- immutable local attempt identity;
- answer-key isolation;
- idempotent sync;
- time semantics;
- conflict handling.

If not allowed, do not silently downgrade an official attempt to practice.

---

# 327. OFFLINE FIRST-ATTEMPT IDENTITY

An offline first attempt receives one stable attempt ID that survives retries and reconnect.

---

# 328. CLIENT CLOCK TRUST

Client clock alone is not reliable for high-stakes timing/deadlines.

Preserve work even if timestamp is suspect; mark timing metadata for review.

---

# 329. BROWSER UPDATE REGRESSION

Supported current browser releases can alter storage, media, PWA or speech behavior.

Re-run relevant P14/P15 slices when support baseline changes.

---

# 330. MEDIA CODEC COMPATIBILITY

Downloaded audio/video formats must work on supported device/browser targets.

Provide alternate encoding only when evidence shows need.

---

# 331. RANGE REQUEST SAFETY

If media seeking/resume uses HTTP ranges, test CDN/service-worker behavior.

A partial response must never be cached as a complete file.

---

# 332. DOWNLOAD RESUME INTEGRITY

Resume must confirm resource revision/ETag/checksum where appropriate.

Never concatenate bytes from different asset versions.

---

# 333. PACK AUTHENTICITY

Use standard platform security such as HTTPS plus manifest integrity/checksum.

If signed packages are later adopted, use established cryptographic primitives only.

---

# 334. THIRD-PARTY ORIGIN MINIMIZATION

Every origin added to CSP/connect/media/font trust surface needs a reason.

Remove unused origins.

---

# 335. SERVICE-WORKER SCOPE

The worker must not unintentionally control unrelated application routes.

---

# 336. USER-SPECIFIC CACHE ISOLATION

Protected/user-specific responses must not be shared across accounts through service-worker cache.

Prefer not caching protected data unless deliberately designed.

---

# 337. LOGOUT / ACCOUNT SWITCH

On logout or account switch:

- isolate/clear user-specific local data according to policy;
- preserve public course packs where safe;
- never expose previous learner drafts/history to the next account.

---

# 338. MULTI-ACCOUNT LOCAL NAMESPACE

If multiple accounts can use one browser profile sequentially, learner-local state is namespaced by account identity.

---

# 339. OFFLINE AUTH BOUNDARY

If previously authenticated users may access offline content, explicitly define accessible data and limits.

Do not invent indefinite offline authorization.

---

# 340. BUILD REPRODUCIBILITY

Record enough to reproduce/compare a release:

- source SHA;
- lockfile;
- toolchain/runtime versions where material;
- build config;
- content snapshot.

---

# 341. SBOM / DEPENDENCY MANIFEST

Generate an SBOM if tooling supports it; otherwise maintain a production dependency inventory.

---

# 342. LICENSE AUDIT

Review dependency/media/content licenses where distribution requires it.

Security PASS does not imply licensing PASS.

---

# 343. UNUSED SECRET / ENV CLEANUP

Remove obsolete secrets and environment variables.

An unused credential remains risk.

---

# 344. CONFIG SCHEMA

Validate required configuration at build/startup.

Unknown or insecure production defaults fail safe.

---

# 345. CONFIG DRIFT

Document material differences between preview/staging/production that can change acceptance behavior.

---

# 346. STABLE ERROR CONTRACT

Prefer machine-readable error codes for API/action failures.

P13 maps them to learner/admin messages.

Do not branch application logic on arbitrary English error text.

---

# 347. GRACEFUL-DEGRADATION MATRIX

For every external dependency map:

`DEPENDENCY → FEATURES AFFECTED → FALLBACK → USER IMPACT`.

AI/provider/analytics outages must not automatically become whole-app outage.

---

# 348. OBSERVABILITY + SNAPSHOT ID

Critical traces should include application build and content snapshot identity.

This is necessary for mixed content/code incident diagnosis.

---

# 349. MIGRATION FORENSICS

Migration failure logs identify:

- from/to version;
- step;
- store;
- error code;
- recovery status.

Avoid logging full sensitive payloads.

---

# 350. USER ERROR REPORT MINIMIZATION

Attach safe diagnostics such as build, route and content ID automatically.

Do not automatically upload full draft, recording or private source.

---

# 351. SANITIZER REGRESSION FIXTURES

Include hostile fixtures for:

- script tag;
- event handler;
- javascript URL;
- SVG payload;
- malformed Markdown;
- encoded bypass attempts.

---

# 352. UPLOAD/IMPORT SECURITY FIXTURES

Include:

- oversized file;
- wrong MIME;
- renamed executable;
- zip-slip path;
- decompression-bomb characteristics;
- CSV formula cell;
- deeply nested JSON.

---

# 353. AUTHORIZATION REGRESSION FIXTURES

Include:

- contributor activates;
- reviewer changes role;
- revoked stale session;
- cross-user resource ID;
- hidden button called directly through API.

---

# 354. CSP REGRESSION

Verify security headers do not break legitimate:

- audio/video;
- fonts;
- AI/backend;
- OAuth;
- PWA.

---

# 355. DEPENDENCY-UPDATE POLICY

Classify updates:

`SECURITY`

`PATCH`

`MINOR`

`MAJOR`.

Regression depth follows actual risk.

Avoid unrelated major dependency upgrades during RC preparation unless necessary.

---

# 356. ACCEPTED SECURITY RISK

If a vulnerability cannot be removed before release, record:

- severity;
- exploitability;
- affected path;
- mitigation;
- owner;
- revalidation trigger.

P15/P16 evaluate release readiness.

---

# 357. PERFORMANCE REGRESSION GATES

After baseline, define gates per critical journey.

Do not rely only on total bundle size.

---

# 358. PERFORMANCE NOISE

Repeat noisy measurements and compare consistent conditions.

One anomalous run is not enough for a release verdict.

---

# 359. MEMORY-LEAK GATE

Representative long sessions should stabilize after repeated mount/unmount/recording/AI cycles rather than grow unbounded.

---

# 360. CPU / BATTERY

Investigate continuous high CPU caused by timers, polling, animation or retries on mobile.

Do not run expensive background work without user value.

---

# 361. SEARCH-INDEX STAGED SWITCH

Build/verify derived search index before making it active.

If index fails, canonical navigation remains available.

---

# 362. CONTENT CORRUPTION QUARANTINE

If one active entity fails parse/schema, isolate/report it where safe rather than blanking the whole subject.

If corruption affects canonical owner broadly, rollback snapshot.

---

# 363. LEARNER-STATE CORRUPTION RECOVERY

Preserve a forensic backup of malformed local state when feasible.

Recover from synced/event source if available.

Never silently reset mastery/attempts.

---

# 364. ATTEMPT CORRUPTION

Official attempt evidence is high priority.

Quarantine and alert rather than overwrite with guessed defaults.

---

# 365. DRAFT CORRUPTION

Offer raw export/recovery where possible.

---

# 366. P14 GOLDEN ENGINEERING REGRESSION SET

Maintain fixed fixtures for:

- mixed service-worker generations;
- blocked IndexedDB upgrade;
- storage eviction;
- incomplete pack install;
- offline first-attempt retry;
- auth expiry during sync;
- account switch isolation;
- app downgrade compatibility;
- corrupt derived index;
- stored XSS;
- authorization bypass;
- malicious archive;
- stale chunk after deploy;
- backup/restore smoke.

---

# 367. P14 REVALIDATION TRIGGERS

Revalidate affected slices when:

- browser support changes;
- service worker/cache changes;
- storage schema changes;
- auth/backend changes;
- deployment platform changes;
- dependency major changes;
- security policy changes;
- content schema changes;
- P15 finds cross-system defects.

---

# 368. P14 PROMPT COMPLETENESS GATE — HARDENED

P14 is fully hardened only if it covers:

1. offline modes;
2. service-worker races;
3. cache categories;
4. storage eviction;
5. IndexedDB upgrade;
6. offline packs;
7. sync/auth expiry;
8. offline assessment boundary;
9. version/downgrade compatibility;
10. migrations;
11. performance;
12. memory/CPU;
13. media/resume;
14. retry/idempotency;
15. threat model;
16. XSS/sanitization;
17. CSP/headers;
18. secrets/config;
19. authorization;
20. account isolation;
21. import/upload security;
22. dependencies/SBOM/licenses;
23. build reproducibility;
24. environment drift;
25. observability;
26. backup/restore;
27. corruption recovery;
28. deploy rollback;
29. golden engineering regression;
30. P15 handoff.

If all are defined:

`P14 PROMPT STATUS: COMPLETE / HARDENED / READY TO EXECUTE`.

**P14 PROMPT HARDENING COMPLETE**

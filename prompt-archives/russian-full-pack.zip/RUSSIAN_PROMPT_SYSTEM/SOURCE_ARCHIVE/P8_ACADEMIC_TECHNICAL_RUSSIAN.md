# P8 — ACADEMIC & TECHNICAL RUSSIAN DEEPENING CONSTITUTION
## MATHEMATICS · CS · DATABASE · AI/ML · NETWORKS/OS · CONTROL · STATISTICS · OPTIMIZATION · EXPERIMENT · TECHNICAL COMMUNICATION

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Primary curriculum targets:

- R10 preparatory academic bridge where relevant.
- R11–R14 university/lecture bridge.
- R15–R18 technical Russian.
- R19–R21 research/seminar language where technical content is required.

Execution mode:

**AUTONOMOUS · P7-VALIDATED · CONCEPT-FIRST · FUNCTION-FIRST · DOMAIN-AWARE · PRODUCTION-ORIENTED · TOKEN-EFFICIENT · NO-GLOSSARY-ONLY**

---

# P8 CHANGELOG

- 2026-09-30 — Full deep P8 constitution created.
- 2026-09-30 — Final hardening: versioned terminology, standards, notation/units, technical truth reproducibility, polysemy, golden regression, domain dependencies and P9 handoff.

---

# 0. MISSION

P8 turns validated Russian language into a **deep academic and technical language system**.

The objective is not:

“add more technical words”.

The objective is:

> enable the learner to understand, explain, compare, troubleshoot, discuss and present technical concepts in Russian.

P8 must build a bridge:

`GENERAL RUSSIAN`

→ `UNIVERSITY RUSSIAN`

→ `ACADEMIC REASONING`

→ `TECHNICAL CONCEPT LANGUAGE`

→ `LECTURE / LAB / DOCUMENTATION`

→ `TECHNICAL ORAL PRODUCTION`

→ `RESEARCH DISCUSSION`.

---

# 1. P8 FOUNDATION DEPENDENCIES

P8 consumes:

### From P2
- curriculum progression;
- R01–R26 map;
- skill targets;
- technical domains.

### From P3
- canonical schemas;
- stable IDs;
- content owners;
- technical concept model;
- academic function model.

### From P4
- objective/competency alignment;
- performance evidence;
- stage gates;
- assessment boundaries.

### From P5
- domain focus;
- adaptive priority;
- skill balancing.

### From P6
- listening/speaking interaction;
- dialogue runtime;
- Deep Speaking;
- recording/evidence.

### From P7
- linguistic authority;
- validated terminology;
- stress;
- morphology;
- government;
- register;
- academic phrase validation;
- terminology conflicts;
- source hierarchy;
- generated-content activation policy.

P8 must not redefine P7 truth.

---

# 2. P8 OWNERSHIP

P8 owns:

- academic technical curriculum depth;
- technical concept sequencing;
- domain language maps;
- concept-to-language mapping;
- technical collocations;
- technical explanation frames;
- lecture technical language content;
- lab language content;
- problem-solving discourse;
- formula/symbol language content;
- diagram/architecture explanation language;
- technical comparison language;
- error/debugging language;
- experiment/result language;
- cross-domain academic functions;
- technical performance tasks specification;
- domain coverage matrices.

P8 does NOT own:

- lexical canonical truth itself if P3/P7 owner exists;
- mastery;
- SRS;
- audio engine;
- AI Mentor;
- UI shell;
- final ВКР writing system;
- production release.

---

# 3. NON-GOALS

P8 is not:

- a dictionary import;
- a 10,000-term glossary;
- machine-translated English textbook;
- subject-matter degree course replacing Bauman classes;
- code tutorial;
- mathematics tutorial;
- AI textbook;
- control theory textbook.

P8 teaches **Russian needed to access and communicate technical content**.

Technical explanations may contain enough domain meaning for language practice, but domain truth must remain accurate.

---

# 4. CENTRAL DESIGN RULE

Every technical content unit should connect:

`CONCEPT`

→ `TERM`

→ `MORPHOLOGY`

→ `COLLOCATION`

→ `DEFINITION`

→ `EXPLANATION`

→ `FORMULA/DIAGRAM/TEXT`

→ `LISTENING`

→ `QUESTION`

→ `ORAL RESPONSE`

→ `WRITTEN RESPONSE`

→ `TRANSFER`.

If content stops at:

`TERM → VIETNAMESE TRANSLATION`

it fails P8.

---

# 5. TECHNICAL LANGUAGE IS NOT JUST VOCABULARY

Technical competence includes:

- nouns;
- verbs;
- adjectives;
- collocations;
- grammar;
- syntax;
- discourse;
- formula reading;
- symbols;
- argumentation;
- register;
- task instructions;
- error explanation;
- process description;
- comparison;
- cause/effect;
- limitation;
- result interpretation.

P8 must cover all relevant layers.

---

# 6. ACADEMIC FUNCTION CORE

P8 uses a reusable academic function set:

- define;
- name;
- classify;
- enumerate;
- describe;
- explain;
- sequence;
- compare;
- contrast;
- quantify;
- estimate;
- calculate;
- derive;
- prove;
- assume;
- condition;
- cause;
- consequence;
- purpose;
- method;
- result;
- interpretation;
- limitation;
- advantage;
- disadvantage;
- requirement;
- constraint;
- dependency;
- recommendation;
- conclusion;
- question;
- clarification;
- disagreement;
- justification.

These functions cut across domains.

---

# 7. ACADEMIC FUNCTION ≠ TEMPLATE MEMORIZATION

Each function must support:

1. recognition;
2. controlled substitution;
3. paraphrase;
4. domain variation;
5. oral production;
6. written production;
7. transfer to unfamiliar content.

Do not consider a phrase mastered because learner copied it.

---

# 8. ACADEMIC REGISTER LADDER

Differentiate:

`NEUTRAL_EXPLANATORY`

`CLASSROOM_TECHNICAL`

`FORMAL_TECHNICAL`

`ACADEMIC_WRITTEN`

`SEMINAR_ORAL`

`DEFENSE_ORAL`.

The same concept may use different constructions by register.

---

# 9. ORAL VS WRITTEN TECHNICAL RUSSIAN

P8 must distinguish:

### Oral
- shorter clauses;
- discourse markers;
- repair;
- clarification;
- reformulation;
- lecturer transitions.

### Written
- denser noun phrases;
- nominalization;
- participial structures where appropriate;
- formal connectors;
- compact technical descriptions.

Do not force written academic syntax into beginner oral production.

---

# 10. B1 → B2 TECHNICAL PROGRESSION

### B1 bridge
Learner can:
- understand basic technical task;
- identify object/process/result;
- explain simple steps;
- use core terminology.

### B1+
Learner can:
- compare methods;
- explain causes;
- describe system structure;
- summarize technical text.

### B2 functional target
Learner can:
- explain unfamiliar but supported technical concept;
- discuss method/result;
- interpret graph/table;
- defend a technical choice;
- follow lecture structure;
- answer follow-up questions.

No formal certification claim is implied.

---

# 11. DOMAIN ARCHITECTURE

P8 organizes domains at minimum:

1. Academic Core.
2. Mathematics & Formal Language.
3. Programming & Software Engineering.
4. Algorithms & Data Structures.
5. Operating Systems & Linux.
6. Computer Networks.
7. Databases & SQL.
8. Data & Data Processing.
9. AI / Machine Learning.
10. Probability & Statistics.
11. Optimization / Operations Research.
12. Control & Automation.
13. Signals / Measurement / Sensors.
14. Simulation & Experiments.
15. Research Methods Bridge.

Not every domain requires equal depth.

Priority follows Bauman curriculum/repository evidence.

---

# 12. DOMAIN PRIORITY POLICY

Classify each domain:

`CORE`

`HIGH_PRIORITY`

`SUPPORTING`

`REFERENCE`

based on:

- current curriculum;
- degree direction;
- prerequisites;
- actual course use;
- learner needs.

Do not expand low-priority domain just because terms are easy to generate.

---

# 13. TECHNICAL CONCEPT UNIT

Each high-value concept should have, when applicable:

- concept ID;
- Russian canonical term;
- accepted variants;
- stress;
- POS/morphology;
- definition;
- simplified Russian explanation;
- Vietnamese scaffold;
- English label if useful for disambiguation;
- prerequisites;
- related concepts;
- contrast concepts;
- collocations;
- governing constructions;
- oral example;
- written example;
- lecturer example;
- task example;
- diagram/formula relation;
- common confusion;
- speaking task;
- reading/listening refs;
- assessment refs;
- provenance/validation.

Do not require irrelevant fields.

---

# 14. CONCEPT RELATIONS

Useful relations:

`IS_A`

`PART_OF`

`HAS_INPUT`

`HAS_OUTPUT`

`USES`

`PRODUCES`

`DEPENDS_ON`

`CONTROLS`

`MEASURES`

`OPTIMIZES`

`CONTRASTS_WITH`

`CAUSES`

`REPRESENTED_BY`

`PREREQUISITE_FOR`.

These relations support language tasks.

Do not build an overly complex ontology unrelated to learning.

---

# 15. CONCEPT CLUSTERS

Teach concepts in meaningful clusters.

Example AI cluster:

dataset
→ feature
→ model
→ training
→ validation
→ inference
→ metric.

Avoid alphabetical glossary sequence.

---

# 16. TERM INTRODUCTION RULE

When introducing a term:

first provide meaningful context.

Then:

- form;
- meaning;
- collocations;
- use.

Do not start every concept with a dictionary-style definition if level is too low.

---

# 17. TERM RECYCLING

A technical term should recur across:

- explanation;
- lecture/listening;
- problem statement;
- diagram;
- speaking;
- writing;
- review;
- performance task.

One flashcard exposure is insufficient.

---

# 18. TECHNICAL ACTIVE VS PASSIVE VOCABULARY

Classify:

`ACTIVE_CORE`

`ACTIVE_DOMAIN`

`PASSIVE_RECOGNITION`

`REFERENCE`.

Learner does not need to produce every specialized term.

---

# 19. MORPHOLOGY OF TECHNICAL TERMS

P8 must expose forms actually needed in technical discourse:

- nominative naming;
- genitive chains;
- prepositional topic/location;
- instrumental method/tool;
- adjective agreement;
- plural;
- verb government.

Do not dump full declension tables unless useful.

---

# 20. TECHNICAL VERBS

High-value technical verbs include functional families such as:

- calculate;
- determine;
- define;
- measure;
- process;
- store;
- transmit;
- receive;
- compare;
- evaluate;
- train;
- predict;
- control;
- regulate;
- model;
- simulate;
- optimize;
- analyze;
- prove;
- derive;
- depend;
- affect;
- consist;
- contain;
- use;
- provide.

Actual Russian forms must be P7-validated.

---

# 21. VERB + GOVERNMENT IN TECHNICAL LANGUAGE

Teach technical verbs with their frames.

Not:

`зависеть = depend`.

But:

conceptually:

`depend on + required Russian construction`.

P7 owns correctness.

P8 owns curricular use.

---

# 22. NOMINALIZATION

Academic/technical Russian frequently uses nominal structures.

P8 should teach progression from:

simple verb clause

→ nominalized technical expression

when level permits.

Do not overload early B1 learners.

---

# 23. GENITIVE CHAINS

Teach comprehension and production of technical noun chains gradually.

Learner must identify:

head noun

vs dependent nouns.

Do not encourage unreadable chains in oral speech.

---

# 24. PASSIVE STRUCTURES

Teach passive constructions when needed for:

- process description;
- method;
- experiment;
- formal writing.

Contrast with active forms.

Avoid implying passive is always “more academic”.

---

# 25. PARTICIPIAL CONSTRUCTIONS

Introduce only when useful for advanced reading/writing.

Priorities:

- recognition first;
- controlled transformation;
- production later.

Do not make B1 technical speaking dependent on complex participles.

---

# 26. SHORT PARTICIPLES / RESULT STATES

If used in technical Russian:

teach functionally in descriptions such as:

“configured”, “connected”, “obtained”, “measured”.

Correct forms must be P7 validated.

---

# 27. MODALITY

Technical language needs:

- must;
- should;
- can;
- may;
- required;
- allowed;
- prohibited;
- possible;
- impossible.

Teach difference between:

requirement

recommendation

possibility.

Critical for assignments and specifications.

---

# 28. CONDITION LANGUAGE

Learner must understand:

- if;
- when;
- provided that;
- in case;
- under condition.

Connect to algorithms, experiments and system behavior.

---

# 29. CAUSE / EFFECT

Technical frames:

cause

→ mechanism

→ effect.

Learner must move beyond generic “because”.

Teach multiple register-appropriate constructions.

---

# 30. PURPOSE LANGUAGE

Needed for:

- “used to”;
- “designed for”;
- “in order to”;
- function of component;
- research purpose.

---

# 31. REQUIREMENT & CONSTRAINT LANGUAGE

Critical concepts:

- requirement;
- constraint;
- limit;
- condition;
- tolerance;
- threshold.

Tasks should include reading specifications.

---

# 32. COMPARISON LANGUAGE

Learner must compare:

- algorithms;
- models;
- controllers;
- datasets;
- methods;
- results.

Functions:

- same/different;
- faster/slower;
- more/less accurate;
- stable/unstable;
- simpler/more complex;
- advantage/disadvantage.

---

# 33. QUANTITATIVE COMPARISON

Teach how to express:

- increase/decrease;
- difference;
- ratio;
- percentage;
- approximately;
- more than/less than;
- order of magnitude where appropriate.

Use validated Russian numerical conventions from P7.

---

# 34. APPROXIMATION & UNCERTAINTY

Technical language should include:

- approximately;
- about;
- estimated;
- likely;
- within error;
- uncertain.

Do not teach false precision.

---

# 35. HEDGING

Advanced academic/technical language must distinguish:

claim

vs cautious interpretation.

Examples functionally:

- suggests;
- may indicate;
- likely;
- cannot conclude.

P7 validates phrases.

---

# 36. DEFINITION FRAME

Learner should be able to:

1. name concept;
2. classify it;
3. state defining property;
4. give simple example.

Use different complexity by level.

---

# 37. PROCESS DESCRIPTION FRAME

Structure:

input

→ transformation

→ intermediate state

→ output.

Useful across:

algorithms;
data processing;
control;
experiments.

---

# 38. SYSTEM DESCRIPTION FRAME

Structure:

purpose

→ components

→ connections

→ data/signal flow

→ output

→ failure/limitation.

---

# 39. ALGORITHM EXPLANATION FRAME

Learner should express:

- input;
- initialization;
- step;
- condition;
- loop;
- output;
- complexity at advanced level;
- edge case.

Do not translate code syntax into Russian words unnecessarily.

---

# 40. ARCHITECTURE DESCRIPTION FRAME

For diagrams:

- component A connects to B;
- data flows from X to Y;
- module handles responsibility;
- service calls API;
- storage persists data.

Language must be natural Russian technical prose.

---

# 41. ERROR / DEBUGGING FRAME

Learner needs language for:

- error occurs;
- expected behavior;
- actual behavior;
- reproduce;
- cause;
- log;
- fix;
- test;
- regression.

This domain is high-value for technical study.

---

# 42. TROUBLESHOOTING DIALOGUE

P8 specifies content for scenarios:

student ↔ lab partner;

student ↔ teacher;

student ↔ admin/IT support;

student ↔ project teammate.

P11 later integrates full scenarios.

---

# 43. TECHNICAL QUESTION TYPES

Learner should understand questions asking:

- what;
- why;
- how;
- under what condition;
- which method;
- compare;
- prove;
- derive;
- calculate;
- explain error;
- interpret result.

Question language must be explicitly taught.

---

# 44. CLASSROOM TECHNICAL COMMANDS

Examples functionally:

- calculate;
- derive;
- prove;
- construct;
- plot;
- compare;
- explain;
- justify;
- implement;
- test;
- analyze.

Use real Russian classroom wording validated by P7.

---

# 45. ASSIGNMENT LANGUAGE

Teach how to read:

- objective;
- task list;
- input data;
- required output;
- constraints;
- deadline;
- report format;
- evaluation criteria.

---

# 46. LAB INSTRUCTION LANGUAGE

Learner must understand:

- connect;
- configure;
- start;
- stop;
- measure;
- record;
- change parameter;
- repeat;
- calculate;
- compare;
- conclude.

---

# 47. SAFETY / WARNING LANGUAGE

Where technical labs include warning language:

teach recognition of:

- caution;
- do not;
- must disconnect;
- limit;
- prohibited.

Do not invent safety procedures.

Only teach validated language from course/material context.

---

# 48. MATHEMATICS DOMAIN — SCOPE

P8 Mathematics language includes:

- numbers;
- sets;
- variables;
- constants;
- expressions;
- equations;
- inequalities;
- functions;
- graphs;
- sequences;
- vectors;
- matrices;
- derivatives;
- integrals;
- probability;
- optimization bridge.

Focus is language access.

---

# 49. MATHEMATICAL SYMBOL READING

Use P7-validated expressions for:

- equality;
- inequality;
- addition/subtraction;
- multiplication/division;
- powers;
- roots;
- subscripts;
- superscripts;
- brackets;
- intervals;
- vectors;
- matrices;
- summation if needed;
- derivatives/integrals.

---

# 50. MATHEMATICAL STATEMENT FRAME

Learner should recognize:

- given;
- find;
- prove;
- let;
- suppose;
- follows;
- therefore;
- for all;
- exists;
- condition.

Do not require formal logic jargon too early.

---

# 51. FUNCTION & GRAPH LANGUAGE

Teach:

- domain/range where relevant;
- increasing/decreasing;
- maximum/minimum;
- intersection;
- slope;
- dependence;
- graph behavior.

---

# 52. EQUATION SOLVING LANGUAGE

Learner should narrate:

- substitute;
- simplify;
- solve;
- move term;
- divide/multiply;
- obtain value;
- verify.

Language should match actual Russian instructional style.

---

# 53. MATRIX / VECTOR LANGUAGE

Teach core terms and operations needed by target coursework.

Avoid expanding into full linear algebra course.

---

# 54. CALCULUS LANGUAGE

Recognize/explain:

- derivative;
- rate/change;
- integral;
- limit;
- function behavior.

Depth follows actual curriculum.

---

# 55. PROGRAMMING DOMAIN — SCOPE

Include:

- variable;
- type;
- value;
- function;
- method;
- parameter;
- argument;
- return value;
- class;
- object;
- interface;
- loop;
- condition;
- exception/error;
- file;
- library;
- package/module;
- API.

Terms validated by P7.

---

# 56. CODE-SAFE RUSSIAN

Learner must distinguish:

natural-language Russian

from code tokens.

Example tasks:

explain code without translating identifiers.

Describe what function does.

Report error message.

---

# 57. PROGRAM EXECUTION LANGUAGE

Teach:

- starts;
- calls;
- returns;
- allocates;
- reads;
- writes;
- loads;
- processes;
- throws error;
- terminates.

---

# 58. DATA STRUCTURES DOMAIN

Core concepts:

- array/list;
- stack;
- queue;
- tree;
- graph;
- hash structure;
- key/value.

Only actual priority depth.

---

# 59. ALGORITHM COMPLEXITY LANGUAGE

At suitable level:

- time;
- memory;
- complexity;
- worst/best/average case if needed;
- grows;
- proportional.

Do not overteach formal notation without course relevance.

---

# 60. OPERATING SYSTEMS DOMAIN

Potential core:

- process;
- thread;
- memory;
- file system;
- permission;
- user;
- kernel;
- scheduling;
- resource.

Prioritize based on curriculum evidence.

---

# 61. LINUX / CLI LANGUAGE

Learner should understand Russian explanatory language around:

- command;
- option;
- path;
- directory;
- file;
- permission;
- process;
- output;
- error.

Commands remain code.

---

# 62. NETWORKS DOMAIN

Core concepts may include:

- client;
- server;
- protocol;
- packet;
- address;
- port;
- connection;
- request;
- response;
- delay;
- bandwidth;
- routing.

---

# 63. NETWORK TROUBLESHOOTING LANGUAGE

Teach language for:

- connection unavailable;
- timeout;
- packet loss;
- DNS/address issue;
- server not responding.

Technical accuracy validated by P7/domain evidence.

---

# 64. DATABASE DOMAIN — SCOPE

Core concepts:

- database;
- table;
- row/record;
- column/field;
- primary key;
- foreign key;
- relation;
- query;
- condition;
- join;
- index;
- transaction;
- normalization.

---

# 65. DATABASE SENSE DISAMBIGUATION

Terms like:

record;
field;
key;
relation;
index

must use database-specific senses.

Do not reuse everyday translation without domain marker.

---

# 66. SQL LANGUAGE

Learner needs Russian around SQL:

- select;
- filter;
- sort;
- group;
- join;
- insert;
- update;
- delete;
- transaction.

SQL keywords themselves remain code.

---

# 67. QUERY EXPLANATION TASK

Learner should be able to explain:

- what data query selects;
- condition;
- tables;
- join;
- result.

---

# 68. DATA DOMAIN

Core concepts:

- dataset;
- record/sample;
- variable/feature;
- label/target;
- missing value;
- preprocessing;
- normalization/standardization;
- split;
- training/validation/test data.

Use domain-specific validated Russian.

---

# 69. AI / ML DOMAIN — SCOPE

Core concepts:

- artificial intelligence;
- machine learning;
- model;
- algorithm;
- dataset;
- feature;
- target;
- training;
- validation;
- test;
- prediction;
- inference;
- error/loss;
- metric;
- neural network where relevant.

---

# 70. AI TERMINOLOGY CONFLICT CONTROL

P7 must validate ambiguous families such as:

- feature;
- label;
- target;
- loss;
- accuracy;
- precision;
- recall;
- inference.

P8 must teach sense/context explicitly.

---

# 71. MODEL TRAINING FRAME

Learner explains:

data

→ preprocessing

→ training

→ validation

→ evaluation

→ inference.

---

# 72. ML METRIC LANGUAGE

Teach distinction among relevant metrics.

Do not flatten multiple technical metrics into one Vietnamese/Russian word.

---

# 73. NEURAL NETWORK LANGUAGE

Only when relevant:

- layer;
- neuron;
- weight;
- input;
- output;
- activation;
- training.

Avoid unnecessary hype terminology.

---

# 74. MODEL COMPARISON

Learner should compare:

- performance;
- speed;
- memory;
- complexity;
- robustness;
- interpretability where relevant.

---

# 75. AI LIMITATION LANGUAGE

Teach:

- model error;
- bias/limitation when domain-appropriate;
- insufficient data;
- overfitting if relevant;
- generalization;
- uncertainty.

Domain truth must be validated.

---

# 76. PROBABILITY DOMAIN

Core language:

- event;
- probability;
- random variable;
- distribution;
- expectation/mean;
- variance;
- conditional probability;
- independence where needed.

---

# 77. STATISTICS DOMAIN

Core concepts:

- sample;
- population;
- statistic;
- mean;
- variance;
- standard deviation;
- hypothesis;
- confidence interval;
- correlation;
- regression where relevant.

---

# 78. STATISTICAL INTERPRETATION

Learner should say:

- result suggests;
- difference;
- uncertainty;
- sample;
- confidence.

Avoid teaching overclaiming.

---

# 79. OPTIMIZATION DOMAIN

Core language:

- objective function;
- variable;
- constraint;
- feasible solution;
- optimum;
- minimum;
- maximum;
- iteration;
- convergence where relevant.

---

# 80. OPERATIONS RESEARCH BRIDGE

If curriculum requires:

- decision;
- resource;
- scheduling;
- queue;
- state;
- transition;
- cost;
- criterion;
- optimization.

Do not expand unless actual need is verified.

---

# 81. CONTROL & AUTOMATION DOMAIN — SCOPE

Core:

- control system;
- object/plant;
- input;
- output;
- signal;
- sensor;
- actuator;
- controller;
- feedback;
- reference/setpoint;
- error;
- disturbance;
- stability;
- dynamic model;
- state.

---

# 82. CONTROL TERMINOLOGY AMBIGUITY

Terms equivalent to English:

- control;
- controller;
- plant;
- state;
- feedback;
- error;

require strict domain validation.

Do not use generic translation blindly.

---

# 83. PID LANGUAGE

Learner should understand:

- proportional;
- integral;
- derivative;
- gain/coefficient;
- response;
- overshoot;
- steady-state error where relevant;
- tuning.

Depth follows study needs.

---

# 84. CONTROL LOOP EXPLANATION

Performance frame:

setpoint

→ error

→ controller

→ actuator

→ plant

→ sensor

→ feedback.

Learner must explain signal flow.

---

# 85. STABILITY LANGUAGE

Teach basic descriptive language:

stable;
unstable;
oscillation;
response;
settling behavior

if course context requires.

Do not replace actual control theory teaching.

---

# 86. SIGNALS / MEASUREMENT DOMAIN

Core:

- signal;
- frequency;
- amplitude;
- sampling;
- noise;
- measurement;
- sensor;
- accuracy;
- error;
- calibration where relevant.

---

# 87. MEASUREMENT ERROR LANGUAGE

Distinguish:

measurement error;
uncertainty;
accuracy/precision concepts according to validated terminology.

Do not collapse them.

---

# 88. SIMULATION LANGUAGE

Learner should describe:

- model;
- parameter;
- initial condition;
- simulation;
- result;
- compare with experiment.

---

# 89. EXPERIMENT LANGUAGE

Core structure:

objective

→ equipment/setup

→ procedure

→ variables

→ measurement

→ data

→ result

→ error

→ conclusion.

---

# 90. LAB REPORT ORAL LANGUAGE

Learner should orally summarize experiment before formal writing in P9.

This creates bridge:

technical speaking

→ academic writing.

---

# 91. GRAPH LANGUAGE

P8 provides validated vocabulary/functions for:

- axis;
- variable;
- curve;
- increase;
- decrease;
- peak;
- minimum;
- stable region;
- comparison;
- trend.

P9 owns full graph-description writing/presentation progression.

---

# 92. TABLE LANGUAGE

Teach:

- row;
- column;
- value;
- category;
- comparison;
- highest/lowest;
- difference.

---

# 93. DIAGRAM LANGUAGE

Technical diagrams:

- block;
- component;
- arrow;
- connection;
- input;
- output;
- flow;
- branch;
- feedback.

---

# 94. UNIT / DIMENSION LANGUAGE

Teach how Russian expresses:

- volts;
- amperes;
- seconds;
- hertz;
- bytes;
- meters;
- degrees;
- percentages;

as required.

P7 validates grammar/format.

---

# 95. TECHNICAL NUMERACY

Learner must understand/read:

- decimal values;
- ranges;
- ratios;
- percentages;
- scientific notation;
- units.

Include listening practice because technical lectures contain many numbers.

---

# 96. LECTURE DISCOURSE CORE

Technical lecture markers:

- topic introduction;
- definition;
- transition;
- example;
- exception;
- emphasis;
- cause/result;
- summary;
- assignment.

P8 provides validated content.

P6 handles audio.

---

# 97. LECTURE COMPRESSION

Learner should learn to ignore nonessential words and extract:

- concept;
- definition;
- formula;
- example;
- instruction;
- conclusion.

---

# 98. TECHNICAL NOTE-TAKING LANGUAGE SUPPORT

P8 identifies:

- high-value abbreviations;
- symbols;
- term families.

P9 owns note-taking production system.

---

# 99. TEXTBOOK LANGUAGE

Teach patterns common in technical textbooks:

- “consider…”
- “let…”
- “denote…”
- “follows from…”
- “is defined as…”
- “is called…”
- “depends on…”
- “consists of…”.

P7 validates actual Russian formulations.

---

# 100. DOCUMENTATION LANGUAGE

Learner should understand:

- install;
- configure;
- parameter;
- option;
- requirement;
- supported;
- deprecated;
- returns;
- error;
- example.

Use real documentation style where possible.

---

# 101. SPECIFICATION LANGUAGE

Recognize:

- required;
- optional;
- shall/must-equivalent;
- allowed;
- prohibited;
- constraint;
- version.

Do not over-formalize if actual coursework uses simpler wording.

---

# 102. TECHNICAL EMAIL / CHAT BRIDGE

P8 defines technical language content for:

- reporting bug;
- asking about task;
- sending result;
- requesting clarification;
- coordinating teammate.

P9 owns writing progression.

---

# 103. SEMINAR TECHNICAL LANGUAGE

Learner should:

- present claim;
- ask technical question;
- challenge assumption;
- compare method;
- request evidence;
- clarify term;
- respond to criticism.

P9/P11 later integrate broader research/seminar scenarios.

---

# 104. TECHNICAL REPAIR LANGUAGE

When learner lacks exact term:

teach strategies:

- define by function;
- describe component;
- give example;
- compare;
- ask for term.

Communication should continue despite vocabulary gap.

---

# 105. PARAPHRASING TECHNICAL CONCEPTS

Learner should explain the same concept:

- simple Russian;
- technical Russian;
- short oral answer;
- formal written definition.

This proves semantic control.

---

# 106. NO DEFINITION COPYING

Assessment should not give mastery merely because learner reproduces exact memorized definition.

Use:

- examples;
- comparison;
- application;
- paraphrase;
- transfer.

---

# 107. CONCEPT MISCONCEPTION VS LANGUAGE ERROR

P8 must distinguish:

language error

from:

technical concept error.

P4 assessment evidence should classify where possible.

Do not “fix Russian” when the learner actually misunderstands the concept.

---

# 108. TECHNICAL ERROR TAXONOMY

Possible categories:

- term selection;
- wrong sense;
- collocation;
- government;
- formula language;
- unit;
- causal relation;
- process sequence;
- concept confusion;
- register;
- unsupported claim.

---

# 109. DOMAIN-SPECIFIC FALSE FRIENDS

Build high-value set for terms that look familiar through English but differ in Russian usage.

Only validated examples.

---

# 110. DOMAIN TERM FAMILY

Example architecture:

concept

→ noun

→ verb

→ adjective

→ collocations.

Useful for academic production.

Do not assume every concept has natural family members.

---

# 111. ACADEMIC VERB BANK

P8 should define validated reusable verbs for functions:

- analyze;
- examine;
- consider;
- define;
- calculate;
- evaluate;
- compare;
- demonstrate;
- obtain;
- propose;
- apply;
- develop;
- model;
- simulate.

P7 validates actual Russian lemmas/government.

---

# 112. ACADEMIC NOUN BANK

Functions/topics such as:

- objective;
- task;
- method;
- approach;
- model;
- result;
- data;
- error;
- limitation;
- conclusion;
- dependency;
- property;
- parameter.

---

# 113. ACADEMIC ADJECTIVE BANK

Useful technical modifiers:

- proposed;
- obtained;
- experimental;
- theoretical;
- numerical;
- initial;
- final;
- input;
- output;
- optimal;
- stable.

Only real Russian usage.

---

# 114. CONNECTOR SYSTEM

Learner should recognize/use connectors for:

- sequence;
- addition;
- contrast;
- cause;
- result;
- example;
- clarification;
- conclusion.

Avoid overusing a few textbook connectors mechanically.

---

# 115. INFORMATION STRUCTURE

Teach technical emphasis:

- what is known;
- what is new;
- what variable is being contrasted.

P7 validates language.

P8 teaches use in explanations.

---

# 116. DEFINITION → EXAMPLE → CONTRAST

A powerful micro-sequence:

1. define concept;
2. show example;
3. contrast with neighbor concept;
4. learner explains difference.

Use widely in technical domains.

---

# 117. CONCEPT CONFUSION PAIRS

Examples of pair types:

training vs inference;

accuracy vs precision;

process vs thread;

primary vs foreign key;

sensor vs actuator;

controller vs controlled object;

sample vs population.

Actual Russian labels validated by P7.

---

# 118. CONCEPT GRAPH INTEGRATION

P8 must link technical concept IDs into P3 content graph.

Edges should support:

prerequisite;
related;
contrast;
uses;
part-of.

Do not create a separate disconnected technical graph if canonical graph supports it.

---

# 119. TECHNICAL KNOWLEDGE INDEX

Technical search/index must be derived.

Search should support:

- Russian term;
- abbreviation;
- English alias;
- Vietnamese support;
- domain;
- related concept.

Canonical truth remains source entities.

---

# 120. MIXED-SCRIPT SEARCH

Support search for terms learner may type in:

- Cyrillic;
- Latin acronym;
- English technology name;
- Vietnamese concept.

Search aliases must not alter canonical display.

---

# 121. CONTENT GRANULARITY

Technical unit should not introduce 50 new terms.

Prefer:

small concept clusters

+ repeated use.

Flag excessive novelty.

---

# 122. COGNITIVE LOAD

When teaching a difficult technical concept:

reduce simultaneous linguistic novelty.

When language target is difficult:

use familiar technical concept where possible.

Do not stack both difficulties unnecessarily.

---

# 123. TECHNICAL BACKGROUND ASSUMPTION

A language module may assume some domain knowledge only if curriculum evidence supports it.

If concept is new:

provide enough simple explanation for language task.

Do not require deep subject knowledge merely to assess Russian.

---

# 124. LANGUAGE-FIRST VS CONTENT-FIRST TASKS

Classify tasks:

`LANGUAGE_FIRST`

`BALANCED`

`CONTENT_FIRST`.

Official Russian mastery should not be dominated by content knowledge outside taught scope.

---

# 125. TECHNICAL LISTENING CONTENT

P8 provides content specs for:

- short explanation;
- lab instruction;
- lecture excerpt;
- problem walkthrough;
- result interpretation.

P6 owns playback/runtime.

---

# 126. TECHNICAL SPEAKING CONTENT

P8 provides:

- explain term;
- explain process;
- compare methods;
- describe diagram;
- report error;
- summarize experiment;
- answer technical question.

P6 owns interaction/evidence.

---

# 127. TECHNICAL READING CONTENT

P8 defines source/content requirements for:

- task statement;
- textbook paragraph;
- documentation;
- lab instruction;
- abstract fragment.

P9 deepens reading pedagogy.

---

# 128. TECHNICAL WRITING CONTENT

P8 defines linguistic building blocks.

P9 owns full writing progression:

- email;
- summary;
- report;
- НИР;
- ВКР.

No duplicate writing engine.

---

# 129. PERFORMANCE TASK LADDER

### T1
Name/identify concept.

### T2
Define in simple Russian.

### T3
Explain with example.

### T4
Compare/contrast.

### T5
Explain system/process.

### T6
Interpret data/result.

### T7
Defend method/choice.

P4 owns official evidence/mastery.

---

# 130. DOMAIN PERFORMANCE TASK — MATHEMATICS

Example structure:

read expression/problem

→ state known values

→ explain operation

→ give result/interpretation.

Do not test advanced math beyond target course.

---

# 131. DOMAIN PERFORMANCE TASK — PROGRAMMING

Explain:

- purpose of code;
- input;
- main steps;
- output;
- error/edge case.

Code itself remains code.

---

# 132. DOMAIN PERFORMANCE TASK — DATABASE

Explain:

- schema/table relation;
- query purpose;
- condition;
- result;
- possible issue.

---

# 133. DOMAIN PERFORMANCE TASK — AI/ML

Explain:

- dataset;
- model;
- training;
- evaluation;
- output;
- limitation.

---

# 134. DOMAIN PERFORMANCE TASK — CONTROL

Explain:

- system;
- signal flow;
- controller;
- feedback;
- output;
- disturbance/error.

---

# 135. DOMAIN PERFORMANCE TASK — EXPERIMENT

Explain:

- objective;
- setup;
- procedure;
- measurement;
- result;
- error;
- conclusion.

---

# 136. ASSESSMENT ALIGNMENT

Every technical assessment item must map:

- objective;
- competency;
- technical concept;
- language function;
- skill.

Avoid questions that only test obscure domain facts.

---

# 137. ASSESSMENT VARIANTS

Use P7 accepted-variant policy.

Technical open responses may permit:

- synonymous term;
- alternate word order;
- valid abbreviation;
- equivalent explanation.

Do not accept technically wrong paraphrase merely because language is fluent.

---

# 138. LANGUAGE SCORE VS TECHNICAL ACCURACY

Where needed separate:

`LANGUAGE_PERFORMANCE`

from:

`TECHNICAL_ACCURACY`.

Do not hide which one caused failure.

---

# 139. ADAPTIVE DOMAIN FOCUS

P5 may prioritize:

AI;
DB;
Control;
Math;
Research.

P8 provides domain-tagged canonical tasks.

No duplicate domain curriculum.

---

# 140. ACTIVE TECHNICAL VOCAB ACTIVATION

When learner enters domain:

activate high-value technical vocabulary.

Do not activate entire reference glossary.

---

# 141. SPACED TECHNICAL REVIEW

Review should include:

- term recognition;
- phrase/collocation;
- oral explanation;
- reading occurrence;
- comparison.

Not only flashcards.

---

# 142. TECHNICAL PREREQUISITE GRAPH

Examples:

database query language

requires:

basic DB concept vocabulary.

AI evaluation language

requires:

basic statistical comparison.

Control explanation

requires:

system/input/output/signal vocabulary.

Do not overconstrain cross-domain dependencies.

---

# 143. R10 BRIDGE

R10 should introduce:

- technical classroom instructions;
- basic math/CS words;
- simple definitions;
- short technical problem statements.

Do not push B2 academic syntax into R10.

---

# 144. R11 ACADEMIC OPERATIONS SUPPORT

P8 contributes language for:

- task requirements;
- course terms;
- project roles;
- technical questions.

---

# 145. R12 MATHEMATICAL RUSSIAN

R12 should contain coherent units for:

- symbols/numbers;
- equation language;
- functions;
- vectors/matrices;
- probability bridge;
- calculus language according to course need;
- formula oral explanation.

Exit task:

explain a simple mathematical object/process in Russian.

---

# 146. R13 TECHNICAL PROBLEM SOLVING

Core language:

problem

→ requirement

→ input

→ method

→ step

→ result

→ error

→ solution

→ justification.

---

# 147. R14 LECTURE SURVIVAL

P8 defines technical lecture vocabulary/functions.

P6 provides audio.

P9 may later deepen note-taking.

Exit:

understand structure of a mini technical lecture.

---

# 148. R15 SOFTWARE / CS

Recommended units:

- program structure;
- variables/types;
- functions;
- objects/classes;
- algorithms;
- errors/debugging;
- OS/files/network bridge.

Actual unit split follows audit.

---

# 149. R16 DATA · DATABASE · AI

Recommended units:

- data;
- relational DB;
- SQL/query language;
- dataset/preprocessing;
- model/training;
- validation/evaluation;
- inference/results.

Do not overload one R16 unit with entire AI curriculum.

---

# 150. R17 CONTROL · AUTOMATION

Recommended units:

- system/input/output;
- signals;
- sensor/actuator;
- feedback;
- controller;
- PID;
- stability;
- state/model;
- comparison of approaches.

---

# 151. R18 EXPERIMENT / REPORT BRIDGE

Recommended units:

- objective/setup;
- procedure;
- measurement;
- data;
- graph/table;
- error/uncertainty;
- result;
- oral conclusion.

P9 owns full writing system.

---

# 152. R19 RESEARCH LANGUAGE BRIDGE

P8 contributes technical/academic concept language:

- research problem;
- relevance;
- objective;
- variables/data;
- method.

P9 owns complete research production.

---

# 153. R20 METHODS / LITERATURE

P8 contributes language for:

- method comparison;
- data/source description;
- technical evidence;
- limitations.

---

# 154. R21 SEMINAR

P8 contributes technical argumentation:

- claim;
- reason;
- evidence;
- method comparison;
- technical objection;
- clarification.

P11 later builds full simulation.

---

# 155. MICRO-LESSON ARCHITECTURE

A technical micro-lesson should usually focus on one or a small coherent set of objectives.

Possible rhythm:

`CONTEXT`

→ `NOTICE TERM/FUNCTION`

→ `UNDERSTAND CONCEPT`

→ `MODEL LANGUAGE`

→ `CONTROLLED USE`

→ `RETRIEVE`

→ `EXPLAIN`

→ `TRANSFER`.

---

# 156. MICRO-LESSON EXAMPLE: DATASET

Possible sequence:

M1:
recognize term in context.

M2:
understand simple definition.

M3:
learn collocations.

M4:
listen to explanation.

M5:
distinguish dataset vs sample/record if relevant.

M6:
explain dataset in 30 seconds.

M7:
use in model-training explanation.

Not necessarily seven screens; architecture only.

---

# 157. MICRO-LESSON EXAMPLE: FEEDBACK CONTROL

Possible:

identify components

→ learn relation verbs

→ read block diagram

→ listen to explanation

→ describe signal flow

→ answer follow-up.

---

# 158. REUSABLE ACADEMIC FRAMES

Store reusable function patterns separately from domain concept.

Examples conceptually:

- X is defined as...
- X consists of...
- X depends on...
- X is used for...
- The difference between X and Y is...
- The result shows...
- The limitation is...

P7 validates actual Russian.

---

# 159. SLOT-FILLING → FREE PRODUCTION

Academic frames progression:

full model

→ replace one slot

→ replace multiple slots

→ choose suitable frame

→ paraphrase

→ free production.

---

# 160. NO TEMPLATE LOCK-IN

If learner always outputs exactly one memorized sentence:

mastery not established.

Assessment uses variation.

---

# 161. TERMINOLOGY DENSITY

Technical text should control term density.

Too many new terms destroy language learning.

Add validator/metric candidate:

`newTechnicalTermsPerUnit`.

Use as flag, not hard universal threshold.

---

# 162. ABBREVIATION DENSITY

Likewise flag units overloaded with abbreviations.

Introduce full form before shorthand when appropriate.

---

# 163. CROSS-DOMAIN TERM COLLISION

Same Russian/English-like token may differ by domain.

Use sense/domain IDs.

Search should disambiguate.

---

# 164. TRANSLATION SUPPORT POLICY

Vietnamese helps initial comprehension.

Progression:

RU + VI

→ RU + simple RU definition

→ RU dominant

→ academic/technical Russian only.

Do not remove VI support abruptly.

---

# 165. ENGLISH SUPPORT POLICY

English can help disambiguate technical terms when learner already knows English terminology.

But English is auxiliary.

Do not make English mandatory unless course/task requires it.

---

# 166. LANGUAGE OF DEFINITIONS

At lower level:

simple Russian.

At higher level:

formal Russian definition.

Both link to same concept.

Do not create separate concepts solely by definition complexity.

---

# 167. DEFINITION CIRCULARITY CHECK

Flag definitions such as:

“model is something that models”.

Simple definition must add meaning.

---

# 168. TECHNICAL EXAMPLE QUALITY

Example should be:

- correct domain use;
- plausible;
- concise enough;
- relevant;
- not overloaded;
- aligned with target.

P7 validates linguistic truth.

---

# 169. PROBLEM STATEMENT QUALITY

Task statement should:

- clearly identify goal;
- provide necessary data;
- not hide language trick unrelated to target;
- use realistic technical wording.

---

# 170. DIAGRAM-TEXT ALIGNMENT

If a diagram has labels:

labels

↔ explanation

↔ concept IDs

must match.

No stale diagram terminology.

---

# 171. TABLE-TEXT ALIGNMENT

Values and textual claims must agree.

Do not generate language saying “increases” when data decreases.

---

# 172. FORMULA-TEXT ALIGNMENT

Variable names and explanation must match formula.

P8 must validate relation, not only grammar.

---

# 173. CODE-TEXT ALIGNMENT

If explanation references function/variable:

must exist in code sample.

Avoid stale code commentary.

---

# 174. CONTENT PROVENANCE

Every imported/adapted technical example should have provenance class from P7.

Generated examples:

candidate until validated.

---

# 175. DOMAIN SOURCE POLICY

P8 uses P7 source hierarchy.

For technical content prefer:

- course materials;
- recognized textbooks;
- standards;
- academic publications;
- official documentation;
- reputable technical references.

Do not copy large source passages.

---

# 176. DOMAIN TRUTH BOUNDARY

P8 must not teach technical claim solely because it creates a convenient Russian sentence.

Technical content must be correct enough for the learning task.

---

# 177. GENERATED TECHNICAL CONTENT

Pipeline:

target concept

→ generate candidate

→ technical validation

→ linguistic validation

→ pedagogical validation

→ activate.

Never:

generate

→ publish.

---

# 178. DOMAIN EXPERT ESCALATION

Use P7 `DOMAIN_REVIEW_REQUIRED` when:

- terminology contested;
- concept explanation uncertain;
- standard-specific wording;
- highly specialized control/statistics meaning.

---

# 179. CONTENT AUTHORING MODE

P12 later supplies editor.

P8 defines what technical content author must provide:

- concept;
- objective;
- domain;
- level;
- terminology refs;
- examples;
- task;
- validation status.

---

# 180. TECHNICAL CONTENT SCHEMA EXTENSIONS

Only propose schema extension if P3 model cannot represent:

- domain sense;
- abbreviation;
- concept relation;
- formula/diagram ref;
- technical validation metadata.

Do not create parallel schema.

---

# 181. CONTENT GRAPH EDGES

Useful P8 additions:

- concept `requires` concept;
- unit `teaches` concept;
- phrase `expresses` academic function;
- task `tests` concept/function;
- media `demonstrates` concept;
- technical term `denotes` concept.

Use canonical graph conventions.

---

# 182. SEARCH FACETS

Possible:

- domain;
- level;
- concept type;
- active/passive;
- academic function;
- abbreviation.

P13 decides UI.

---

# 183. TECHNICAL KNOWLEDGE NAVIGATION

Learner should be able to move conceptually:

term

→ definition

→ related lesson

→ examples

→ speaking task

→ related concept.

Do not create dead-end glossary pages.

---

# 184. TECHNICAL CONTENT REUSE

One concept can support:

R12 lesson

R14 lecture

R18 experiment

R20 research.

Reference canonical concept.

Do not copy full content.

---

# 185. CROSS-STAGE DEEPENING

Same concept can deepen:

basic definition

→ technical use

→ academic comparison

→ research discussion.

Use levels/senses/examples rather than duplicate concept identity.

---

# 186. CONTENT PACKAGING

Large technical domains should lazy-load if not active.

Do not preload every domain at startup.

P14 owns final performance packaging.

---

# 187. OFFLINE REQUIREMENT

Core current-stage technical content should follow offline policy.

External source evidence is not required at runtime.

---

# 188. PERFORMANCE BUDGET AWARENESS

Rich technical metadata can be large.

Runtime should fetch:

summary/index first

then details.

Do not require P8 to redesign PWA; record impact for P14.

---

# 189. ACCESSIBILITY

Technical figures/diagrams require meaningful text alternatives where used pedagogically.

P13 owns final accessibility implementation.

P8 must provide semantic descriptions/content.

---

# 190. LISTENING ACCESSIBILITY

Transcripts/captions should exist where feasible.

Reveal policy follows P4/P6.

---

# 191. FORMULA ACCESSIBILITY

Where possible, include human-readable formula description.

Do not rely solely on image of equation.

---

# 192. QA — TERMINOLOGY

Test:

- validated term;
- accepted variant;
- wrong domain sense;
- abbreviation;
- mixed English/Russian;
- deprecated variant.

---

# 193. QA — MORPHOLOGY

Test technical terms in:

- nominative;
- required oblique cases;
- plural;
- collocations.

Focus on forms actually used.

---

# 194. QA — ACADEMIC FUNCTIONS

For each function:

verify at least:

- recognition;
- example;
- production task;
- domain transfer.

---

# 195. QA — CROSS-DOMAIN

Ensure terms such as:

model;
state;
control;
record;
feature

resolve correctly by domain.

---

# 196. QA — TECHNICAL TRUTH

Sample every domain for:

- concept definition;
- example;
- diagram/formula relation;
- task answer.

---

# 197. QA — LEVEL

Check B1 units do not accidentally contain B2/C1-style dense academic prose without scaffolding.

---

# 198. QA — PRODUCTION

A domain does not PASS if learner only reads and selects answers.

Must have:

oral explanation

or written production

according to target.

---

# 199. QA — LISTENING

Core technical domains need representative audio/listening tasks if target includes lecture comprehension.

P6 runs runtime tests.

---

# 200. QA — TRANSFER

At least representative tasks use unseen examples/contexts.

Prevent memorized template pass.

---

# 201. QA — DUPLICATION

Detect:

same definition copied across files;
same example under many concepts;
same technical sentence with noun swap;
duplicate glossary sources.

---

# 202. QA — ORPHANS

Flag:

technical concept never taught;
term never used;
task not linked;
unit without performance;
abbreviation without full form;
domain pack unreachable.

---

# 203. P8 PILOT

Before full migration, pilot:

### Pilot A — Mathematics
One coherent concept cluster.

### Pilot B — AI/Database
Terminology ambiguity + explanation.

### Pilot C — Control
System/feedback terminology + diagram.

Pilot must test schema, graph, speaking/listening integration and P7 workflow.

---

# 204. PILOT ACCEPTANCE

Pilot passes if:

- canonical IDs stable;
- terminology validated;
- concept graph works;
- lesson references work;
- search works;
- speaking/listening refs work;
- assessment alignment works;
- no duplicated owner;
- state unaffected.

---

# 205. MIGRATION ORDER

Recommended:

1. Academic function core.
2. Mathematics/formal language.
3. Technical problem-solving language.
4. Programming/CS.
5. Database/data.
6. AI/ML.
7. Control/automation.
8. Probability/statistics.
9. Optimization/OR if needed.
10. Experiment/report bridge.
11. Research/seminar technical language.

Adjust based on curriculum dependencies.

---

# 206. BATCH RULE

Each batch:

baseline

→ validated terminology

→ concept map

→ lesson/task mapping

→ generate/enrich candidates

→ P7 validation

→ runtime integration

→ assessment integration

→ regression

→ evidence.

---

# 207. NO MASS GENERATION BEFORE PILOT

Do not generate:

2,000 technical records

before pilot proves:

schema;
quality;
terminology;
authoring workflow.

---

# 208. SEMANTIC DIFF

Each batch report should summarize:

- concepts added;
- senses added;
- terminology changed;
- phrases added;
- assessment changes;
- technical definitions changed.

Raw line diff alone insufficient.

---

# 209. STATE IMPACT

Most P8 content expansion should not rewrite learner state.

If old concept identity changes:

coordinate P3/P4 migration.

---

# 210. BACKWARD COMPATIBILITY

Existing R12/R15/R16/R17/R18 routes/IDs should remain resolvable according to foundation contract.

New units can map under them.

---

# 211. LEGACY CONTENT CLASSIFICATION

For old technical content:

`KEEP`

`ENRICH`

`REMAP`

`SPLIT_CONCEPT`

`DEPRECATE_LATER`

`BLOCK`.

Do not delete immediately.

---

# 212. P8 RISK REGISTER

Track:

- wrong technical term;
- ambiguous sense;
- overloaded unit;
- glossary-only design;
- duplicate concept;
- stale terminology;
- technical falsehood;
- unvalidated generated content;
- assessment mismatch;
- performance impact.

---

# 213. BLOCKER EXAMPLES

BLOCKER:

- systematic wrong technical terminology in assessed content;
- concept identity conflict causing wrong mastery mapping;
- P7 validation unavailable for critical terminology;
- generated content pipeline bypasses validation;
- technical content materially false.

---

# 214. CRITICAL EXAMPLES

CRITICAL:

- R15–R18 mostly glossary with no production;
- ambiguous term used across domains without sense split;
- assessment scores domain facts not taught;
- diagrams/formulas contradict explanations;
- high-frequency task instructions linguistically wrong.

---

# 215. DELIVERABLES — ARCHITECTURE

Create/maintain:

`subjects/russian/docs/p8/RUSSIAN_P8_EXECUTIVE_SUMMARY.md`

`RUSSIAN_ACADEMIC_FUNCTION_CORE.md`

`RUSSIAN_TECHNICAL_DOMAIN_MAP.md`

`RUSSIAN_TECHNICAL_CONCEPT_GRAPH.json`

`RUSSIAN_TECHNICAL_TERM_COVERAGE_MATRIX.md`

`RUSSIAN_TECHNICAL_PREREQUISITE_MAP.md`

`RUSSIAN_TECHNICAL_PERFORMANCE_TASK_MATRIX.md`.

---

# 216. DELIVERABLES — DOMAIN MAPS

As needed:

`RUSSIAN_MATHEMATICS_LANGUAGE_MAP.md`

`RUSSIAN_PROGRAMMING_SOFTWARE_LANGUAGE_MAP.md`

`RUSSIAN_ALGORITHMS_DATA_STRUCTURES_LANGUAGE_MAP.md`

`RUSSIAN_OS_LINUX_LANGUAGE_MAP.md`

`RUSSIAN_NETWORKS_LANGUAGE_MAP.md`

`RUSSIAN_DATABASE_SQL_LANGUAGE_MAP.md`

`RUSSIAN_DATA_AI_ML_LANGUAGE_MAP.md`

`RUSSIAN_PROBABILITY_STATISTICS_LANGUAGE_MAP.md`

`RUSSIAN_OPTIMIZATION_OR_LANGUAGE_MAP.md`

`RUSSIAN_CONTROL_AUTOMATION_LANGUAGE_MAP.md`

`RUSSIAN_SIGNALS_MEASUREMENT_LANGUAGE_MAP.md`

`RUSSIAN_EXPERIMENT_SIMULATION_LANGUAGE_MAP.md`.

Create only domains actually used.

Do not create empty ceremonial documents.

---

# 217. DELIVERABLES — QA

Create:

`RUSSIAN_P8_CONTENT_COVERAGE_REPORT.md`

`RUSSIAN_P8_TECHNICAL_TRUTH_AUDIT.md`

`RUSSIAN_P8_LEVEL_LOAD_AUDIT.md`

`RUSSIAN_P8_DUPLICATE_ORPHAN_REPORT.md`

`RUSSIAN_P8_RISK_REGISTER.json`

`RUSSIAN_P8_EVIDENCE_INDEX.md`

`RUSSIAN_P9_INPUT_CONTRACT.md`.

---

# 218. TEST MATRIX

Static:

- IDs;
- refs;
- schemas;
- graph;
- domain enum;
- validated terminology status.

Content:

- terminology;
- definitions;
- collocations;
- formulas;
- diagrams;
- code references;
- units.

Pedagogical:

- measurable objective;
- controlled practice;
- retrieval;
- production;
- transfer.

Runtime:

- lesson route;
- search;
- media;
- speaking;
- assessment.

State:

- no accidental mastery/state change.

Offline/performance:

- representative domain pack.

---

# 219. BROWSER ACCEPTANCE SAMPLE

Representative:

R12 math;

R15 programming;

R16 DB/AI;

R17 control;

R18 experiment;

R21 seminar bridge.

Test desktop + mobile representative view where content rendering differs.

P13 later owns full UX audit.

---

# 220. P8 FAIL CONDITIONS

P8 FAIL if:

- mostly glossary;
- technical terms unvalidated;
- terms duplicated into local lesson truth;
- academic phrases memorized without production;
- domains disconnected from curriculum;
- formulas/diagrams contradict text;
- code tokens translated/corrupted;
- same ambiguous English term gets one Russian translation across all domains;
- B1 content overloaded with advanced syntax;
- no oral technical production;
- no concept prerequisite graph;
- technical assessment lacks objective mapping;
- AI-generated technical content bypasses P7;
- startup performance regresses because all domains preload.

---

# 221. P8 PASS CONDITIONS

P8 PASS when:

1. Academic function core exists.
2. Technical domain priorities are evidence-based.
3. Canonical terminology comes through P7.
4. Concept graph exists.
5. Domain senses are disambiguated.
6. R12–R18 technical progression is coherent.
7. R19–R21 technical research bridge is coherent.
8. Concepts connect term → use → explanation → transfer.
9. Formula/symbol language is validated.
10. Code-safe mixed-language policy works.
11. Mathematics language is usable.
12. Programming/CS language is usable.
13. Database/data language is usable.
14. AI/ML language is usable.
15. Control/automation language is usable.
16. Probability/statistics coverage exists as required.
17. Experiment/report oral bridge exists.
18. Listening/speaking refs integrate P6.
19. Assessment integrates P4.
20. Personalization metadata integrates P5.
21. No duplicate canonical owners.
22. Generated content follows P7 validation.
23. Representative offline/performance remains acceptable.
24. Technical truth audit passes in changed scope.
25. P9 receives stable academic/technical inputs.

---

# 222. P9 HANDOFF CONTRACT

P8 supplies P9:

- validated technical concepts;
- academic function set;
- phrase/collocation bank;
- technical domain map;
- reading-source taxonomy;
- experiment/result vocabulary;
- graph/table language;
- seminar argumentation building blocks;
- terminology variants;
- unresolved domain-review items.

P9 owns:

- full reading pedagogy;
- note-taking;
- writing progression;
- НИР;
- ВКР;
- defense production.

P9 must not redefine technical truth silently.

---

# 223. FINAL RESPONSE FORMAT

When P8 implementation completes:

`P8 STATUS: PASS / FAIL / BLOCKED`

`Base SHA:`

`Head SHA:`

`Domains implemented:`

`Academic function core: PASS / FAIL`

`Mathematics language:`

`Programming/CS:`

`Database/Data:`

`AI/ML:`

`Control/Automation:`

`Probability/Statistics:`

`Optimization/OR:`

`Experiment/Simulation:`

`Terminology validation: PASS / PARTIAL / FAIL`

`Technical truth audit: PASS / FAIL`

`Concept graph integrity: PASS / FAIL`

`Production coverage: PASS / FAIL`

`Assessment alignment: PASS / FAIL`

`P6 speaking/listening integration: PASS / FAIL`

`State safety: PASS / FAIL`

`Offline/performance impact:`

`Unresolved domain reviews:`

`P9 readiness: READY / NOT READY`

`PR:`

`Merged SHA:`

`Production: UNCHANGED unless explicitly authorized`

End:

**P8 ACADEMIC & TECHNICAL RUSSIAN DEEPENING COMPLETE**

---

# 224. EXECUTION RULE

When authorized:

`inspect current technical content`

→ `reuse P7 evidence`

→ `baseline domains`

→ `rank domain priorities`

→ `pilot`

→ `validate terminology`

→ `build concept/function map`

→ `enrich/migrate in batches`

→ `link listening/speaking`

→ `align assessment`

→ `run transfer tasks`

→ `run regression`

→ `document evidence`

→ `open PR`.

Do not wait until the end to discover terminology conflicts.

Resolve through P7 workflow as they appear.

---

# 225. FINAL P8 PRINCIPLE

The target is not:

> “The learner knows Russian names for technical things.”

The target is:

> “The learner can use Russian to understand and communicate technical relationships.”

For every important concept ask:

- Can the learner recognize it?
- Can the learner understand it in a sentence?
- Can the learner hear it in an explanation?
- Can the learner define it?
- Can the learner describe how it relates to another concept?
- Can the learner use it in a technical problem?
- Can the learner explain a result using it?
- Can the learner answer a follow-up question?

If not:

the content is not deep enough.

**CONCEPT BEFORE GLOSSARY.**
**FUNCTION BEFORE PHRASEBOOK.**
**TECHNICAL TRUTH BEFORE SCALE.**
**PRODUCTION BEFORE CLAIMED MASTERY.**


---

# P8 HARDENING ADDENDUM
## FINAL COMPLETENESS PASS BEFORE P9

This addendum closes the remaining edge cases that can create late technical-language defects.

It does not move P8 into P9.

---

# 226. VERSIONED TECHNICAL TERMINOLOGY

Some technical terms depend on:

- software version;
- standard version;
- framework/library version;
- institutional course terminology;
- current research usage.

For such terms, allow metadata such as:

`VERSION_STABLE`

`VERSION_SENSITIVE`

`STANDARD_BOUND`

`COURSE_SPECIFIC`

`LEGACY`.

Do not treat one modern label as timeless canonical truth when the domain clearly changes.

---

# 227. COURSE-SPECIFIC TERMINOLOGY OVERRIDE

A Bauman course may use a term/abbreviation preferred locally.

P8 may record:

- canonical general Russian term;
- course-specific preferred term;
- equivalent variant;
- source/course context.

Do not overwrite general canonical term solely because one course uses a local convention.

---

# 228. STANDARD-BOUND TERMINOLOGY

If terminology is defined by:

- GOST;
- ISO;
- IEC;
- IEEE;
- RFC;
- other formal standard;

record the standard context when relevant.

Do not claim standards compliance without evidence.

---

# 229. TECHNICAL TERM DEPRECATION

Support:

`CURRENT`

`COMMON_LEGACY`

`DEPRECATED`

`HISTORICAL`.

Learner should recognize important legacy terms when encountered, but active production should prefer current usage unless course context requires otherwise.

---

# 230. NOTATION VARIANT POLICY

Technical notation may vary across:

- Russian textbooks;
- international notation;
- programming domains;
- engineering traditions.

P8 must distinguish:

same concept / different notation

from:

different concept.

Do not “correct” one accepted notation to another merely for consistency.

---

# 231. DECIMAL / THOUSANDS / UNIT CONVENTIONS

P8 consumes P7 formatting truth and must ensure technical examples consistently handle:

- decimal comma vs point by context;
- thousands separators;
- unit spacing;
- scientific notation;
- percentage;
- degree symbol;
- ranges.

Code/data literals may intentionally use a point even when Russian prose uses a comma.

Do not normalize across contexts blindly.

---

# 232. DIMENSIONAL CONSISTENCY

Where examples contain physical quantities:

check units and dimensions.

A grammatically perfect sentence with impossible units is still invalid technical content.

This is a technical-truth check, not a language-only check.

---

# 233. FORMULA VARIABLE CONSISTENCY

For every formula-linked explanation:

- variable names;
- units;
- subscripts;
- superscripts;
- sign convention;
- textual definition

must align.

Flag stale explanation after formula edits.

---

# 234. MULTI-FORMULA TASK SAFETY

If a task contains multiple formulas:

identify which formula each explanation refers to.

Do not let generic pronouns create ambiguity.

---

# 235. DIAGRAM COORDINATE CONSISTENCY

For block diagrams/graphs:

verify:

- direction of arrows;
- input/output labels;
- variable names;
- legend;
- axis labels;
- textual explanation.

P13 may improve visual accessibility later, but P8 owns semantic alignment.

---

# 236. CHART CLAIM VALIDATION

Any text claiming:

- increase;
- decrease;
- maximum;
- minimum;
- better;
- worse;
- stable;
- converged

must match the underlying chart/data.

Generated chart-description tasks require deterministic checks where possible.

---

# 237. BENCHMARK / METRIC CONTEXT

Technical metrics are meaningless without context.

For model/system evaluation examples, capture when needed:

- metric name;
- direction (higher/lower better);
- dataset/scenario;
- unit;
- baseline/comparator.

Do not teach “better accuracy” without defining what is compared.

---

# 238. ACCURACY / PRECISION / ERROR DISAMBIGUATION

Domains use overlapping terms differently.

P8 must explicitly disambiguate:

- everyday accuracy;
- measurement accuracy;
- statistical precision;
- classification precision;
- numerical error.

P7 validates Russian term choices.

P8 teaches domain sense.

---

# 239. CONTROL ERROR VS SOFTWARE ERROR

The concept equivalent to “error” differs across:

- control;
- numerical methods;
- software;
- statistics;
- measurement.

Never bind one translation globally.

Use domain/sense IDs.

---

# 240. STATE TERMINOLOGY DISAMBIGUATION

“State” may mean:

- system state;
- program state;
- state machine state;
- database state;
- physical condition.

P8 must preserve sense boundaries.

---

# 241. MODEL TERMINOLOGY DISAMBIGUATION

“Model” may mean:

- mathematical model;
- ML model;
- simulation model;
- physical model;
- data model.

Teach sense + domain.

---

# 242. FEATURE TERMINOLOGY DISAMBIGUATION

“Feature” may mean different things across:

- ML;
- product/software;
- signal processing;
- UI.

P8 must not reuse one sense silently.

---

# 243. QUERY TERMINOLOGY DISAMBIGUATION

“Query” may refer to:

- database query;
- search query;
- request/message in another system.

Use domain context.

---

# 244. TECHNICAL POLYSEMY GATE

High-risk polysemous technical terms must have:

- sense IDs;
- domain;
- example;
- accepted translation;
- related concepts.

If not, they cannot be treated as fully validated active technical vocabulary.

---

# 245. TECHNICAL GOLDEN REGRESSION SET

Create a compact P8 golden set covering:

- mathematics;
- programming;
- database;
- AI/ML;
- statistics;
- control;
- signals;
- experiment.

Include:

- correct term;
- wrong sense;
- accepted variant;
- formula-text match;
- diagram-text match;
- code-safe sentence;
- ambiguous metric.

Run before/after P8 tooling changes.

---

# 246. DOMAIN DEPENDENCY MATRIX

Create machine-readable or structured mapping:

Domain

→ prerequisite language

→ prerequisite technical concepts

→ target modules

→ active vocabulary

→ performance tasks.

This prevents P8 from teaching “advanced AI Russian” before learner can express basic data/process relationships.

---

# 247. CROSS-DOMAIN PREREQUISITE CONTROL

Some concepts legitimately bridge domains.

Examples:

probability → ML;

linear algebra → control/ML;

data structures → algorithms;

SQL → database/data;

statistics → experiment/research.

Keep these dependencies explicit but minimal.

Avoid turning the language curriculum into a full technical degree prerequisite graph.

---

# 248. SUBJECT-KNOWLEDGE CEILING

P8 must define a ceiling for each technical language task.

If learner needs to solve a difficult domain problem before they can demonstrate Russian ability, the task may be mis-scoped.

Separate:

`LANGUAGE_COMPLEXITY`

from:

`DOMAIN_COMPLEXITY`.

---

# 249. DOMAIN-COMPLEXITY METADATA

Useful levels:

`FOUNDATIONAL`

`COURSE_CORE`

`ADVANCED`

`SPECIALIZED`.

This is not CEFR.

It helps avoid a B1 Russian task requiring graduate-level technical knowledge.

---

# 250. TECHNICAL CLAIM AUTHORITY

When an example states a domain fact:

classify evidence source.

Generated technical statements should remain candidate content until validated.

Do not assume a simple sentence is safe merely because language is simple.

---

# 251. NUMERICAL EXAMPLE REPRODUCIBILITY

For examples with computed results:

store or generate enough inputs to reproduce the result.

Where feasible:

automated test recalculates expected result.

Do not allow stale result after formula/input changes.

---

# 252. RANDOM DATA POLICY

If examples generate random values:

assessment mode must be reproducible.

Use seed or deterministic fixtures where required.

Do not make answer keys impossible to reproduce.

---

# 253. CODE EXECUTION CLAIMS

If a lesson claims code output:

verify the output against code/version where feasible.

Do not write “this returns X” solely from generated prose.

---

# 254. SQL RESULT CLAIMS

For SQL examples:

schema + data fixture + query should produce the stated result where feasible.

This can be automated for representative core tasks.

---

# 255. ALGORITHM TRACE CLAIMS

For algorithm walkthrough:

step sequence must correspond to actual algorithm.

Do not create a language exercise around a technically wrong trace.

---

# 256. CONTROL / SIMULATION CLAIMS

For control/simulation examples:

do not invent response behavior or stability conclusion without a validated model/example.

Language practice can use simplified systems, but simplification must be explicit.

---

# 257. DATASET / ML CLAIMS

Do not assert:

- metric;
- training result;
- model performance;
- causality;

unless example defines context/data.

Use synthetic pedagogical data if needed and clearly mark it.

---

# 258. SYNTHETIC TECHNICAL DATA POLICY

Synthetic data is allowed for learning.

Mark as:

`PEDAGOGICAL_SYNTHETIC`.

Do not present as real experimental evidence.

---

# 259. REAL DATA POLICY

If real data is used:

record source/provenance.

Avoid sensitive personal data.

Do not add real data merely to make exercise seem authentic.

---

# 260. TECHNICAL CITATION LANGUAGE BRIDGE

P8 should provide validated expressions for:

- according to;
- based on;
- as shown in;
- the documentation states;
- the experiment demonstrates.

P9 later owns full citation/writing practice.

---

# 261. VERSION-SENSITIVE DOCUMENTATION

For software/API documentation examples:

store version/context.

Do not teach deprecated syntax as current without label.

---

# 262. LIBRARY / FRAMEWORK NAMES

Preserve official spelling.

Russian sentence may inflect surrounding nouns, not corrupt library name.

Search may add aliases.

---

# 263. FILE / PATH / COMMAND SAFETY

Technical text containing:

- file path;
- shell command;
- SQL;
- code;
- config;

must preserve exact token content when the task requires it.

Do not apply Russian typography normalization inside code spans.

---

# 264. MARKDOWN / CODE BLOCK SAFETY

If canonical content contains Markdown/code:

validate rendering boundaries.

A technical code sample must not be interpreted as raw HTML/script.

P14 later hardens security.

---

# 265. TECHNICAL LISTENING NUMBERS

P8 technical audio content should include controlled exposure to:

- decimal values;
- units;
- version numbers;
- percentages;
- port numbers;
- matrix dimensions;
- parameter values.

P6 owns audio interaction.

---

# 266. LECTURE NOISE / REDUNDANCY

Advanced technical listening should include realistic discourse features:

- restatement;
- hesitation;
- examples;
- lecturer emphasis;

but not uncontrolled noise that obscures learning target.

---

# 267. ACADEMIC FUNCTION COVERAGE MATRIX

For each core function, map:

- domains used;
- oral example;
- written example;
- listening occurrence;
- speaking task;
- reading task;
- assessment.

Flag functions taught only once.

---

# 268. TECHNICAL CONCEPT COVERAGE MATRIX

For each CORE concept, map:

- first exposure;
- review;
- listening;
- speaking;
- reading;
- writing bridge;
- assessment;
- later research use.

This proves spiral depth.

---

# 269. DOMAIN SATURATION CHECK

Do not continue adding terms to a domain when:

- core functions are still weak;
- production tasks missing;
- existing concepts not recycled.

Depth before breadth.

---

# 270. TECHNICAL CONTENT RETIREMENT

When a term/example becomes obsolete:

do not hard-delete immediately.

Mark legacy/deprecated;

update active path;

preserve migration/search aliases if needed.

---

# 271. P8 CONTENT REVISION IMPACT

Classify change:

`METADATA_ONLY`

`LINGUISTIC_ONLY`

`TECHNICAL_FACT`

`CONCEPT_IDENTITY`

`ASSESSMENT_AFFECTING`.

Coordinate P4/P7 migration for higher-impact classes.

---

# 272. P8 REVALIDATION TRIGGERS

Revalidate relevant domain slice when:

- technical standard changes;
- course materials change materially;
- API/software version updates;
- domain terminology conflict appears;
- technical example is corrected;
- P9 relies on a new research sense.

Do not rerun all domains for an isolated spelling fix.

---

# 273. P8 PROMPT COMPLETENESS GATE

P8 prompt is structurally complete only if it covers:

1. academic functions;
2. technical concept model;
3. domain priorities;
4. mathematics;
5. programming;
6. algorithms/data structures;
7. OS/Linux;
8. networks;
9. database/SQL;
10. data;
11. AI/ML;
12. probability/statistics;
13. optimization/OR where required;
14. control/automation;
15. signals/measurement;
16. experiment/simulation;
17. formula/symbol language;
18. code-safe language;
19. notation/units;
20. technical polysemy;
21. version-sensitive terminology;
22. technical truth;
23. production;
24. listening/lecture;
25. assessment alignment;
26. concept graph;
27. cross-domain prerequisites;
28. P9 handoff.

If all are defined:

`P8 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P8 work has already PASSed.

---

# 274. P8 → P9 HARD HANDOFF

P9 receives:

- validated academic functions;
- technical terminology;
- concept graph;
- technical reading vocabulary;
- experiment/result language;
- graph/table language;
- technical register;
- course-specific variants;
- unresolved domain-review items.

P9 must not silently rewrite technical truth.

If P9 discovers a technical terminology/fact conflict:

return to P7/P8 validation workflow.

**P8 PROMPT HARDENING COMPLETE**

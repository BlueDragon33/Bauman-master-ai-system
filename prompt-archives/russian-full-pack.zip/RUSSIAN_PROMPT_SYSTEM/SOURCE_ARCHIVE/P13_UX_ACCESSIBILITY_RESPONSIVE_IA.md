# P13 — UX · ACCESSIBILITY · RESPONSIVE · INFORMATION ARCHITECTURE CONSTITUTION
## LEARNER EXPERIENCE · AUTHOR EXPERIENCE · NAVIGATION · STATES · DEVICE ADAPTATION · CONSISTENCY · ACCESSIBILITY

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Execution mode:

**AUTONOMOUS · USER-JOURNEY-FIRST · ACCESSIBLE-BY-DESIGN · RESPONSIVE · STATE-AWARE · CONSISTENT · LOW-COGNITIVE-LOAD · FOUNDATION-PRESERVING · TOKEN-EFFICIENT**

---

# P13 CHANGELOG

- 2026-09-30 — Full deep P13 constitution created.

---

# 0. MISSION

P13 is the final product/learning-floor layer.

It converts the capabilities built in P1–P12 into one coherent experience for learner, author, reviewer and administrator.

P13 is not a visual repaint.

It is responsible for ensuring that:

- the next action is obvious;
- system state is truthful;
- content remains readable;
- errors are recoverable;
- mobile/tablet/desktop preserve capability;
- keyboard/touch/accessibility work;
- learning semantics are not mutated by presentation;
- authoring workflows remain safe and understandable.

> **CLARITY BEFORE DECORATION · STATE TRUTH BEFORE ANIMATION · ACCESSIBILITY BEFORE POLISH**

---

# 1. FOUNDATION DEPENDENCIES

P13 consumes and must preserve:

- P2 curriculum hierarchy;
- P3 canonical entity relations;
- P4 completion/mastery/assessment semantics;
- P5 Today/SRS/recommendation semantics;
- P6 listening/speaking/audio states;
- P7 stress/register/linguistic annotations;
- P8 technical content/formulas/diagrams;
- P9 reading/writing/НИР/ВКР workflows;
- P10 AI Mentor states, uncertainty and source boundaries;
- P11 scenario state/objective/debrief semantics;
- P12 authoring/review/approval/activation semantics.

P13 may recompose presentation.

P13 may not silently change those meanings.

---

# 2. P13 OWNERSHIP

P13 owns:

- learner information architecture;
- author/admin information architecture;
- navigation;
- search presentation;
- responsive layout;
- typography;
- spacing/density;
- component consistency;
- UI state presentation;
- accessibility;
- keyboard/touch behavior;
- focus management;
- loading/error/offline UX;
- lesson UX;
- listening/speaking UX;
- assessment UX;
- AI Mentor UX;
- scenario UX;
- reading/writing/research UX;
- authoring/review UX;
- settings UX;
- visual regression baselines;
- critical user journey acceptance.

P13 does NOT own:

- canonical content truth;
- mastery calculation;
- SRS;
- AI permissions;
- scenario engine state;
- content governance decisions;
- production deployment.

---

# 3. PRESENTATION TRUTH PRINCIPLE

The UI must never invent a domain state.

Examples:

- `Saved` only after actual persistence;
- `Published/Active` only when canonical activation succeeded;
- `Completed` only according to P4 completion semantics;
- mastery display only from P4 evidence;
- `Offline` only when runtime is actually offline/degraded;
- `AI unavailable` when AI is unavailable, not generic silent fallback;
- `Recording` only while P6 recorder is active.

No decorative state simulation.

---

# 4. USER GROUPS

Primary UX contexts:

`LEARNER`

`AUTHOR/EDITOR`

`REVIEWER`

`ADMIN/QA`

Do not place all roles inside one overloaded dashboard.

Role-specific density and controls are allowed while design tokens remain consistent.

---

# 5. LEARNER CORE QUESTIONS

Within seconds, learner should be able to answer:

1. What should I do now?
2. Why is it recommended?
3. Where am I in the course?
4. What needs review?
5. What did I just complete?
6. What can I do offline?
7. How do I search a topic?
8. How do I practice speaking?
9. How do I review errors?
10. How do I continue after interruption?

---

# 6. AUTHOR/ADMIN CORE QUESTIONS

Author/admin should quickly answer:

1. What is blocked?
2. What needs review?
3. What changed?
4. What is the impact?
5. What can be previewed?
6. What is active?
7. What validation failed?
8. What can be rolled back?
9. What is stale/duplicate/orphaned?
10. Which action am I authorized to perform?

---

# 7. LEARNER TOP-LEVEL IA

Keep top-level destinations small and stable.

Conceptual options:

- Home / Today;
- Course;
- Review;
- Practice;
- Progress;
- Search;
- Settings.

Inside Russian subject:

- Overview;
- Roadmap;
- Lessons;
- Speaking/Practice;
- Review;
- Progress.

Do not duplicate the same functionality across many tabs.

---

# 8. HOME / TODAY

Consumes P5 canonical plan.

May show:

- MUST DO;
- SHOULD DO;
- OPTIONAL;
- session estimate;
- concise recommendation reason.

P13 must not rank tasks independently.

---

# 9. TODAY PRIORITY VISUAL LANGUAGE

Use calm hierarchy.

Reserve danger/red for real error/critical blocker.

Do not turn every overdue review into an alarm.

---

# 10. WHY THIS TASK

Expose concise reason where useful:

- current lesson;
- overdue review;
- prerequisite repair;
- speaking deficit;
- stage preparation;
- learner-selected focus.

Do not expose opaque internal scoring formula.

---

# 11. COURSE OVERVIEW

Show:

- current stage;
- current macro module;
- next major milestone;
- recent activity;
- high-value next action.

Do not show every micro-lesson at once.

---

# 12. ROADMAP

Represent canonical stage progression.

Roadmap answers:

`WHERE AM I?`

`WHAT COMES NEXT?`

It does not claim mastery merely because learner has navigated to a stage.

---

# 13. MODULE CARDS

May display:

- title;
- purpose;
- skills;
- status;
- next action;
- rough workload.

Keep metadata secondary.

---

# 14. UNIT/MICRO-LESSON DISCLOSURE

Use progressive disclosure.

Do not render hundreds of lessons as one massive page.

---

# 15. MICRO-LESSON PAGE ORDER

Prefer:

1. context/objective;
2. input/model;
3. interaction;
4. feedback;
5. retry/remediation;
6. next action.

---

# 16. LEARNING OBJECTIVE COPY

Learner-facing wording should be functional.

Internal objective/competency IDs remain hidden unless debug/admin.

---

# 17. HIERARCHY

Use more than font size:

- placement;
- spacing;
- headings;
- grouping;
- labels.

---

# 18. BREADCRUMBS

Useful on desktop for deep navigation.

Compact on mobile.

Do not duplicate side nav + breadcrumb + giant route title unnecessarily.

---

# 19. BACK BEHAVIOR

Back navigation must not silently lose:

- writing draft;
- recording;
- official assessment;
- scenario state.

---

# 20. DEEP LINKS

Meaningful lesson/task/scenario routes should be stable where architecture permits.

Opening a deep link must resolve current canonical content/state safely.

---

# 21. SEARCH GOALS

Search should find:

- Russian lemma;
- stressless spelling;
- Vietnamese support term;
- English technical alias;
- abbreviation;
- lesson title;
- technical concept;
- grammar/function.

---

# 22. SEARCH RESULT TYPES

Label results:

`LESSON`

`VOCAB`

`GRAMMAR`

`TECHNICAL CONCEPT`

`SCENARIO`

`WRITING/RESEARCH`.

Avoid indistinguishable mixed results.

---

# 23. SEARCH FILTERS

Optional filters:

- type;
- stage;
- skill;
- technical domain.

Default should remain simple.

---

# 24. SEARCH EMPTY STATE

Offer:

- spelling alternative;
- remove filter;
- related concept;
- browse path.

Never show blank white area.

---

# 25. SEARCH NORMALIZATION UX

Search can normalize `ё/е`, stress marks and aliases.

Canonical display remains precise.

---

# 26. NAVIGATION LABEL CONSISTENCY

One destination uses one stable human label.

Do not rename the same destination differently across dashboard/settings/mobile navigation.

---

# 27. ICON CONSISTENCY

Use one coherent icon family.

Critical actions include labels.

Icons never carry meaning alone.

---

# 28. RESPONSIVE PHILOSOPHY

Responsive is composition change, not shrinking desktop.

Preserve capability while adapting hierarchy.

---

# 29. DESKTOP COMPOSITION

Desktop can use:

- side navigation;
- main content;
- secondary contextual panel.

Main learning task remains visually dominant.

---

# 30. TABLET COMPOSITION

Tablet may collapse side/context panels.

Touch targets become primary.

Portrait and landscape must both work.

---

# 31. MOBILE COMPOSITION

Prefer:

- one primary column;
- compact navigation;
- bottom sheet/drawer for secondary data;
- sticky primary action only when useful.

No normal horizontal page scroll.

---

# 32. NO EXACT-ASPECT DEPENDENCY

The system may be optimized visually for common desktop/tablet/mobile proportions but must not depend on exact aspect ratio.

Content-driven breakpoints are preferred.

---

# 33. BREAKPOINT PRINCIPLE

Change composition when content no longer fits comfortably.

Do not select breakpoints solely by named device models.

---

# 34. CONTENT WIDTH

Long prose uses readable maximum width.

Tables, code and technical diagrams may intentionally use wider workspace.

---

# 35. ULTRAWIDE

Use spare width for secondary context/notes.

Do not make paragraphs span the full monitor.

---

# 36. SMALL SCREEN

Collapse secondary metadata first.

Never hide task instruction or required action.

---

# 37. ORIENTATION CHANGE

Rotation preserves:

- draft;
- scenario;
- recorder state where platform safely supports;
- current task.

---

# 38. TEXT ZOOM

Large text must not clip essential controls.

Layout should reflow.

---

# 39. TYPOGRAPHY REQUIREMENTS

Font system must support:

- Cyrillic;
- Vietnamese diacritics;
- stress marks;
- math symbols;
- code.

---

# 40. TYPOGRAPHIC SCALE

Use a small tokenized scale.

Avoid per-component arbitrary font sizing.

---

# 41. USER FONT SIZE

If setting exists:

`SMALLER`

`DEFAULT`

`LARGER`.

All key layouts must survive each.

---

# 42. LINE HEIGHT

Reading content gets comfortable line height.

Tables/code may be denser.

---

# 43. FONT WEIGHT

Avoid overly light learning text.

---

# 44. STRESS MARK RENDERING

Combining stress marks must remain visible, selectable and copyable.

Do not create stress through CSS decoration alone.

---

# 45. CYRILLIC ITALIC CAUTION

Italic Cyrillic can change letter shapes strongly.

Use intentionally, especially for beginners.

---

# 46. HANDWRITING FONT

Use only within handwriting practice/model.

Never globally.

---

# 47. CODE FONT

Monospace for code only.

Russian explanatory prose remains standard reading font.

---

# 48. FORMULA RENDERING

No clipped equations.

Allow wrapping/scroll where appropriate and accessible textual explanation when needed.

---

# 49. DESIGN TOKENS

Tokenize:

- colors;
- spacing;
- font sizes;
- radii;
- shadows;
- breakpoints;
- z-index.

No random values scattered across components.

---

# 50. SEMANTIC COLOR

Use tokens:

background;
surface;
text;
muted;
accent;
success;
warning;
danger;
info.

---

# 51. COLOR NOT SOLE SIGNAL

Every critical status also uses label/icon/structure.

---

# 52. CONTRAST

Ensure readable:

- text;
- focus;
- borders;
- disabled state;
- error/success.

---

# 53. DARK MODE

If supported, test all:

- formula;
- code;
- audio;
- recorder;
- editor;
- charts;
- tables.

---

# 54. HIGH-CONTRAST MODE

If supported, adapt tokens rather than creating a parallel app.

---

# 55. BACKGROUND SETTING

Constrain appearance choices so readability remains safe.

---

# 56. TYPEFACE SETTING

If exposed, use curated supported fonts.

Do not allow arbitrary learner font uploads.

---

# 57. UI LANGUAGE SETTING

Interface/support language can switch independently from canonical Russian target content.

---

# 58. BILINGUAL COMPOSITION

Desktop may use paired columns.

Mobile should stack/collapse.

Do not compress bilingual text into tiny side-by-side columns.

---

# 59. TRANSLATION REVEAL

Progressive reveal follows pedagogy.

Advanced content should not always show full Vietnamese translation by default.

---

# 60. READING MODE

Provide distraction-reduced reading with:

- readable width;
- glossary access;
- notes/annotation where supported.

---

# 61. FOCUS MODE

Optional.

Hide secondary chrome while retaining escape/back.

---

# 62. DASHBOARD DENSITY

Primary dashboard should prioritize:

- next action;
- urgent review;
- current stage;
- meaningful alerts.

Secondary analytics go lower.

---

# 63. CARD DISCIPLINE

Use cards for coherent groups.

Do not wrap every sentence in a card.

---

# 64. PAGE LENGTH

Avoid endlessly long home pages.

Use progressive disclosure and bounded scroll areas only when discoverability remains clear.

---

# 65. PRIMARY ACTION

One action should normally dominate a task context.

---

# 66. SECONDARY ACTION

Lower visual priority.

---

# 67. DESTRUCTIVE ACTION

Clear visual distinction and consequence.

---

# 68. DISABLED ACTION

If disabled for a non-obvious prerequisite, explain why.

---

# 69. CLICK/TAP FEEDBACK

Immediate interaction feedback.

Prevent accidental double submit.

---

# 70. TOUCH TARGETS

Core controls must be comfortably tappable.

No tiny icon-only buttons.

---

# 71. HOVER

Supplemental only.

Never required to discover essential action/information.

---

# 72. KEYBOARD

All core flows work by keyboard.

---

# 73. FOCUS VISIBLE

Never remove visible focus without accessible replacement.

---

# 74. FOCUS MANAGEMENT

After route/modal/error/dialogue transition, focus moves to logical target.

---

# 75. MODAL

Use for focused temporary tasks only.

Avoid nested modal workflows.

---

# 76. DRAWER / BOTTOM SHEET

Useful for:

- glossary;
- filter;
- notes;
- settings;
- mobile secondary panels.

Must support focus/keyboard semantics.

---

# 77. TOOLTIP

Supplemental only.

Never the only location for critical instructions.

---

# 78. TOAST

For transient confirmation.

Not for detailed critical failures.

---

# 79. ALERT

Persistent actionable state.

---

# 80. ERROR MESSAGE CONTRACT

An error should communicate:

- what failed;
- what remains safe;
- next action;
- retry/fallback.

---

# 81. ERROR LIFECYCLE

Resolved errors clear.

Never leave stale red banner indefinitely.

---

# 82. INLINE ERROR

Form/task validation near field.

---

# 83. GLOBAL ERROR

Reserved for app/system-level issues.

---

# 84. LOADING

Show only for real pending state.

No indefinite spinner.

---

# 85. SKELETON

Use for predictable layout only.

Never imply fake content.

---

# 86. PROGRESSIVE LOAD

Load essential current content before large supporting datasets/media.

---

# 87. EMPTY STATE

Explain why empty and what next.

Example:

“No reviews due.”

---

# 88. SUCCESS STATE

Confirm meaningful completion without excessive celebration.

---

# 89. OFFLINE STATE

Clearly show offline/degraded mode and available features.

---

# 90. SYNC STATE

If sync exists, distinguish:

- synced;
- pending;
- failed;
- conflict.

---

# 91. UNSAVED / SAVING / SAVED

Truthful status only.

---

# 92. CONFLICT

Preserve both revisions and provide resolution.

---

# 93. PROGRESS DISPLAY

Distinguish:

`EXPOSURE`

`COMPLETION`

`MASTERY`

`REVIEW DUE`.

Do not collapse them silently into one percent.

---

# 94. MASTERY VISUALIZATION

Prefer evidence-backed bands/status over fake precision.

---

# 95. OVERDUE REVIEW

Use calm language.

No shame/guilt patterns.

---

# 96. STREAK

Engagement only.

Do not present as competence.

---

# 97. SKILL VIEW

Show skill state only when backed by actual evidence.

---

# 98. SKILL IMBALANCE COPY

Prefer:

“Speaking has had less practice recently.”

Avoid personal judgment.

---

# 99. ERROR HISTORY

Surface recurring actionable patterns, not every historical mistake.

---

# 100. REMEDIATION VIEW

Explain:

- target problem;
- steps;
- exit/retry.

---

# 101. SRS REVIEW SCREEN

Manageable queue, clear item, concise controls.

---

# 102. FLASHCARD

Front/back semantics clear.

Keyboard + touch friendly.

---

# 103. SELF-RATING

If used, simple labels and limited frequency.

---

# 104. BACKLOG UX

Show manageable daily workload rather than intimidating total debt as primary callout.

---

# 105. LISTENING PLAYER

Prioritize:

play/pause;
seek/repeat;
speed when allowed;
transcript policy;
response action.

---

# 106. AUDIO FAILURE

Offer cached/text/alternate fallback.

---

# 107. TRANSCRIPT UI

Readable/selectable.

Respect reveal policy.

---

# 108. SEGMENT LOOP

Support phrase/segment repetition where P6 allows.

---

# 109. RECORDING UI

Always make active recording unmistakable.

Show:

- timer;
- stop;
- cancel;
- permission/error state.

---

# 110. ROUTE EXIT WHILE RECORDING

Warn/stop according to P6.

No hidden continuing microphone.

---

# 111. MIC PERMISSION

Explain just-in-time why needed.

If denied, show fallback and retry route.

---

# 112. SPEECH RECOGNITION

Display transcript as recognition result, not pronunciation truth.

---

# 113. PRONUNCIATION FEEDBACK

Actionable language:

stress;
sound;
rhythm;
phrase target.

No fake 98% scores.

---

# 114. SPEAKING RETRY LOOP

Record → feedback → retry should be fast and low-friction.

---

# 115. DIALOGUE UI

Differentiate:

- counterpart;
- learner;
- coach feedback;
- system event.

---

# 116. ROLE LABEL

Compact role/context indicator.

---

# 117. SCENARIO OBJECTIVE

Visible learner objective.

Never expose hidden world facts.

---

# 118. SCENARIO PROGRESS

Show learner-meaningful subgoal progress, not internal state IDs.

---

# 119. SCENARIO SYSTEM EVENT

Visually separate from role speech.

---

# 120. CHOICE FALLBACK

Do not style semantic fallback choice as the one “correct sentence” unless it is actually a choice task.

---

# 121. SCENARIO HINT

Optional and clearly marked.

---

# 122. DEBRIEF

Exit role before feedback.

Show:

- outcome;
- important repair;
- errors;
- better phrases;
- retry.

---

# 123. AI MENTOR ENTRY

Mentor should be contextually available without covering primary lesson content.

---

# 124. AI MODE LABEL

If mode materially changes behavior, show concise label:

- Explain;
- Practice;
- Roleplay;
- Writing feedback;
- Research rehearsal.

---

# 125. AI PENDING STATE

Show response pending without inventing hidden reasoning steps.

---

# 126. AI SOURCES

When grounding matters, expose source/reference in a usable form.

---

# 127. AI UNCERTAINTY

Allow visible states:

- unverified;
- source conflict;
- needs review.

Do not hide uncertainty.

---

# 128. AI ADVISORY LABEL

In high-impact writing/assessment contexts, make advisory status understandable.

---

# 129. AI CANCEL/RETRY

Retry/cancel must not duplicate side effects.

---

# 130. AI FAILURE

Offer:

- retry;
- canonical explanation;
- continue without AI.

---

# 131. AI HISTORY

Allow collapse/new session.

Clearing chat does not reset learning progress.

---

# 132. AI SUGGESTION ACCEPT/REJECT

For writing, compare original vs suggested and let learner decide.

No silent overwrite.

---

# 133. WRITING WORKSPACE

Core elements:

- editor;
- autosave status;
- task/source access;
- feedback;
- revision/submission action.

---

# 134. WRITING MOBILE

Single-pane priority.

Source/feedback as sheets/tabs.

---

# 135. WRITING DESKTOP

May use outline + editor + secondary panel.

Main document remains dominant.

---

# 136. SOURCE PANEL

Show source identity and relevant excerpt/claim.

Do not dump huge documents by default.

---

# 137. FEEDBACK PANEL

Group by:

- task/content;
- structure;
- language;
- technical accuracy;
- integrity.

---

# 138. FEEDBACK SEVERITY

Meaning-changing issue > style preference.

---

# 139. VERSION/REVISION VIEW

Meaningful revisions discoverable for long-form work.

---

# 140. SAVE VS SUBMIT

Visually and semantically distinct.

---

# 141. SUBMISSION CONFIRMATION

Show submitted revision/state only after actual persistence.

---

# 142. NIR/VKR WORKSPACE

Organize long documents by sections/stages.

Avoid one giant unstructured page.

---

# 143. OUTLINE NAVIGATION

Desktop: side outline.

Mobile: sheet/dropdown.

---

# 144. RESEARCH TRACEABILITY

If implemented, allow learner to inspect objective → method → result → conclusion relations without overwhelming the writing surface.

---

# 145. FIGURE/TABLE WORKSPACE

Preview asset/data and description.

Accessible alternative required.

---

# 146. PRESENTATION PRACTICE

Show slide/figure, timer if needed, notes/recording according to mode.

Do not make advanced learner read a full script by default.

---

# 147. DEFENSE PRACTICE

Question → response → follow-up → debrief.

---

# 148. TIMER

Use only when task requires.

Readable but not visually dominant unless timing is the target.

---

# 149. ASSESSMENT ENTRY

Before official attempt show:

- purpose;
- support policy;
- timing if any;
- attempt semantics.

---

# 150. OFFICIAL MODE INDICATOR

Learner should know they are in official/graded mode where applicable.

---

# 151. ANSWER KEY LEAK PREVENTION

Hidden answer should not be accidentally rendered/preloaded into learner-visible DOM where avoidable.

---

# 152. HINT EFFECT

If hint affects evidence, communicate this when appropriate.

---

# 153. DOUBLE SUBMIT

Prevent and handle idempotently.

---

# 154. HIGH-STAKES SUBMIT CONFIRMATION

Use only for long/high-impact submissions.

Not every small answer.

---

# 155. FIRST/LATEST/BEST ATTEMPT

Only display these when backed by P4 semantics.

Retry never overwrites first attempt.

---

# 156. RESULT VIEW

Answer:

- what happened;
- evidence;
- what needs work;
- next step.

---

# 157. SCORE UX

Never invent percent or rank.

Use official rubric/bands only.

---

# 158. PARTIAL CREDIT

Explain criterion-level result where available.

---

# 159. ACCEPTED VARIANT

UI/evaluator must not mark valid P7 variant wrong because display assumes exact string.

---

# 160. AUTHOR/ADMIN IA

Possible top-level:

- Dashboard;
- Content;
- Reviews;
- Issues;
- Imports;
- Media;
- Scenarios;
- Assessments;
- Snapshots/Releases;
- Settings.

---

# 161. AUTHORING DASHBOARD

Prioritize:

- blockers;
- requested reviews;
- activation failures;
- stale critical content;
- high-risk issues.

Avoid vanity charts.

---

# 162. CONTENT LIST

Useful columns/filters:

- type;
- title/ID;
- status;
- stage/domain;
- validation;
- updated;
- owner.

---

# 163. LARGE ADMIN LIST

Virtualize/paginate.

Do not render thousands of rich rows.

---

# 164. COLUMN PRIORITY

Allow optional columns to hide/collapse.

---

# 165. CONTENT DETAIL IA

Sections/tabs:

- content;
- relations;
- validation;
- provenance;
- impact;
- history.

---

# 166. VIEW VS EDIT

Clearly separate.

No accidental edit-on-click.

---

# 167. REVIEW MODE

Optimized for:

- diff;
- findings;
- impact;
- source;
- comments;
- approve/request changes.

---

# 168. AUTHORIZATION UX

Only show protected actions when appropriate, but server/action layer remains authoritative.

---

# 169. VALIDATION SUMMARY

Group:

`BLOCKING`

`WARNING`

`INFO`.

---

# 170. FINDING NAVIGATION

Click finding → relevant field/entity/state node.

---

# 171. SEMANTIC DIFF UI

Highlight important categories:

- meaning;
- stress;
- answer key;
- prerequisite;
- scenario topology;
- source/provenance.

---

# 172. IMPACT VIEW

Summary first, detailed dependency list/graph second.

---

# 173. DEPENDENCY GRAPH ACCESSIBILITY

Graph visualization requires list/table alternative.

---

# 174. SCENARIO GRAPH EDITOR

Canvas can exist, but canonical model remains structured.

Provide non-canvas editing/read alternative for critical operations.

---

# 175. IMPORT UX

Wizard flow:

upload → map → validate → review → stage.

No immediate activation.

---

# 176. IMPORT ERROR UX

Row/entity-level errors with downloadable/viewable report.

---

# 177. BULK ACTION

Display exact affected count and dry-run impact.

---

# 178. REVIEW QUEUE

Filter by risk/type/domain/assignee/status.

---

# 179. REVIEW CONFLICT

Show conflicting reviewer evidence explicitly.

---

# 180. WAIVER UX

Intentional high-friction action with reason.

---

# 181. ACTIVATION UX

Before activation show:

- changeset;
- validation;
- impact;
- rollback point.

---

# 182. ROLLBACK UX

Show consequences/dependent changes.

No ambiguous one-click destructive action.

---

# 183. AUDIT LOG

Read-only, searchable/filterable.

---

# 184. ISSUE INBOX

Group duplicates.

Show entity/severity/status.

---

# 185. EMERGENCY BLOCK

Fast but explicit.

Reason required.

---

# 186. SETTINGS IA

Separate categories:

- language;
- appearance;
- accessibility;
- audio;
- learning preferences;
- offline/storage;
- AI preferences where allowed.

---

# 187. APPEARANCE SETTINGS

May include:

- font size;
- theme/background;
- typeface from curated set;
- contrast.

Preview immediately.

---

# 188. LANGUAGE SETTINGS

Interface/support language changes do not alter canonical course content.

---

# 189. AUDIO SETTINGS

Expose only supported options.

Potential:

- default playback speed;
- autoplay preference;
- input device where truly supported.

---

# 190. ACCESSIBILITY SETTINGS

Potential:

- reduced motion;
- high contrast;
- larger text;
- transcript/caption preferences.

---

# 191. LEARNING PREFERENCES

Session length/focus/support language can be presented here while P5 owns actual planner semantics.

---

# 192. OFFLINE SETTINGS

Show:

- downloaded packs;
- size;
- update;
- remove.

No low-level cache jargon by default.

---

# 193. CLEAR CACHE VS RESET PROGRESS

These must be visibly and technically separate.

A cache-clear action must never imply/delete mastery.

---

# 194. SEMANTIC HTML

Core controls use correct native semantics:

button;
input;
label;
heading;
list;
table;
dialog.

---

# 195. HEADING ORDER

Logical hierarchy independent of styling.

---

# 196. PAGE LANDMARKS

Use main/nav/header/aside/footer meaningfully.

---

# 197. FORM ACCESSIBILITY

Every input has programmatic label.

Errors associated with fields.

---

# 198. REQUIRED FIELD

Convey with text/semantics, not color alone.

---

# 199. ERROR ANNOUNCEMENT

Screen reader detects relevant submit errors.

---

# 200. LIVE REGION

Use carefully for:

- recording state;
- AI completion;
- validation result.

Avoid chatter.

---

# 201. DIALOG FOCUS

Trap focus appropriately and return it on close.

---

# 202. TABS/ACCORDIONS

Implement expected keyboard/expanded semantics.

---

# 203. TABLE ACCESSIBILITY

Headers and relationships programmatically clear.

---

# 204. CHART ACCESSIBILITY

Provide textual/data alternative.

---

# 205. GRAPH ACCESSIBILITY

Dependency/scenario graph has structured list alternative.

---

# 206. AUDIO ACCESSIBILITY

Transcript/caption/alternate path according to learning/assessment policy.

---

# 207. VIDEO ACCESSIBILITY

Captions/transcript where pedagogically required.

---

# 208. RECORDING ACCESSIBILITY

Recording state visually and programmatically announced.

---

# 209. DRAG/DROP

Keyboard alternative for reorder/authoring operations.

---

# 210. REDUCED MOTION

Respect setting/system preference.

---

# 211. FLASHING

Avoid hazardous flashing.

---

# 212. TIME LIMIT ACCESSIBILITY

Communicate clearly and integrate approved accommodation semantics.

---

# 213. FOCUS ORDER

DOM and visual order should align.

---

# 214. SKIP LINK

Useful in desktop application shell.

---

# 215. LANGUAGE ATTRIBUTES

Mark Russian/Vietnamese/English spans/pages where practical for assistive technology.

---

# 216. STRESS ACCESSIBILITY

Test how screen readers handle combining accent.

Provide accessible pronunciation label where necessary.

---

# 217. MATH ACCESSIBILITY

Use accessible math representation where possible and textual explanation for instructional equations.

---

# 218. CODE ACCESSIBILITY

Keyboard-scrollable and semantically code.

---

# 219. LOCALIZATION

Centralize UI strings.

No hard-coded Vietnamese/Russian labels scattered through components.

---

# 220. STRING EXPANSION

Layouts tolerate longer translations.

Essential labels are not irreversibly truncated.

---

# 221. DATE/TIME/NUMBER

Locale-aware UI formatting where appropriate while preserving technical/source notation when that notation is part of content.

---

# 222. COPY/SELECTION

Copied learning content should contain semantic text, not decorative artifacts.

---

# 223. MOBILE KEYBOARD

Use suitable input mode for numeric/email/text fields while allowing Russian input normally.

---

# 224. SAFE AREA

Respect mobile safe areas.

---

# 225. VIRTUAL KEYBOARD

Inputs/chat/writing controls remain usable when keyboard opens.

---

# 226. STICKY ELEMENTS

Sticky headers/footers must not cover content/actions.

---

# 227. BOTTOM NAV

If used, keep primary destinations limited and stable.

---

# 228. SIDE NAV

Desktop side nav may collapse while selected state stays obvious.

---

# 229. SCROLL RESTORATION

Back navigation restores sensible position when appropriate.

---

# 230. NEXT/PREVIOUS LESSON

Clear navigation but cannot bypass required official submission silently.

---

# 231. KEYBOARD SHORTCUTS

Optional.

Do not conflict with typing fields.

---

# 232. CONTEXTUAL HELP

Provide help close to difficult feature.

Avoid giant manual as primary UX.

---

# 233. ONBOARDING

Minimal first-run:

- course structure;
- Today;
- mic permission when first needed;
- offline capability where useful.

---

# 234. JUST-IN-TIME PERMISSIONS

Ask mic/storage permission at feature need, not all at startup.

---

# 235. INSTALL PROMPT

If PWA install exists, offer unobtrusively and stop nagging after dismissal according to policy.

---

# 236. OFFLINE DOWNLOAD

Show pack size/content before download.

---

# 237. DOWNLOAD PROGRESS

Show real progress if measurable; allow cancel/retry when safe.

---

# 238. UPDATE AVAILABLE

Do not force disruptive update during official assessment/long draft.

---

# 239. STALE APP

If incompatible app/content version exists, provide clear recovery path.

---

# 240. NETWORK FLUCTUATION

Avoid noisy alerts for brief hiccups.

Surface only actionable degraded state.

---

# 241. PERCEIVED PERFORMANCE

Respond immediately to input and progressively load nonessential content.

Do not hide actual failure behind animation.

---

# 242. LONG JOB PROGRESS

For import/build/AI, show stage/status.

Do not fabricate percentage without measurable denominator.

---

# 243. RETRY SAFETY

Retry never duplicates side effects.

---

# 244. ISSUE REPORT

Allow learner to report content problem from current context with entity ID pre-attached.

---

# 245. ISSUE CATEGORIES

Examples:

- wrong content;
- broken audio;
- unclear instruction;
- technical issue;
- answer problem.

---

# 246. PRIVACY UX

Make data usage understandable for:

- microphone;
- AI;
- uploads;
- external source processing.

---

# 247. CONFIDENTIAL DOCUMENT WARNING

Before external AI processing of potentially confidential research content, follow product authorization/disclosure requirements.

---

# 248. MULTI-TAB DRAFT

If a newer revision exists, stale tab must reconcile rather than overwrite silently.

---

# 249. NOTIFICATIONS

Use sparingly for meaningful events:

- review due;
- content pack update;
- feedback ready.

---

# 250. BADGES

Counts must be current and meaningful.

Red badge reserved for real urgency/error.

---

# 251. STATUS CHIPS

Use one consistent vocabulary/color mapping across app.

---

# 252. MICROCOPY

Learner:

plain/direct.

Admin:

precise/actionable.

---

# 253. DESTRUCTIVE COPY

Name exactly what will be removed and what remains safe.

---

# 254. AI COPY

Do not overstate AI capabilities or imply actions not actually performed.

---

# 255. COMPONENT LIBRARY

Core shared components should include as needed:

- Button;
- Input;
- Select;
- Tabs;
- Accordion;
- Card;
- Dialog;
- Toast;
- Table;
- Badge;
- Progress;
- AudioPlayer;
- Recorder;
- Feedback;
- SourceCard;
- ScenarioTurn;
- EditorField.

---

# 256. COMPONENT OWNERSHIP

Do not create local duplicate Button/Input systems for each feature.

---

# 257. VARIANT CONTROL

Keep component variants finite and documented.

---

# 258. COMPONENT STATE MATRIX

At minimum:

- default;
- hover;
- focus;
- active;
- disabled;
- loading;
- error;
- success.

---

# 259. RESPONSIVE COMPONENT MATRIX

Test mobile/tablet/desktop/wide for core components.

---

# 260. VISUAL CONSISTENCY

Spacing, iconography, borders, radii and states are token/component-driven.

---

# 261. LEGACY CSS AUDIT

Find:

- global collisions;
- duplicate classes;
- inline hacks;
- obsolete themes;
- inconsistent icon systems.

---

# 262. GLOBAL CSS SAFETY

Avoid broad selectors that break code/formulas/editor content.

---

# 263. Z-INDEX LAYERS

Define explicit layers for:

- base;
- sticky;
- dropdown;
- modal;
- toast.

No z-index arms race.

---

# 264. OVERFLOW

Test long:

- technical terms;
- URLs;
- code;
- tables;
- formulas.

---

# 265. TEXT TRUNCATION

Only secondary metadata may truncate.

Essential instruction/title remains accessible in full.

---

# 266. RESPONSIVE TOOLBAR

Primary action remains visible.

Secondary actions can move to overflow menu.

---

# 267. RESPONSIVE TABLE

Choose according to task:

- horizontal scroll;
- priority columns;
- stacked card.

Do not squash unreadably.

---

# 268. RESPONSIVE CHART

Labels remain legible and textual data alternative exists.

---

# 269. RESPONSIVE EDITOR

Mobile uses single pane with sheets/tabs.

Desktop may use multiple panes.

---

# 270. GRAPH EDITOR DEVICE POLICY

Full graph authoring may be desktop-preferred.

Small-screen fallback can be list/read-only or constrained editing.

Do not fake a desktop canvas on a tiny screen.

---

# 271. CAPABILITY DETECTION

Feature-detect:

- microphone;
- speech recognition;
- storage;
- install;
- pointer/hover.

Do not infer capability from viewport alone.

---

# 272. HYBRID INPUT DEVICE

Tablet/laptop hybrids support touch + keyboard simultaneously.

---

# 273. SAFE ROUTE TRANSITION

Before route change handle:

- unsaved draft;
- active recording;
- official assessment;
- pending authoring action.

---

# 274. ROUTE ERROR

App shell/navigation remains available when a route fails.

---

# 275. SESSION RESTORE

Reload returns to a meaningful safe state.

---

# 276. REALISTIC UX FIXTURES

Use Russian/Vietnamese/technical/code/math content.

`Lorem ipsum` is insufficient for critical layout testing.

---

# 277. LONG STRING FIXTURE

Test IDs, paths, URLs, technical names and compound Russian phrases.

---

# 278. MULTILINGUAL FIXTURE

Russian + Vietnamese + English + numbers + symbols.

---

# 279. DARK/HIGH-CONTRAST FIXTURE

Include formulas, code, audio and editor controls.

---

# 280. USER JOURNEY GOLDEN SET

Maintain golden journeys for:

- Today;
- lesson;
- listening;
- speaking;
- review;
- scenario;
- writing;
- assessment;
- authoring;
- activation.

---

# 281. LEARNER JOURNEY — TODAY

Open app → understand priorities → start next task.

---

# 282. LEARNER JOURNEY — LESSON

Open lesson → understand objective → practice → feedback → continue.

---

# 283. LEARNER JOURNEY — LISTENING

Play → answer → feedback → replay/remediation.

---

# 284. LEARNER JOURNEY — SPEAKING

Permission → record → feedback → retry.

---

# 285. LEARNER JOURNEY — REVIEW

Due queue → answer → feedback → updated queue.

---

# 286. LEARNER JOURNEY — SCENARIO

Objective → interact → recover → complete → debrief.

---

# 287. LEARNER JOURNEY — WRITING

Source → draft → autosave → feedback → revise → submit.

---

# 288. LEARNER JOURNEY — DEFENSE

Project/slide → response → follow-up → debrief.

---

# 289. AUTHOR JOURNEY

Search entity → draft edit → validate → review → preview → approve → activate.

---

# 290. IMPORT JOURNEY

Upload → map → validate → correct → stage.

---

# 291. ROLLBACK JOURNEY

Find bad changeset → inspect impact → rollback/forward-fix → verify.

---

# 292. KEYBOARD JOURNEY

A keyboard-only learner can navigate, play, answer, submit and read feedback.

---

# 293. LARGE-TEXT JOURNEY

Large text/zoom keeps all essential controls usable.

---

# 294. OFFLINE JOURNEY

Cached lesson → complete local task → reload → state preserved → AI unavailable gracefully.

---

# 295. FAILURE JOURNEY

Network/audio/AI/save failure → user understands state → recovers without lost work.

---

# 296. UX ANALYTICS

Possible diagnostic metrics:

- search success;
- action completion;
- error recovery;
- abandonment by step;
- support use.

Do not optimize for time-spent alone.

---

# 297. NO DARK PATTERNS

Do not:

- guilt overdue learners;
- hide exit;
- repeatedly nag install/notification;
- inflate progress;
- obscure destructive consequences.

---

# 298. LEARNER AGENCY

Allow browse/skip optional/postpone/stop AI/exit scenario/change support language except where official assessment policy constrains behavior.

---

# 299. ANALYTICS PRIVACY

Do not record private text/audio merely for UI analytics by default.

---

# 300. ANALYTICS EVENT SEMANTICS

Prefer behavior events:

`lesson_started`

not presentation events:

`blue_button_clicked`.

---

# 301. FEATURE DISCOVERABILITY

Important features should be reachable in context.

Avoid hidden menu labyrinth.

---

# 302. PROGRESSIVE DISCLOSURE

Advanced options appear only when needed.

---

# 303. EXPERT DENSITY

Admin/editor may use denser presentation than learner while preserving accessibility.

---

# 304. GLOSSARY UX

Term click opens lightweight glossary panel.

Closing returns focus.

---

# 305. MULTI-PANE RESEARCH

Desktop may support source + draft + feedback panes.

Mobile must provide equivalent sequential access.

---

# 306. PANE PREFERENCE

Layout preference is UI preference, not learning state.

---

# 307. DEFAULTS

System must be usable without configuring settings.

---

# 308. FIRST-RUN

Avoid forcing long onboarding or false-precision CEFR selection.

Diagnostic can be offered with clear purpose.

---

# 309. STAGE GATE UX

Show:

- requirements;
- readiness evidence;
- attempt state;
- remediation.

No opaque pass prediction.

---

# 310. LOCKED CONTENT

If hard lock exists, explain prerequisite.

Prefer soft preview when pedagogy permits.

---

# 311. ADVANCED PREVIEW

Preview is clearly non-credit/non-mastery.

---

# 312. DEPRECATED DEEP LINK

Redirect/show replacement rather than blank failure where possible.

---

# 313. 404 / MISSING CONTENT

Offer search/course navigation.

---

# 314. BROKEN MEDIA

Fallback text/alternate media/action.

---

# 315. UNSUPPORTED API/BROWSER

Explain feature limitation and fallback.

Do not block whole course.

---

# 316. LOW STORAGE

Offer removable offline packs.

Never imply learner progress must be deleted.

---

# 317. UPDATE CONFLICT

Do not swap content/version under an active assessment or unsaved long draft.

---

# 318. ASSESSMENT INTERRUPTION

Recover according to P4; tell learner what happened to attempt.

---

# 319. SESSION EXPIRY

Protect draft and explain re-auth/retry.

---

# 320. UX SECURITY

Admin actions clearly indicate environment/privilege context.

Never expose secrets unnecessarily.

---

# 321. SANITIZED TECHNICAL DETAILS

Admin can expand raw errors/logs safely.

Learner gets plain-language error.

---

# 322. PERFORMANCE-SENSITIVE UX

Flag visible regressions:

- first interaction delay;
- layout shift;
- frozen editor;
- slow search;
- recorder delay.

P14 hardens metrics.

---

# 323. LAYOUT SHIFT

Reserve media/player space.

Avoid controls jumping after load.

---

# 324. SCROLL PERFORMANCE

Virtualize long lists and avoid heavy nested animation.

---

# 325. TYPING PERFORMANCE

Long drafts remain responsive.

---

# 326. RECORDING FEEDBACK LATENCY

Record control reacts immediately even if backend/recognition startup continues.

---

# 327. AI LATENCY UX

Show pending quickly; allow continue/cancel where appropriate.

---

# 328. SEARCH LATENCY UX

Incremental result presentation allowed.

---

# 329. LOADING PRIORITY

Current task before analytics/decorative content.

---

# 330. MOBILE DATA AWARENESS

Avoid automatic large media downloads on metered/cellular connections unless user opted in.

---

# 331. MEDIA PRELOAD

Preload current/next small set only.

---

# 332. VIDEO/AUDIO AUTOPLAY

Do not autoplay disruptive sound by default.

Respect browser/user preference/task policy.

---

# 333. MOTION

Short/subtle and nonessential.

Respect reduced motion.

---

# 334. CELEBRATION

Use only for meaningful milestone.

No constant confetti.

---

# 335. BRAND/DESIGN COHERENCE

Russian subject should remain visually part of the same product ecosystem.

---

# 336. SUBJECT ACCENT

Optional color/accent can distinguish subject but must not be sole semantic channel.

---

# 337. TECHNICAL DIAGRAM STYLE

Consistent labels/fonts/spacing.

Readable on mobile and screenshot/print.

---

# 338. UX WRITING STYLE

Learner:

concise, instructional, non-patronizing.

Admin:

precise and action-oriented.

---

# 339. TERMINOLOGY CONSISTENCY

Same domain concept/action uses same UI label across search, lesson, progress and editor.

---

# 340. STRESS DISPLAY MODE

Stress marks can be shown/hidden according to learning mode while canonical data remains unchanged.

---

# 341. SUPPORT REVEAL PATTERN

Translation, hint and stress reveal should use consistent interaction patterns.

---

# 342. DESIGN DOCUMENTATION

Maintain:

- IA map;
- design tokens;
- component state matrix;
- responsive matrix;
- accessibility checklist;
- critical journeys.

Do not document every pixel.

---

# 343. VISUAL REGRESSION BASELINE

Representative screens:

- Home;
- Roadmap;
- Lesson;
- Listening;
- Speaking;
- Scenario;
- Writing;
- Assessment;
- Content list;
- Editor;
- Review diff.

---

# 344. REPRESENTATIVE VIEWPORTS

At least:

- small mobile;
- large mobile;
- tablet;
- desktop.

No need every device model.

---

# 345. VISUAL REGRESSION LIMIT

Screenshot similarity is not sufficient usability evidence.

Pair with interaction/accessibility tests.

---

# 346. UX REGRESSION SEVERITY

`BLOCKER`

`CRITICAL`

`HIGH`

`MEDIUM`

`LOW`.

---

# 347. BLOCKER EXAMPLES

- cannot navigate core flow;
- official submit unreachable;
- long draft silently lost;
- recording continues invisibly;
- answer key exposed;
- false saved/published state;
- mobile layout blocks required action;
- keyboard trap;
- no recovery from critical error.

---

# 348. CRITICAL EXAMPLES

- mastery display is misleading;
- stale error banner persists;
- AI silently overwrites text;
- scenario hidden fact leaks;
- search cannot resolve canonical Cyrillic term;
- large text clips controls;
- dark mode makes technical content unreadable.

---

# 349. P13 PILOT SCREENS

Learner:

- Today;
- Roadmap;
- Lesson;
- Listening;
- Speaking;
- Scenario;
- Writing;
- Assessment.

Admin:

- Content list;
- Editor;
- Review;
- Import;
- Scenario graph;
- Activation.

---

# 350. P13 PILOT CONDITIONS

Test:

- mobile;
- tablet;
- desktop;
- keyboard-only;
- large text;
- reduced motion;
- dark/high contrast where supported;
- offline/degraded.

---

# 351. PILOT ACCEPTANCE

Must prove:

- clear IA;
- truthful states;
- responsive composition;
- touch;
- keyboard/focus;
- accessibility;
- error recovery;
- no domain-contract mutation.

---

# 352. MIGRATION ORDER

Recommended:

1. IA map;
2. design tokens;
3. app shell/navigation;
4. typography/responsive primitives;
5. core components;
6. lesson/review;
7. listening/speaking;
8. assessment;
9. scenario;
10. writing/research;
11. AI Mentor;
12. authoring/admin;
13. accessibility pass;
14. visual regression;
15. legacy CSS cleanup.

---

# 353. NO BIG-BANG REDESIGN

Refactor in coherent slices.

Preserve working domain logic.

---

# 354. LEGACY UI CLASSIFICATION

`KEEP`

`RESTYLE`

`RECOMPOSE`

`REPLACE_PRESENTATION`

`DEPRECATE_LATER`.

---

# 355. HIDDEN DOMAIN LOGIC

Before deleting old UI, extract any embedded domain/state logic into canonical engine.

---

# 356. REQUIRED DELIVERABLES — IA/DESIGN

Create/maintain:

`subjects/russian/docs/p13/RUSSIAN_P13_EXECUTIVE_SUMMARY.md`

`RUSSIAN_INFORMATION_ARCHITECTURE_MAP.md`

`RUSSIAN_NAVIGATION_CONTRACT.md`

`RUSSIAN_RESPONSIVE_LAYOUT_MATRIX.md`

`RUSSIAN_DESIGN_TOKEN_CONTRACT.md`

`RUSSIAN_COMPONENT_STATE_MATRIX.md`

`RUSSIAN_TYPOGRAPHY_CONTENT_RULES.md`.

---

# 357. REQUIRED DELIVERABLES — ACCESSIBILITY

Create:

`RUSSIAN_ACCESSIBILITY_REQUIREMENTS.md`

`RUSSIAN_KEYBOARD_FOCUS_MATRIX.md`

`RUSSIAN_MEDIA_ACCESSIBILITY_MATRIX.md`

`RUSSIAN_ACCESSIBILITY_TEST_REPORT.md`.

---

# 358. REQUIRED DELIVERABLES — JOURNEYS

Create:

`RUSSIAN_LEARNER_JOURNEY_MATRIX.md`

`RUSSIAN_AUTHORING_JOURNEY_MATRIX.md`

`RUSSIAN_ERROR_RECOVERY_MATRIX.md`

`RUSSIAN_OFFLINE_UX_MATRIX.md`.

---

# 359. REQUIRED DELIVERABLES — QA

Create:

`RUSSIAN_P13_VISUAL_REGRESSION_BASELINE.md`

`RUSSIAN_P13_RESPONSIVE_QA_REPORT.md`

`RUSSIAN_P13_UX_RISK_REGISTER.json`

`RUSSIAN_P13_EVIDENCE_INDEX.md`

`RUSSIAN_P14_INPUT_CONTRACT.md`.

No empty ceremonial documents.

---

# 360. TEST MATRIX — NAVIGATION

Test:

- deep link;
- back;
- reload;
- stage/module;
- search;
- missing/deprecated route.

---

# 361. TEST MATRIX — RESPONSIVE

Test representative:

- mobile portrait/landscape;
- tablet;
- desktop;
- wide screen.

---

# 362. TEST MATRIX — ACCESSIBILITY

Test:

- keyboard;
- focus;
- semantic structure;
- large text;
- contrast;
- reduced motion.

---

# 363. TEST MATRIX — STATES

Test:

- loading;
- empty;
- error;
- offline;
- saving;
- saved;
- conflict;
- disabled;
- permission denied.

---

# 364. TEST MATRIX — LEARNING

Test:

- lesson;
- SRS;
- listening;
- speaking;
- assessment;
- scenario;
- writing.

---

# 365. TEST MATRIX — AUTHORING

Test:

- edit;
- validate;
- review;
- approve;
- preview;
- activate;
- rollback;
- import.

---

# 366. TEST MATRIX — CAPABILITY

Test:

- mic supported/denied;
- speech recognition unsupported;
- low storage;
- offline;
- touch;
- keyboard.

---

# 367. TEST MATRIX — MULTILINGUAL

Test:

- Russian;
- Vietnamese;
- English;
- bilingual;
- long strings.

---

# 368. TEST MATRIX — CONTENT EXTREMES

Test:

- long title;
- technical term;
- large table;
- formula;
- code block;
- long draft;
- many validation errors.

---

# 369. UX EVIDENCE

For major screen capture:

- route;
- viewport;
- state;
- screenshot;
- interaction result;
- accessibility notes.

Do not claim responsive from one desktop image.

---

# 370. P14 HANDOFF CONTRACT

P13 supplies P14:

- critical journeys;
- representative device matrix;
- offline UX expectations;
- performance-sensitive screens;
- storage/recovery expectations;
- accessibility constraints;
- update/version semantics;
- large-data UI expectations;
- fallback/error semantics.

P14 hardens packaging, cache, performance, migration and security without breaking P13 interaction meaning.

---

# 371. P13 FAIL CONDITIONS

P13 FAIL if:

- next action is unclear;
- UI invents mastery/progress;
- mobile is merely desktop squeezed;
- core controls are unreachable;
- keyboard/focus is broken;
- saved/published state lies;
- offline state is ambiguous;
- AI silently overwrites learner work;
- hidden assessment/scenario data leaks;
- authoring actions have ambiguous lifecycle;
- large text/mobile breaks key flows;
- accessibility relies on color/hover only;
- huge lists freeze usability;
- P14 has no explicit non-functional handoff.

---

# 372. P13 PASS CONDITIONS

P13 PASS when:

1. Learner IA is clear.
2. Author/admin IA is clear.
3. Today consumes canonical P5 plan.
4. Roadmap reflects curriculum without faking mastery.
5. Search handles Russian/support aliases.
6. Responsive composition works across representative devices.
7. Typography supports Cyrillic/Vietnamese/math/code/stress.
8. Appearance/font settings do not break layouts.
9. Accessibility semantics are built in.
10. Keyboard/focus works.
11. Touch works.
12. Loading/empty/error/offline states are explicit.
13. Save/sync/activation states are truthful.
14. Progress/mastery/review distinctions are visible.
15. Listening/speaking UX respects P6.
16. Assessment UX respects P4.
17. AI Mentor UX respects P10.
18. Scenario UX respects P11.
19. Writing/research UX respects P9.
20. Authoring/review UX respects P12.
21. Hidden internal state is not exposed.
22. Long-form draft UX is safe.
23. Large admin datasets remain usable.
24. Design tokens/components are coherent.
25. Dark/high contrast are coherent when supported.
26. Representative visual regression baseline exists.
27. Critical learner journeys pass.
28. Critical authoring journeys pass.
29. Accessibility journey passes.
30. P14 receives complete handoff.

---

# 373. P13 PROMPT COMPLETENESS GATE

P13 is structurally complete only if it covers:

1. learner IA;
2. author IA;
3. navigation;
4. search;
5. dashboard;
6. course/lesson layout;
7. responsive;
8. typography;
9. color/contrast;
10. appearance/language settings;
11. localization;
12. accessibility;
13. keyboard/touch;
14. loading/error/offline;
15. progress/mastery presentation;
16. listening;
17. speaking;
18. scenario;
19. AI Mentor;
20. writing/research;
21. assessment;
22. authoring/review;
23. settings;
24. offline/update UX;
25. performance perception;
26. privacy UX;
27. design system;
28. visual regression;
29. critical journeys;
30. P14 handoff.

If all are defined:

`P13 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does not mean repository P13 implementation has PASSed.

---

# 374. FINAL RESPONSE FORMAT

When P13 implementation completes:

`P13 STATUS: PASS / FAIL / BLOCKED`

`Base SHA:`

`Head SHA:`

`Learner IA: PASS / FAIL`

`Author/Admin IA: PASS / FAIL`

`Navigation/Search: PASS / FAIL`

`Responsive: PASS / FAIL`

`Typography: PASS / FAIL`

`Accessibility: PASS / FAIL`

`Keyboard/Focus: PASS / FAIL`

`Touch/Mobile: PASS / FAIL`

`Loading/Error/Offline: PASS / FAIL`

`Progress/Mastery presentation: PASS / FAIL`

`Listening/Speaking UX: PASS / FAIL`

`Assessment UX: PASS / FAIL`

`AI Mentor UX: PASS / FAIL`

`Scenario UX: PASS / FAIL`

`Writing/Research UX: PASS / FAIL`

`Authoring/Review UX: PASS / FAIL`

`Design system: PASS / FAIL`

`Visual regression: PASS / FAIL`

`Critical journeys: PASS / FAIL`

`P14 readiness: READY / NOT READY`

`PR:`

`Merged SHA:`

`Production: UNCHANGED unless explicitly authorized`

End:

**P13 UX · ACCESSIBILITY · RESPONSIVE · INFORMATION ARCHITECTURE COMPLETE**

---

# 375. EXECUTION RULE

When authorized:

`audit actual routes/screens/styles`

→ `map learner/admin journeys`

→ `identify hidden domain logic in UI`

→ `lock IA`

→ `normalize design tokens`

→ `normalize app shell/navigation`

→ `normalize typography/responsive primitives`

→ `refactor shared components`

→ `fix lesson/review`

→ `fix listening/speaking`

→ `fix assessment`

→ `fix scenario`

→ `fix writing/research`

→ `fix AI Mentor`

→ `fix authoring/admin`

→ `run accessibility`

→ `run responsive/visual regression`

→ `remove legacy presentation duplication`

→ `document evidence`

→ `open PR`.

Do not begin by repainting colors while navigation/state semantics remain broken.

---

# 376. FINAL P13 PRINCIPLE

A professional interface is not the one with the most effects.

It is the one where:

- the learner knows the next action;
- state is truthful;
- content is readable;
- errors are recoverable;
- touch and keyboard both work;
- mobile preserves capability;
- AI remains bounded;
- assessments remain trustworthy;
- authors can review safely;
- the design remains coherent as content grows.

For every screen ask:

1. Who is this for?
2. What is the primary goal?
3. What is the primary action?
4. Which domain state is represented?
5. Can that state be misunderstood?
6. What happens on mobile/tablet/desktop?
7. What happens with keyboard/large text?
8. What happens offline/error?
9. What happens with very long content?
10. Does the screen preserve P1–P12 contracts?

If these are not answerable:

the screen is not production-ready.

**CLARITY BEFORE DECORATION.**

**STATE TRUTH BEFORE ANIMATION.**

**ACCESSIBILITY BEFORE POLISH.**

**RESPONSIVE BY COMPOSITION, NOT SHRINKING.**

**ONE DESIGN SYSTEM · MANY CAPABILITIES.**

# RUSSIAN MASTER PROMPT
# SINGLE-SOURCE PROMPT · FORENSIC → CURRICULUM → SCHEMA → ASSESSMENT/MASTERY

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

---

## MASTER ORCHESTRATION RULE

File này là **nguồn prompt duy nhất** cho quá trình nâng cấp môn Tiếng Nga.

Không tạo thêm các file kiểu:

- `prompt-v2.md`
- `prompt-final.md`
- `prompt-final2.md`
- `prompt-new.md`
- `prompt-rebuild.md`

Mọi nâng cấp sau này phải:

1. đọc file này;
2. xác định phase hiện tại;
3. sửa/bổ sung đúng section;
4. ghi changelog;
5. không tạo nguồn prompt thứ hai nếu không có lý do kiến trúc đặc biệt.

### Phase model

- **P1** — Forensic Foundation Audit.
- **P2** — Deep Content & Curriculum Reconstruction.
- **P3** — Content Schema Constitution.
- **P4** — Assessment & Mastery Constitution.
- **P5+** — Chỉ bổ sung vào chính file này khi được thiết kế tiếp.

### Precedence

Nếu một phase cũ nói “không tự chuyển phase”, quy tắc đó chỉ áp dụng trong lúc phase đó đang chạy.

Khi người dùng đã yêu cầu **“tiếp theo / tiếp tục / nâng cấp prompt”** sau khi phase trước hoàn tất, các phase kế tiếp trong file này được xem là đã được ủy quyền để lập kế hoạch/triển khai theo gate của chúng.

Không chạy tất cả phase cùng lúc nếu phase trước chưa đủ evidence.

---

## GLOBAL PROMPT GOVERNANCE STANDARD

Quy tắc này áp dụng cho **tất cả dự án đã có, đang làm và sẽ tạo prompt sau này**:

> **ONE PROJECT · ONE MASTER PROMPT FILE · CONTINUOUS EVOLUTION**

Mỗi dự án nên có một file Master Prompt duy nhất trong repository, ví dụ:

- `PROJECT_MASTER_PROMPT.md`
- hoặc một tên chuyên biệt ổn định như `RUSSIAN_MASTER_PROMPT.md`.

Mỗi lần nâng cấp:

- không tạo prompt rời mới;
- không copy toàn bộ prompt sang phiên bản khác;
- không tăng version trong tên file;
- chỉ patch/append section;
- giữ lịch sử thay đổi trong `CHANGELOG`;
- nếu nội dung cũ bị thay thế, đánh dấu `SUPERSEDED` hoặc chỉnh trực tiếp nhưng giữ migration note khi cần.

### Token-efficiency rule

Work/Codex không được đọc lại toàn repository nếu:

- inventory gần nhất còn hợp lệ;
- SHA không thay đổi ở khu vực liên quan;
- evidence index đã tồn tại;
- change scope có thể xác định bằng diff.

Ưu tiên:

`status → diff → impacted dependencies → targeted files → tests`

thay vì:

`rescan everything`.

---

## MASTER CHANGELOG

- 2026-09-30 — Consolidated original P1 forensic prompt into a single Master Prompt.
- 2026-09-30 — Added Deep Content & Curriculum architecture.
- 2026-09-30 — Added R01–R26 macro-module / unit / micro-lesson architecture.
- 2026-09-30 — Added Content Schema Constitution.
- 2026-09-30 — Added Assessment & Mastery Constitution.
- 2026-09-30 — Added Adaptive SRS & Personalization Constitution.
- 2026-09-30 — Hardened the 17-layer execution architecture; added formal P0 orchestration, completed P6 Listening/Speaking foundation, and locked P7–P17 responsibilities/gates.
- Future upgrades: append or revise this same file.

---


# PART 0 — P0 MASTER ORCHESTRATION & EXECUTION CONSTITUTION

## P0.0 PURPOSE

P0 là **bộ chỉ huy thi công** của toàn bộ RUSSIAN MASTER PROMPT.

P0 không sở hữu nội dung học.

P0 sở hữu:

- thứ tự phase;
- phạm vi phase;
- trạng thái phase;
- evidence requirements;
- dependency rules;
- change control;
- merge/publish authority flow;
- rollback requirements;
- token-efficient execution;
- stop/continue logic.

P0 tồn tại để ngăn hệ thống rơi vào tình trạng:

- mỗi prompt hiểu kiến trúc khác nhau;
- phase sau phá phase trước;
- test PASS nhưng runtime sai;
- sửa symptom thay vì root cause;
- duplicate engine;
- duplicate dataset;
- merge khi chưa đủ evidence;
- publish khi chưa đủ acceptance gate.

---

## P0.1 17-LAYER BUILD MODEL

Toàn bộ chương trình được xem như một công trình 17 tầng:

### FOUNDATION / LOAD-BEARING FRAME

`P0 → P1 → P2 → P3 → P4 → P5 → P6`

P0:
Command & orchestration.

P1:
Forensic reality map.

P2:
Curriculum & content architecture.

P3:
Canonical data/schema ownership.

P4:
Assessment/mastery truth.

P5:
Adaptive/SRS/personalization.

P6:
Listening/speaking/audio interaction engine.

Khi P0–P6 PASS:

> **MÓNG + KHUNG CHỊU LỰC ĐƯỢC COI LÀ KHÓA.**

Các phase sau không được tùy ý đổi contract P0–P6.

---

### PRODUCT / LEARNING FLOORS

`P7 → P13`

P7:
Linguistic Authority & Content Validation.

P8:
Academic & Technical Russian Deepening.

P9:
Reading · Writing · НИР · ВКР Production System.

P10:
AI Mentor Pedagogy & Guardrails.

P11:
Scenario · Simulation · Dialogue Experience Layer.

P12:
Authoring · Content Governance · Editor Workflow.

P13:
UX · Accessibility · Responsive · Information Architecture Integration.

Các tầng này xây **không gian sử dụng thực tế** trên khung P0–P6.

---

### ENGINEERING / ACCEPTANCE / DE-SCAFFOLDING

`P14 → P16`

P14:
Offline · Packaging · Performance · Migration · Security Hardening.

P15:
Full-System QA · Regression · Acceptance · Evidence.

P16:
Legacy Retirement · Technical Debt Closure · Release Candidate Freeze · Documentation.

---

### PRODUCTION

`P17`

Production publish/deploy/verification/rollback/observability.

P17 không được sửa kiến trúc lớn.

Nếu P17 phát hiện lỗi kiến trúc:

return phase owner.

Không hot-fix architecture trực tiếp trong publish phase trừ blocker nhỏ, isolated và rollback-safe.

---

## P0.2 PHASE STATE MACHINE

Mỗi phase phải ở đúng một trạng thái:

`NOT_STARTED`

`BASELINING`

`IN_PROGRESS`

`VALIDATING`

`BLOCKED`

`FAIL`

`PASS`

`SUPERSEDED`

Không dùng trạng thái mơ hồ:

“gần xong”
“có vẻ ổn”
“tạm được”.

---

## P0.3 PHASE CONTRACT

Mọi phase P1–P17 bắt buộc phải có:

1. Mission.
2. Preconditions.
3. Inputs.
4. Canonical owners affected.
5. Allowed changes.
6. Forbidden changes.
7. Required deliverables.
8. Runtime tests.
9. Static/schema tests.
10. Data/state migration tests khi liên quan.
11. Regression scope.
12. Evidence index.
13. Risk register delta.
14. Rollback plan.
15. Exit gate.
16. PR/merge rule.
17. Production effect.

Nếu phase thiếu một trong các mục trên:

phase chưa đủ chắc để tự động thực hiện.

---

## P0.4 ENTRY GATE

Một phase chỉ được START khi:

- previous required phase = PASS;
- required evidence tồn tại;
- current main SHA được ghi nhận;
- impacted scope được xác định;
- no unresolved blocker từ dependency phase;
- branch strategy rõ.

Không cần previous phase toàn bộ repo PASS nếu phase hiện tại chỉ phụ thuộc subset rõ ràng.

Dependency graph quyết định.

---

## P0.5 EXIT GATE

Một phase chỉ PASS khi:

- deliverables complete;
- runtime behavior verified;
- tests relevant PASS;
- evidence complete;
- no unresolved BLOCKER;
- no unresolved CRITICAL thuộc scope phase;
- migration/rollback validated nếu có;
- documentation reflects actual runtime;
- PR scope sạch.

CI xanh một mình KHÔNG đủ.

Screenshot đẹp một mình KHÔNG đủ.

JSON valid một mình KHÔNG đủ.

---

## P0.6 HARD BLOCKERS

Dừng phase khi có:

- learner data loss risk chưa kiểm soát;
- mastery corruption;
- destructive migration không rollback;
- canonical ownership conflict chưa giải quyết;
- production-only dependency không test được;
- credential/authorization bắt buộc không có;
- source-of-truth ambiguity làm kết luận không thể đáng tin.

Không dừng vì:

- lint;
- formatting;
- test nhỏ sửa được;
- refactor nội bộ rollback-safe;
- rename nội bộ;
- ordinary dependency fix.

Các lỗi kỹ thuật thông thường phải tự xử lý.

---

## P0.7 ROOT-CAUSE RULE

Không sửa symptom hàng loạt.

Workflow:

`OBSERVE`
→ `REPRODUCE`
→ `TRACE OWNER`
→ `IDENTIFY ROOT CAUSE`
→ `DEFINE IMPACT`
→ `PATCH OWNER`
→ `REGRESSION TEST`
→ `VERIFY RUNTIME`.

Nếu một bug xuất hiện ở 5 route nhưng cùng root cause:

sửa root cause một lần.

---

## P0.8 OWNERSHIP RULE

Mỗi responsibility chỉ có một canonical owner.

Examples:

- content truth;
- grammar truth;
- lexical truth;
- route;
- mastery;
- SRS;
- assessment scoring;
- Today planner;
- audio playback;
- recording;
- speech recognition adapter;
- dialogue state;
- offline cache;
- package build.

Nếu MULTIPLE OWNER:

không mở rộng feature trước khi ownership được resolve hoặc facade/adaptor rõ.

---

## P0.9 FOUNDATION FREEZE AFTER P6

Sau khi P6 PASS:

P1–P6 contracts trở thành **LOAD-BEARING CONTRACTS**.

P7–P17 không được thay đổi chúng tùy tiện.

Muốn thay phải tạo:

`FOUNDATION CHANGE REQUEST`

gồm:

- reason;
- affected contract;
- alternatives considered;
- migration;
- regression scope;
- rollback;
- downstream phases impacted.

Nếu change không cần thiết:

không chạm foundation.

---

## P0.10 CHANGE CLASSIFICATION

Mọi thay đổi được phân loại:

### CLASS A — PRESENTATION ONLY
Không đổi behavior/state.

### CLASS B — DOMAIN BEHAVIOR
Đổi logic nhưng không schema/state identity.

### CLASS C — DATA/SCHEMA
Đổi canonical data shape.

### CLASS D — STATE/MIGRATION
Đổi learner state/mastery/SRS.

### CLASS E — ARCHITECTURE
Đổi owner/boundary/protocol.

### CLASS F — PRODUCTION
Deploy/config/runtime environment.

Class càng cao:

gate càng mạnh.

---

## P0.11 EVIDENCE HIERARCHY

Ưu tiên:

1. Runtime evidence.
2. Browser evidence.
3. State/storage evidence.
4. Network/performance trace.
5. Automated test.
6. Code trace.
7. Documentation.
8. Historical report.

Docs/report không được override runtime reality.

---

## P0.12 EVIDENCE INDEX

Mỗi conclusion quan trọng phải trỏ tới:

- file/line;
- test;
- screenshot;
- trace;
- runtime measurement;
- storage snapshot;
- migration fixture;
- package artifact.

Không viết:

“seems”
“probably”
“looks unused”

cho architectural conclusion.

Dùng:

`UNKNOWN`
hoặc:
`NEEDS VALIDATION`.

---

## P0.13 TOKEN-EFFICIENT EXECUTION

Không quét lại toàn repo nếu không cần.

Execution order:

1. read phase status;
2. get current SHA;
3. inspect diff from last validated SHA;
4. identify impacted owners;
5. read only dependencies;
6. run targeted tests;
7. expand scope only if evidence requires.

Reuse:

- file inventory;
- owner registry;
- evidence index;
- dependency graph;
- previous test baseline.

---

## P0.14 NO REPORT SPAM

Không tạo 5 report mô tả cùng một finding.

Ưu tiên:

- one canonical report per responsibility;
- machine-readable artifact;
- concise human summary.

Update existing report when appropriate.

---

## P0.15 BRANCH STRATEGY

Mỗi phase hoặc coherent batch:

separate branch nếu thay đổi đáng kể.

Naming conceptually:

`russian/pX-<scope>`

Không bắt version label.

Không tạo branch theo từng edit nhỏ.

---

## P0.16 COMMIT STRATEGY

Commit theo coherent root-cause batch.

Không:

- commit từng dòng;
- mega commit toàn course.

Mỗi commit phải reviewable và rollbackable.

---

## P0.17 PR STRATEGY

PR phải trả lời:

- What changed?
- Why?
- Which owner?
- Evidence?
- Tests?
- Migration?
- Risks?
- Rollback?
- Production impact?

Không mở PR “misc fixes”.

---

## P0.18 MERGE AUTHORITY

Merge chỉ khi phase gate PASS.

Không merge vì:

“cần đi tiếp”.

Nếu blocker chưa resolve:

stay branch.

---

## P0.19 PRODUCTION AUTHORITY

P1–P16 không tự coi production là success.

P17 là production authority.

Exception:

explicit project rule cho phép preview/test deploy.

Preview ≠ production.

---

## P0.20 ROLLBACK CONSTITUTION

Mọi Class C–F change cần rollback strategy.

Possible rollback:

- commit revert;
- schema downgrade/read-old compatibility;
- feature flag;
- old package;
- previous deployment;
- cache version rollback.

“Có Git nên rollback được” không đủ nếu state đã migrate destructively.

---

## P0.21 STATE PROTECTION

Bất kỳ phase nào chạm state phải chứng minh:

- old state fixture;
- migration;
- new state;
- repeated migration;
- corrupted state behavior;
- rollback/recovery.

Không silent reset.

---

## P0.22 DATA PROTECTION

Không delete canonical data chỉ vì “không thấy dùng”.

Need:

- references;
- runtime load;
- route reachability;
- derived dependencies;
- state references;
- package references.

Delete only after migration evidence.

---

## P0.23 TEST PYRAMID

Use multiple levels:

- schema/static;
- unit/domain;
- integration;
- browser;
- offline/package;
- visual;
- accessibility;
- performance;
- migration;
- acceptance.

Không dùng static string assertions để giả runtime coverage.

---

## P0.24 BROWSER MATRIX

At minimum representative:

Desktop.

Tablet.

Mobile.

Touch.

Keyboard.

Offline.

Unsupported optional APIs where relevant.

Do not require every phase to retest every viewport if dependency unaffected; use risk-based selection.

---

## P0.25 NON-FUNCTIONAL BASELINES

Baseline before major refactor:

- bundle/data size;
- startup requests;
- memory;
- DOM nodes;
- route latency;
- storage;
- cache;
- accessibility;
- error console.

Compare after.

---

## P0.26 NO FAKE PASS

PASS requires evidence.

Do not auto-write:

PASS

because task runner ended.

If test coverage insufficient:

status:

`VALIDATING`

or:

`FAIL / INCOMPLETE EVIDENCE`.

---

## P0.27 PHASE TRANSITION RECORD

When phase passes, record:

- phase;
- date;
- main/base SHA;
- head SHA;
- evidence artifact;
- known limitations;
- downstream assumptions.

This lets future Work/Codex avoid rescanning.

---

## P0.28 DOWNSTREAM CONTRACT

Each phase must publish:

`INPUT CONTRACT FOR NEXT PHASE`.

Next phase should consume that contract rather than rediscover everything.

---

## P0.29 REGRESSION OWNERSHIP

If P10 causes bug in P4 mastery:

bug owner is not automatically P10.

Trace root cause.

Fix canonical owner.

Then rerun impacted downstream gates.

---

## P0.30 PHASE INVALIDATION

A previously PASS phase becomes:

`NEEDS_REVALIDATION`

only if later diff touches:

- its owner;
- its contract;
- its dependencies;
- its state/schema.

Do not rerun P1–P6 from zero for every small UI change.

---

## P0.31 ACCEPTANCE LANGUAGE

Use precise completion words:

`PASS`

`FAIL`

`BLOCKED`

`NEEDS_REVALIDATION`

`UNCHANGED`

`ROLLED_BACK`.

Avoid:

“almost done”
“probably complete”.

---

## P0.32 AUTONOMOUS EXECUTION

Within authorized phase:

self:

inspect
→ edit
→ test
→ repair
→ rerun
→ document
→ commit
→ PR

without asking user for ordinary technical decisions.

Ask only for:

- credentials;
- external authorization;
- irreversible business choice;
- destructive action with no safe rollback;
- ambiguous pedagogical/product requirement that materially changes outcome.

---

## P0.33 FINAL P0 GATE

P0 PASS when:

1. phase map exists;
2. owner map exists;
3. phase state machine exists;
4. entry/exit gates defined;
5. rollback policy defined;
6. evidence policy defined;
7. change classification defined;
8. foundation freeze defined;
9. transition rules defined;
10. production authority isolated to P17.

**P0 MASTER ORCHESTRATION CONSTITUTION COMPLETE**

---

# PART I — P1 FORENSIC FOUNDATION AUDIT

The following P1 body is preserved from the original forensic prompt.

# RUSSIAN FOUNDATION P1
# FORENSIC SYSTEM AUDIT · GROUND SURVEY FOR A 100-STORY PRODUCT

Repository:
BlueDragon33/Bauman-master-ai-system

Primary scope:
subjects/russian/

Supporting scope when required for dependency tracing:
platform/
foundation/
assets/
tests/
scripts/
.github/workflows/
cloudflare/
control-service/

Execution mode:
AUTONOMOUS · EVIDENCE-FIRST · ROOT-CAUSE-FIRST · TOKEN-EFFICIENT

============================================================
0. MISSION
============================================================

Thực hiện một cuộc FORENSIC AUDIT toàn diện đối với hệ thống học Tiếng Nga Bauman.

Đây KHÔNG phải prompt redesign.
Đây KHÔNG phải prompt làm đẹp UI.
Đây KHÔNG phải prompt thêm feature.
Đây KHÔNG phải prompt xóa legacy hàng loạt.

Mục tiêu của P1:

Hiểu chính xác công trình hiện tại đang được xây như thế nào trước khi thiết kế lại.

Phải trả lời được:

1. Hệ thống hiện có những layer nào?
2. Layer nào đang thật sự sở hữu mỗi responsibility?
3. Có bao nhiêu generation UI đang còn tác động?
4. CSS nào đang thật sự quyết định pixel cuối cùng?
5. Renderer nào đang thật sự tạo DOM cuối cùng?
6. State nào là canonical?
7. Progress/mastery được thay đổi ở đâu?
8. Có duplicate engine không?
9. Route/deep-link nào đang được sử dụng?
10. Dataset nào được preload/lazy load?
11. Offline/PWA đang hoạt động theo contract nào?
12. Những phần nào tốt và PHẢI GIỮ?
13. Những phần nào cần refactor?
14. Những phần nào thực tế đã chết?
15. Những phần nào nhìn như dead code nhưng vẫn có side effect?
16. Những technical debt nào đang trực tiếp gây UI xấu?
17. Những technical debt nào không liên quan UI và không được chạm?
18. Test hiện tại đang chứng minh điều gì?
19. Test nào đang cho cảm giác an toàn giả?
20. Muốn xây hệ thống 10–20 năm thì ranh giới kiến trúc phải đặt lại ở đâu?

Không được kết luận theo tên file hoặc version label.
Chỉ kết luận bằng runtime evidence + code evidence + browser evidence.

============================================================
1. CONSTITUTIONAL PRE-FLIGHT
============================================================

Trước khi audit:

Đọc và tuân thủ:

.blueprint/constitution-adoption.json
docs/UI_CONTRAST_CONSTITUTION.md
foundation/learning-content/web-lesson-standard.v1.json

Đọc các tài liệu Russian architecture hiện tại, tối thiểu:

subjects/russian/docs/REFACTOR_AUDIT_20260923.md
subjects/russian/docs/RUSSIAN_BAUMAN_SURVIVAL_ROADMAP_V7.md
subjects/russian/subject-manifest.json
subjects/russian/README.md

Đọc các report gần nhất có liên quan đến:

Future UI
learning integrity
route
speaking
handwriting
assessment
storage
responsive
overlap
presentation
offline
data loading.

Không tin report lịch sử tuyệt đối.
Report chỉ là hypothesis.
Runtime hiện tại mới là authority.

Ghi lại:

current main SHA
audit date
branch
production SHA nếu có thể xác định
subject manifest version
actual runtime version.

============================================================
2. BRANCH & SAFETY
============================================================

Tạo branch:

audit/russian-p1-forensic-foundation-YYYYMMDD

Không thay đổi behavior production trong P1.

Chỉ được phép thêm:

- audit documents;
- audit scripts;
- read-only instrumentation;
- test probes không thay behavior;
- generated reports/evidence.

Không được:

- redesign UI;
- thay layout;
- đổi màu;
- xóa CSS legacy;
- đổi route;
- đổi learner state;
- migrate storage;
- đổi mastery;
- đổi SRS;
- đổi lesson data;
- merge presentation layer;
- production deploy.

Nếu phát hiện bug nghiêm trọng:
document trước.
Không sửa trong P1 trừ khi bug làm audit không thể tiếp tục.

============================================================
3. INVENTORY — XÂY BẢN ĐỒ TOÀN BỘ HỆ THỐNG
============================================================

Lập inventory machine-readable cho subjects/russian/.

Phân loại toàn bộ file thành:

A. Entry / Shell
B. Presentation
C. Domain runtime
D. Learning engine
E. State / Persistence
F. Data
G. Data loader
H. Offline/PWA
I. Integration / Bridge
J. AI
K. Assessment
L. Speaking
M. Handwriting
N. Testing
O. Build / Packaging
P. Documentation
Q. Legacy / Unknown

Tạo:

subjects/russian/docs/p1/RUSSIAN_FILE_INVENTORY.json

Mỗi file phải có tối thiểu:

path
category
sizeBytes
runtimeLoaded
runtimeLoadOrder
ownerHypothesis
sideEffects
imports
referencedBy
storageKeysTouched
DOMRootsTouched
routesTouched
dataSourcesTouched
status:
  KEEP
  REFACTOR
  MERGE
  DELETE_LATER
  UNKNOWN
riskLevel
evidence

Không suy đoán status nếu chưa đủ evidence.
Dùng UNKNOWN.

============================================================
4. HTML / SCRIPT / STYLE LOAD ORDER AUDIT
============================================================

Phân tích subjects/russian/index.html.

Lập chính xác:

CSS load order
JS load order
defer/async behavior
module/non-module
inline script
runtime bootstrap order
service worker registration
bridge initialization
data initialization
UI initialization.

Xuất:

RUSSIAN_RUNTIME_LOAD_ORDER.md

Cần chỉ ra:

1. CSS nào load trước.
2. CSS nào load sau.
3. CSS nào override CSS nào.
4. JS nào tạo DOM.
5. JS nào mutate DOM sau render.
6. JS nào subscribe state.
7. JS nào dùng MutationObserver.
8. JS nào patch sau DOMContentLoaded.
9. JS nào chạy nhiều lần.
10. JS nào có khả năng race condition.

Nếu có timing-dependent behavior:
chứng minh bằng instrumentation hoặc browser trace.

============================================================
5. CSS FORENSIC AUDIT
============================================================

Đây là phần rất quan trọng.

Audit tối thiểu:

subjects/russian/assets/core.css
subjects/russian/assets/russian.css
subjects/russian/assets/russian-future-ui.css

và mọi CSS Russian thực tế đang load.

Đo:

file size
rule count
selector count
!important count
duplicate selector count
media query count
max specificity
average specificity
CSS custom properties
hard-coded colors
z-index values
fixed heights
overflow:hidden
position:fixed
position:absolute.

Đặc biệt thống kê số lần định nghĩa các selector shell như:

.app
.sidebar
.main
.nav
.nav button
.content
.card
.panel
.topbar
.lesson
.page
.modal

Không chỉ đếm.
Phải xác định rule nào thắng thực tế.

Tạo:

subjects/russian/docs/p1/RUSSIAN_CSS_FORENSIC.json
subjects/russian/docs/p1/RUSSIAN_CSS_OWNERSHIP_MAP.md

CSS ownership map phải trả lời:

Selector/component:
Canonical owner
Legacy owners
Final computed source
Conflicting properties
Required migration
Risk if removed

Ví dụ:

.sidebar
canonical:
legacy:
computed width:
winning declaration:
override chain:
recommended future owner:

Không được kết luận:
“core.css lớn nên xóa”.

Phải xác định từng dependency.

============================================================
6. CASCADE / COMPUTED STYLE EVIDENCE
============================================================

Chạy browser audit.

Chọn các component đại diện:

App shell
Sidebar
Topbar
Primary navigation
Home hero
Today card
Lesson card
Listening control
Speaking control
Vocabulary card
Grammar panel
Writing panel
Assessment
Modal
Mobile navigation.

Tại mỗi viewport:

1920×1080
1440×1000
1366×768
1024×768
820×1180
768×1024
744×1133
430×932
393×852
390×844
375×812

Thu:

bounding box
computed display
position
overflow
width
height
font-size
line-height
color
background
border
z-index
visibility
opacity.

Với những property quan trọng:
xác định stylesheet/rule nào cung cấp giá trị cuối.

Phải phát hiện:

overlap
clipping
horizontal overflow
nested scrolling
hidden content
viewport escape
button collision
fixed element collision
text overflow
unintended wrap.

Không coi scrollWidth == clientWidth là đủ.

Phải test actual rectangle collision.

============================================================
7. DOM OWNERSHIP AUDIT
============================================================

Xác định ai tạo DOM cho từng vùng.

Lập bảng:

DOM region
initial creator
subsequent mutator
observer
rerender trigger
state dependency
presentation owner.

Đặc biệt kiểm tra:

core.js
russian.js
russian-future-ui.js
subject-adapter.js
learning-flow.js
learning-state.js
speaking-coach.js
vocab-srs.js
academic-language.js
ai-mentor-guard.js.

Phát hiện:

duplicate renderers
renderer wrapping renderer
post-render patching
DOM replacement
innerHTML regeneration
event listener duplication
MutationObserver loops
render → observer → render cycle.

Đo:

MutationObserver count
active observers by route
event listener duplication nếu có thể đo.

Nếu Future UI được gọi nhiều lần:
kiểm chứng idempotence thực tế.

============================================================
8. ROUTE & INFORMATION ARCHITECTURE AUDIT
============================================================

Lập danh sách canonical route.

Bao gồm:

overview
learning
dialogue
writing
media
vocab
grammar
mindmap
storage

và mọi deep route/subroute thực tế.

Cho mỗi route:

URL/deeplink representation
navigation source
renderer
data source
learning purpose
current visibility
legacy compatibility
mobile behavior
browser back behavior
reload behavior.

Test:

direct entry
reload
back
forward
deep link
Hub → Russian
Russian → Hub
standalone Russian.

Phát hiện:

route alias
duplicate route
route whose content is hidden but runtime still active
route whose nav disappeared but deeplink remains.

Không xóa route ở P1.

============================================================
9. LEARNING STATE FORENSIC AUDIT
============================================================

Xác định canonical state model.

Inventory tất cả:

localStorage keys
sessionStorage keys
IndexedDB databases
Cache Storage
service worker state
in-memory state.

Tạo:

RUSSIAN_STORAGE_STATE_MAP.md

Cho từng key:

name
owner
schema
writer
reader
migration
criticality
reset behavior
corruption behavior.

Đặc biệt xác minh:

progress
mastery
lesson completion
review queue
SRS
speaking
handwriting
assessment
learner identity
route receipt
planning bridge.

Phải trả lời:

Presentation code có thay mastery không?

Có nơi nào:
open lesson → progress tăng?
click → mastery tăng?
render → state mutate?
UI rerender → storage write?

Nếu có:
ghi Critical Finding.

Không sửa.

============================================================
10. LEARNING ENGINE OWNERSHIP
============================================================

Lập ownership matrix:

Capability | Canonical engine | Alternative/duplicate engine | State store | Evidence

Bao gồm:

Lesson state
Progress
Mastery
Learning flow
SRS
Vocabulary review
Speaking
Speech recognition
Handwriting
Glyph authority
Listen+Write
Assessment
Review/remediation
Stage progression
AI Mentor
Academic language
Planning integration.

Mục tiêu:
phát hiện duplicate responsibility.

Flag:

ONE OWNER
MULTIPLE OWNER
UNCLEAR OWNER.

MULTIPLE/UNCLEAR phải được phân tích root cause.

============================================================
11. DATA ARCHITECTURE AUDIT
============================================================

Inventory tất cả data:

curriculum
lessons
grammar
grammar-path
vocab
speaking
dialogue-bauman-az
deep-speaking-bauman
speaking-link-index
writing
handwriting
tests
exercises
videos
mindmap
knowledge-index
simulations.

Cho mỗi dataset:

file
size
record count
required/optional
startup loaded?
lazy loaded?
loader
consumer
schema
validation
provenance
duplicate source?
external mirror?
memory impact.

Đặc biệt kiểm tra:

8000 vocab
4164 dialogue
1140 deep-speaking
1220 speaking.

Không được load tất cả vào startup nếu không cần.

Đo bằng browser/network evidence.

Phân biệt:

source data
generated data
derived index
cache
external backup.

============================================================
12. CONTENT QUALITY / LESSON STANDARD AUDIT
============================================================

Lấy mẫu lesson đại diện:

beginner
listening
speaking
vocab
grammar
writing
technical Russian.

So với:

BAUMAN_WEB_LESSON_STANDARD_V1.

Đánh giá mỗi lesson theo rhythm:

orient
observe
example
interact
retrieve
apply
reflect
review.

Không yêu cầu mọi lesson phải có đủ 8 bước nếu không phù hợp,
nhưng phải chỉ ra missing pedagogical function.

Đánh giá:

representation channels
example quality
retrieval
production
feedback
provenance
accessibility.

Tạo:

RUSSIAN_CONTENT_STANDARD_GAP_REPORT.md

Không rewrite content trong P1.

============================================================
13. LISTENING / SPEAKING FORENSIC AUDIT
============================================================

Xác minh đúng separation:

speaking.json
= basic listening/speaking

dialogue-bauman-az.json
= advanced dialogue

deep-speaking-bauman.json
= deep/pressure production

speaking-link-index.json
= bridge/index.

Phân tích:

UI entry
loader
runtime
state
audio
recording
speech recognition
fallback
scoring
progress evidence.

Đặc biệt tìm:

fake score
browser-dependent silent failure
duplicate speech engine
dataset cross-contamination
basic path accidentally loading deep data.

============================================================
14. VOCAB + SRS FORENSIC AUDIT
============================================================

Xác định:

Canonical SRS engine
SRS state
review queue
scheduling algorithm
vocab loader
search mechanism
DOM virtualization/pagination nếu có.

Test với dataset lớn.

Đo:

time to open Vocabulary
records parsed
DOM nodes
memory footprint
search latency
route-return latency.

Phát hiện:
8000 cards rendered?
full file parsed at startup?
duplicate vocab state?
review state written by UI?

============================================================
15. HANDWRITING / LISTEN+WRITE AUDIT
============================================================

Audit:

glyph authority
recognition
stroke model
Listen+Write
pronunciation support
progress integration.

Xác định:
recognition deterministic hay heuristic?
source glyph authority ở đâu?
presentation có can thiệp recognition không?

Test:
mouse
touch
iPad-style viewport.

Không làm lại recognition engine.

============================================================
16. ASSESSMENT / MASTERY FORENSIC AUDIT
============================================================

Trace toàn bộ:

question generation
question source
attempt
answer
submit
feedback
score
review
remediation
mastery.

Phải chứng minh:

first attempt preserved?
answer reveal timing?
exam vs practice khác nhau?
wrong answers map về concept?
remediation tồn tại?
mastery update ở đâu?

Flag Critical nếu:

presentation writes score
answer visible before submit
single click creates mastery
retry overwrites first attempt.

============================================================
17. AI MENTOR AUDIT
============================================================

Xác định:

entry point
context builder
read permissions
write permissions
state influence
canonical content boundary.

Kiểm tra AI có thể:

write mastery?
write score?
mutate canonical content?
invent source?
overwrite learner state?

AI Mentor phải được audit như assistant,
không phải authoritative engine.

============================================================
18. OFFLINE / PWA / PACKAGE AUDIT
============================================================

Audit:

manifest
service worker
cache strategy
offline shell
data cache
large dataset behavior
version update
cache invalidation.

Test:

first online visit
reload
offline reload
route offline
lesson offline
vocab offline
speaking offline fallback.

Xác định package path:

direct source
preview package
production package.

Kiểm tra packaged Russian có khác direct runtime không.

============================================================
19. HUB / PLANNING BRIDGE INTEGRATION
============================================================

Audit toàn bộ protocol:

incoming
outgoing
today mission
schedule
route receipt
subject ready
manifest exchange.

Phải xác định:

Main Hub owns what?
Russian owns what?

Không để Main Hub điều khiển internal learning engine vượt contract.

Test:

Hub → Russian lesson
Russian completion → Hub
reload
standalone fallback.

============================================================
20. PERFORMANCE BASELINE
============================================================

Thu baseline trước refactor.

Desktop + iPhone.

Đo:

HTML bytes
CSS bytes
JS bytes
startup JSON
lazy JSON
request count
DOMContentLoaded
load
time to first usable interaction
route switch time
Vocabulary open
Dialogue open
memory
DOM node count.

Không đặt target tùy tiện.
P1 chỉ baseline.

Output:

RUSSIAN_P1_PERFORMANCE_BASELINE.json
RUSSIAN_P1_PERFORMANCE_BASELINE.md

============================================================
21. ACCESSIBILITY BASELINE
============================================================

Audit:

semantic headings
landmarks
button semantics
labels
focus
keyboard
tab order
dialog focus trap
Esc
screen-reader labels
alt
audio transcript
color-only signal
reduced motion
touch target
font scaling.

Không chỉ chạy automated axe-like checks.

Manual keyboard path tối thiểu:

open app
navigate
open lesson
play audio
answer exercise
close modal.

============================================================
22. SECURITY / DATA SAFETY AUDIT
============================================================

Kiểm tra:

JSON import
HTML injection
innerHTML
URL handling
external media
localStorage parsing
IndexedDB parsing
file import
dangerous eval
Function constructor
unsafe script injection.

Phải ưu tiên data loss risk.

Test malformed localStorage.

Không được silently reset learner history.

Document recovery behavior.

============================================================
23. TEST SUITE FORENSIC AUDIT
============================================================

Inventory mọi Russian test.

Cho mỗi test:

file
type
scope
what it proves
what it does NOT prove
runtime or static
direct or packaged
viewport
route coverage
false-confidence risk.

Tạo:

RUSSIAN_TEST_COVERAGE_MATRIX.md

Đặc biệt phát hiện:

static string assertion pretending runtime behavior
tests that assert removed UI
tests that only check file existence
tests that miss screenshot defects
tests that don't load actual package.

Phân loại:

TRUSTED
USEFUL
WEAK
STALE
MISLEADING.

Không xóa test trong P1.

============================================================
24. VISUAL FORENSIC AUDIT
============================================================

Chụp screenshot canonical của các route quan trọng.

Mỗi viewport.

Không chỉ screenshot Home.

Tối thiểu:

Home
Lesson
Listening/Speaking
Vocabulary
Grammar
Writing
Dialogue
Assessment.

Đánh giá theo:

Visual hierarchy
Reading hierarchy
Density
Whitespace
Contrast
Navigation
CTA clarity
Surface separation
Professionalism
Consistency
Mobile usability.

Tạo scorecard nhưng KHÔNG dùng score để che qualitative issue.

Mỗi finding phải có:

severity
viewport
route
component
evidence
root cause hypothesis.

============================================================
25. ROOT CAUSE TREE
============================================================

Tất cả finding phải được gom thành root cause.

Không lập danh sách 100 bug rời rạc.

Ví dụ:

SYMPTOM:
Mobile layout chồng lấn.

Không dừng ở:
padding sai.

Trace:

fixed height
→ old core rule
→ overridden by future UI
→ nested scroll owner
→ mobile breakpoint conflict
→ ownership ambiguity.

Tạo:

RUSSIAN_ROOT_CAUSE_TREE.md

Root causes phải được nhóm:

Architecture
CSS
Rendering
State
Data
Learning
Routing
Offline
Testing
Accessibility
Performance.

============================================================
26. KEEP / REFACTOR / MERGE / DELETE-LATER
============================================================

Sau khi có đủ evidence,
lập bảng cuối:

Component/File/System

KEEP
REFACTOR
MERGE
DELETE_LATER
DO_NOT_TOUCH
UNKNOWN.

DELETE_LATER không có nghĩa là xóa trong P1.

Mỗi DELETE_LATER phải có:

replacement
dependents
migration
test coverage
rollback.

Nếu thiếu một mục:
không được đánh DELETE_LATER.

============================================================
27. CURRENT ARCHITECTURE DIAGRAM
============================================================

Tạo architecture diagram mô tả đúng runtime hiện tại.

Không vẽ architecture mong muốn.

Phải có:

Browser
HTML bootstrap
Presentation
Routing
Learning engines
State
Data
Offline
Hub bridge
AI
Assessment.

Dùng Mermaid nếu phù hợp.

Output:

RUSSIAN_CURRENT_ARCHITECTURE.md

============================================================
28. TARGET BOUNDARY HYPOTHESIS
============================================================

P1 chưa thiết kế P2 đầy đủ.

Nhưng phải ghi lại boundary hypothesis:

What should become Foundation
What should become Domain
What should remain Learning Engine
What should become Presentation
What should become adapters.

Không implementation.

Tạo:

RUSSIAN_P2_INPUT_BOUNDARY_HYPOTHESIS.md

Đây sẽ là input chính thức cho Prompt 2.

============================================================
29. RISK REGISTER
============================================================

Tạo:

RUSSIAN_P1_RISK_REGISTER.json
RUSSIAN_P1_RISK_REGISTER.md

Risk fields:

id
title
severity
probability
impact
affectedLayer
evidence
mitigation
mustFixBefore
ownerCandidate.

Severity:

BLOCKER
CRITICAL
HIGH
MEDIUM
LOW.

Ví dụ blocker:

learner data loss
mastery corruption
route break
offline data reset.

============================================================
30. PRIORITY MATRIX
============================================================

Không ưu tiên dựa vào độ dễ sửa.

Dùng:

Impact on learning
Architectural leverage
User pain
Regression risk
Dependency order.

Tạo P2–P16 dependency map.

Không implementation.

============================================================
31. REQUIRED DELIVERABLES
============================================================

P1 chỉ được COMPLETE nếu có:

subjects/russian/docs/p1/RUSSIAN_P1_EXECUTIVE_SUMMARY.md

subjects/russian/docs/p1/RUSSIAN_FILE_INVENTORY.json

subjects/russian/docs/p1/RUSSIAN_RUNTIME_LOAD_ORDER.md

subjects/russian/docs/p1/RUSSIAN_CSS_FORENSIC.json

subjects/russian/docs/p1/RUSSIAN_CSS_OWNERSHIP_MAP.md

subjects/russian/docs/p1/RUSSIAN_DOM_OWNERSHIP_MAP.md

subjects/russian/docs/p1/RUSSIAN_ROUTE_MAP.md

subjects/russian/docs/p1/RUSSIAN_STORAGE_STATE_MAP.md

subjects/russian/docs/p1/RUSSIAN_ENGINE_OWNERSHIP_MATRIX.md

subjects/russian/docs/p1/RUSSIAN_DATA_ARCHITECTURE.md

subjects/russian/docs/p1/RUSSIAN_CONTENT_STANDARD_GAP_REPORT.md

subjects/russian/docs/p1/RUSSIAN_TEST_COVERAGE_MATRIX.md

subjects/russian/docs/p1/RUSSIAN_P1_PERFORMANCE_BASELINE.json

subjects/russian/docs/p1/RUSSIAN_P1_PERFORMANCE_BASELINE.md

subjects/russian/docs/p1/RUSSIAN_ACCESSIBILITY_BASELINE.md

subjects/russian/docs/p1/RUSSIAN_SECURITY_DATA_SAFETY_AUDIT.md

subjects/russian/docs/p1/RUSSIAN_ROOT_CAUSE_TREE.md

subjects/russian/docs/p1/RUSSIAN_KEEP_REFACTOR_MATRIX.md

subjects/russian/docs/p1/RUSSIAN_CURRENT_ARCHITECTURE.md

subjects/russian/docs/p1/RUSSIAN_P2_INPUT_BOUNDARY_HYPOTHESIS.md

subjects/russian/docs/p1/RUSSIAN_P1_RISK_REGISTER.json

subjects/russian/docs/p1/RUSSIAN_P1_RISK_REGISTER.md

subjects/russian/docs/p1/RUSSIAN_P1_EVIDENCE_INDEX.md

============================================================
32. EVIDENCE INDEX
============================================================

Mọi kết luận quan trọng phải trỏ về evidence.

Evidence có thể là:

file + line/range
runtime measurement
browser screenshot
computed style
network trace
storage inspection
test output.

Không dùng:

“looks like”
“probably”
“seems unused”

cho kết luận kiến trúc.

Nếu chưa chứng minh:
ghi UNKNOWN / NEEDS P2 VALIDATION.

============================================================
33. AUDIT QUALITY GATE
============================================================

P1 FAIL nếu:

- chỉ đọc docs mà không chạy runtime;
- chỉ scan code mà không mở browser;
- chỉ test desktop;
- không audit state;
- không audit data loading;
- không audit mastery ownership;
- không audit CSS cascade;
- kết luận dead code chỉ vì search không thấy;
- đề xuất xóa core.css hàng loạt;
- redesign trong quá trình audit;
- sửa UI để screenshot đẹp;
- đánh PASS chỉ vì CI xanh.

P1 PASS khi:

1. Runtime hiện tại đã được map.
2. Presentation ownership rõ.
3. Learning ownership rõ.
4. Data ownership rõ.
5. State ownership rõ.
6. Route ownership rõ.
7. Major CSS conflicts có evidence.
8. Major UX failures có root cause.
9. Test blind spots rõ.
10. P2 có đủ dữ liệu để thiết kế architecture mới.

============================================================
34. PR / MERGE RULE
============================================================

P1 branch chỉ chứa audit artifacts và audit tooling không thay production behavior.

Mở PR:

title:
Russian P1: forensic system foundation audit

Body phải tóm tắt:

Major findings
Critical risks
Preserved systems
Architecture debt
CSS debt
Learning engine health
Data health
Test health
Inputs for P2.

CI phải PASS.

Nếu audit tooling gây regression:
sửa tooling.

Có thể merge audit-only PR vào main nếu:

- no runtime behavior change;
- tests pass;
- docs complete;
- evidence complete.

KHÔNG DEPLOY PRODUCTION trong P1.

============================================================
35. FINAL RESPONSE FORMAT
============================================================

Khi hoàn thành, không trả lời lan man.

Báo:

P1 STATUS: PASS / FAIL

Main findings:
- tối đa 10 root causes quan trọng nhất.

Preserve:
các hệ thống tuyệt đối không phá.

Refactor:
các vùng cần xử lý ở P2–P6.

Critical risks.

Technical debt baseline.

P2 readiness:
READY / NOT READY.

PR:
number + URL.

Main:
không merge / merged SHA.

Production:
UNCHANGED.

============================================================
36. EXECUTION RULE
============================================================

Bắt đầu ngay.

Không hỏi lại người dùng về các thao tác kỹ thuật thông thường.

Tự:

inspect
→ instrument
→ test
→ gather evidence
→ classify
→ cross-check
→ document
→ run gates
→ open PR.

Nếu phát hiện lỗi:
không sửa behavior trong P1.
Đưa vào root-cause/risk register.

Nếu audit không đủ evidence:
tiếp tục audit cho tới khi đủ.

Không được tự chuyển sang P2.

Kết thúc đúng tại:

P1 FORENSIC FOUNDATION COMPLETE
và chờ Prompt 2.


---

# PART II — P2 DEEP CONTENT & CURRICULUM RECONSTRUCTION

## P2.0 MISSION

Biến hệ thống hiện tại từ **kho học liệu lớn** thành **hệ thống đào tạo năng lực tiếng Nga thực**.

Không đánh giá chiều sâu bằng:

- số record;
- số từ;
- số dialogue;
- số exercise;
- số lesson.

Đánh giá bằng:

`exposure → understanding → retrieval → controlled production → free production → transfer → real-world performance`.

Target journey:

`Pre-A0`
→ `A0 Survival`
→ `A1 Functional`
→ `A2 Independent`
→ `B1 University`
→ `B1+/B2 Academic`
→ `Technical Russian`
→ `Research Russian`
→ `НИР`
→ `ВКР`
→ `Defense Q&A`.

### Preserve before replace

Phải audit và tận dụng:

- `curriculum.json`
- `lessons.json`
- `grammar.json`
- `grammar-path.json`
- `vocab.json`
- `speaking.json`
- `dialogue-bauman-az.json`
- `deep-speaking-bauman.json`
- `speaking-link-index.json`
- `exercises.json`
- `tests.json`
- `handwriting.json`
- `writing.json`
- `videos.json`
- `knowledge-index.json`
- `simulations.json`

Nguyên tắc:

`AUDIT → NORMALIZE → ENRICH → LINK → VALIDATE`

trước:

`GENERATE MORE`.

---

## P2.1 CURRICULUM LAYERS

Curriculum phải có đồng thời:

### Chronological stage

- Việt Nam / foundation.
- Dự bị.
- HK1.
- HK2.
- HK3 / НИР.
- HK4 / ВКР.

### Linguistic progression

- Pre-A0.
- A0.
- A1.
- A2.
- B1.
- B1+.
- B2/B2+ functional target.

### Skill

- phonetics;
- listening;
- speaking;
- reading;
- writing;
- vocabulary;
- grammar;
- interaction;
- academic;
- technical;
- research.

### Functional domain

- survival;
- dorm;
- transport;
- administration;
- classroom;
- university;
- mathematics;
- CS;
- database;
- AI/ML;
- control/automation;
- statistics;
- research;
- НИР;
- ВКР.

Không collapse toàn bộ learner thành một level duy nhất.

---

## P2.2 PHONETICS SYSTEM

Progression tối thiểu:

1. Cyrillic recognition.
2. Sound-letter mapping.
3. Hard/soft consonants.
4. Voiced/unvoiced.
5. Final devoicing.
6. Assimilation.
7. Word stress.
8. Unstressed vowel reduction.
9. Difficult consonants.
10. Consonant clusters.
11. Phrase stress.
12. Intonation.
13. Connected speech.
14. Lecture-speed recognition.

### Vietnamese learner error corpus

Đặc biệt audit:

- ы / и;
- ш / щ;
- ж / з;
- ц / ч;
- х;
- р;
- hard/soft consonants;
- stress;
- unstressed о;
- devoicing;
- consonant clusters;
- Vietnamese tonal interference.

Pronunciation loop:

`HEAR → DISTINGUISH → REPEAT → RECORD → COMPARE → WORD → SENTENCE → DIALOGUE`.

---

## P2.3 VOCABULARY AS A LEXICAL NETWORK

8.000 từ không được coi là 8.000 đơn vị mastered.

Các lexical item quan trọng cần, khi phù hợp:

- lemma;
- stress;
- POS;
- gender;
- animacy;
- plural;
- irregular forms;
- aspect;
- aspect pair;
- government;
- case pattern;
- senses;
- Vietnamese meaning;
- simplified Russian meaning;
- domain;
- level;
- frequency band;
- collocations;
- word family;
- synonyms;
- antonyms;
- confusables;
- basic example;
- academic example;
- technical example;
- lesson links;
- speaking links;
- dialogue links;
- review tags;
- provenance.

Không fabricate field chưa xác minh.

### Lexical depth

- L0 Seen.
- L1 Recognized.
- L2 Meaning recalled.
- L3 Form recalled.
- L4 Used in phrase.
- L5 Used in sentence.
- L6 Used in conversation.
- L7 Used in academic/technical context.

### Chunk-first examples

- `обратить внимание на + В.п.`
- `зависеть от + Р.п.`
- `принимать решение`
- `проводить исследование`
- `получить результат`
- `сделать вывод`
- `обрабатывать данные`

Học `WORD + GOVERNMENT + COLLOCATION`, không chỉ word translation.

---

## P2.4 GRAMMAR DEPTH

Phải có dependency graph cho:

- gender;
- number;
- agreement;
- pronouns;
- present/past/future;
- reflexive verbs;
- imperative;
- six cases;
- preposition + case government;
- numerals;
- quantity;
- modal language;
- impersonal constructions;
- negation;
- aspect;
- verbs of motion;
- prefixed motion verbs;
- comparison;
- complex clauses;
- condition;
- cause;
- result;
- purpose;
- concession;
- participles khi phù hợp;
- passive;
- word order;
- information structure;
- academic nominalisation.

### Case system: function first

Nominative:
- naming;
- subject.

Genitive:
- possession;
- absence;
- quantity;
- origin/relation.

Dative:
- recipient;
- experiencer;
- age;
- need/state.

Accusative:
- direct object;
- destination.

Instrumental:
- instrument;
- role;
- accompaniment;
- predicate complement.

Prepositional:
- location;
- topic.

Loop:

`MEANING → FORM → PREPOSITION/GOVERNMENT → AGREEMENT → CONTRAST → LISTENING → TRANSFORMATION → SPEAKING → FREE PRODUCTION`.

### Aspect system

Không chỉ pair list.

Dạy:

- process;
- repetition;
- general fact;
- completion;
- result;
- single event;
- sequence;
- attempted/interrupted action.

Learner phải hiểu semantic difference, ví dụ:

`Я писал отчёт.`

vs

`Я написал отчёт.`

### Motion verbs

Progression:

`идти / ходить`
`ехать / ездить`

sau đó mở rộng hợp lý sang:

- нести / носить;
- вести / водить;
- везти / возить;

và prefixes:

- при-
- у-
- в-
- вы-
- под-
- от-
- пере-
- про-
- до-
- за-

---

## P2.5 LISTENING ARCHITECTURE

Difficulty ladder:

- L0 phoneme.
- L1 isolated word.
- L2 controlled sentence.
- L3 slow dialogue.
- L4 normal conversation.
- L5 public announcement.
- L6 classroom instruction.
- L7 technical explanation.
- L8 lecture.
- L9 seminar.
- L10 defense Q&A.

Task types:

- gist;
- detail;
- keyword;
- sequence;
- intent;
- role;
- number/date;
- instruction following;
- dictation;
- cloze;
- note taking;
- summary;
- technical extraction.

Không dùng một tốc độ TTS cho toàn course.

---

## P2.6 SPEAKING ARCHITECTURE

Progression:

`LISTEN`
→ `REPEAT`
→ `SHADOW`
→ `COMPLETE`
→ `SUBSTITUTE`
→ `ANSWER`
→ `ROLE PLAY`
→ `REFORMULATE`
→ `PARAPHRASE`
→ `MONOLOGUE`
→ `TECHNICAL EXPLANATION`
→ `PRESSURE Q&A`.

Giữ separation:

- `speaking.json` = basic listening/speaking.
- `dialogue-bauman-az.json` = contextual dialogue.
- `deep-speaking-bauman.json` = advanced productive speaking.
- `speaking-link-index.json` = bridge/index.

Speech recognition chỉ là signal, không phải mastery authority.

---

## P2.7 READING & WRITING

### Reading ladder

sign
→ form
→ message
→ timetable
→ notice
→ email
→ article
→ textbook
→ technical instruction
→ documentation
→ abstract
→ paper fragment
→ research material.

Reading tasks không chỉ dịch:

- locate;
- infer;
- classify;
- summarize;
- extract;
- outline;
- compare;
- explain;
- reconstruct.

### Writing ladder

handwriting
→ word
→ sentence
→ message
→ form
→ email
→ paragraph
→ summary
→ lab note
→ technical explanation
→ report
→ abstract
→ НИР fragment
→ ВКР fragment.

Handwriting ≠ written production.

---

## P2.8 ACADEMIC RUSSIAN

Academic functions:

- DEFINE;
- CLASSIFY;
- DESCRIBE;
- COMPARE;
- CONTRAST;
- EXPLAIN;
- JUSTIFY;
- CAUSE;
- EFFECT;
- EVIDENCE;
- EXAMPLE;
- ASSUMPTION;
- METHOD;
- RESULT;
- INTERPRETATION;
- LIMITATION;
- CONCLUSION;
- COUNTERARGUMENT.

Learner phải biến đổi mẫu chứ không copy phrasebook.

---

## P2.9 TECHNICAL RUSSIAN

Domains tối thiểu:

### Mathematics
- equation;
- variable;
- function;
- derivative;
- integral;
- vector;
- matrix;
- probability;
- optimization.

### Computer Science
- algorithm;
- data structure;
- complexity;
- process;
- memory;
- OS;
- network;
- database;
- query;
- API.

### AI / ML
- dataset;
- feature;
- model;
- training;
- validation;
- loss;
- accuracy;
- inference;
- neural network.

### Control / Automation
- control object;
- feedback;
- controller;
- PID;
- signal;
- sensor;
- actuator;
- stability;
- transfer function;
- state.

### Statistics
- sample;
- population;
- distribution;
- mean;
- variance;
- hypothesis;
- confidence.

Technical concept cần link tới:

term
→ stress
→ morphology
→ collocation
→ government
→ definition
→ simple explanation
→ technical example
→ lecturer-style sentence
→ oral response
→ written response.

---

## P2.10 RESEARCH / НИР / ВКР

Learner phải làm được:

1. nêu topic;
2. nêu problem;
3. relevance;
4. objective;
5. research tasks;
6. method;
7. data;
8. model/algorithm;
9. experiment;
10. results;
11. figure/table description;
12. limitations;
13. contribution;
14. conclusion;
15. answer questions;
16. defend choice;
17. acknowledge uncertainty;
18. propose future work.

---

# PART III — R01–R26 MASTER CURRICULUM MAP

## P2.11 ID MODEL

- R01–R26 = macro modules.
- Units = `Rxx-Uxx`.
- Micro-lessons = `Rxx-Uxx-Mxx`.

Không version trong identity.

---

## P2.12 R01–R06 FOUNDATION

### R01 — Cyrillic · Sound · Stress
Units:
- alphabet decoding;
- print/handwriting recognition;
- sound map;
- hard/soft;
- voiced/unvoiced;
- stress;
- vowel reduction;
- rhythm.

Exit:
đọc chậm từ mới + nhại audio.

### R02 — First Russian Sentences
Units:
- Это...
- Я...
- Кто?/Что?
- Где?
- Мне нужно...
- Можно...?
- repair language;
- politeness / вы.

Exit:
giới thiệu + xin nhắc lại + hỏi thông tin.

### R03 — Numbers · Time · Date · Money
Units:
- numbers;
- phone;
- money;
- clock;
- dates;
- years;
- room/floor;
- measurements.

Exit:
xử lý số/thời gian/giá/phòng trong hội thoại.

### R04 — Navigation · Transport
Units:
- directions;
- metro;
- bus/tram;
- taxi;
- где/куда;
- идти/ехать;
- announcements;
- wrong direction/problem.

Exit:
đi từ điểm A đến ký túc xá/campus.

### R05 — Daily Life
Units:
- food;
- cafeteria;
- supermarket;
- dorm;
- SIM;
- bank;
- pharmacy;
- basic medical;
- everyday problems.

### R06 — Documents · Administration
Units:
- passport;
- visa;
- migration;
- registration;
- forms;
- international office;
- missing document;
- emergency;
- integrated survival simulation.

Foundation gate:
airport → transport → dorm → administration → daily life.

---

## P2.13 R07–R10 PREPARATORY RUSSIAN

### R07 — Classroom Russian
- objects;
- commands;
- read/write/listen;
- ask question;
- repeat/slow;
- homework;
- deadlines;
- correctness language.

### R08 — Cases for Real University Life
- nominative;
- prepositional;
- accusative;
- genitive;
- dative;
- instrumental;
- contrasts;
- adjective agreement;
- pronouns.

### R09 — Verbs · Time · Aspect · Motion
- present;
- past;
- future;
- aspect;
- process/result;
- repetition/completion;
- идти/ходить;
- ехать/ездить;
- motion prefixes.

### R10 — Preparatory Academic Bridge
- math foundation;
- CS foundation;
- task statements;
- explanation steps;
- definitions;
- short writing;
- teacher explanation;
- note taking;
- prep assessment.

Prep gate:
nghe instruction + đọc task + hỏi clarification + giải thích cách làm.

---

## P2.14 R11–R14 BAUMAN HK1

### R11 — University Academic Operations
- syllabus;
- schedule;
- assignment;
- requirements;
- deadline;
- lecturer communication;
- email;
- group work;
- progress update.

### R12 — Mathematical & Formal Russian
- equation;
- variable;
- function;
- vectors;
- matrices;
- probability;
- derivative/integral;
- conditions;
- formula reading.

### R13 — Technical Problem Solving
- problem;
- input;
- output;
- requirement;
- procedure;
- error;
- solution;
- compare;
- justify.

### R14 — Lecture Survival & Note-Taking
- markers;
- definitions;
- examples;
- attention;
- enumeration;
- cause/result;
- notes;
- reconstruction;
- post-lecture clarification;
- mini technical presentation.

HK1 gate:
mini lecture → notes → 1–2 minute reconstruction.

---

## P2.15 R15–R18 BAUMAN HK2

### R15 — Computer Science / Software Russian
- algorithms;
- data structures;
- variables/types;
- functions;
- class/object;
- process/thread;
- memory/files;
- network/API;
- debugging.

### R16 — Database · Data · AI
- database;
- table;
- record;
- key;
- relation;
- query;
- dataset;
- feature;
- model;
- training;
- validation;
- evaluation.

### R17 — Control · Automation · Systems
- system;
- input/output;
- signal;
- sensor;
- actuator;
- feedback;
- controller;
- PID;
- stability;
- state/model.

### R18 — Experiment · Data · Report
- objective;
- setup;
- procedure;
- measurement;
- data;
- graph;
- trend;
- error;
- expected vs actual;
- result;
- conclusion.

HK2 gate:
technical mini-report.

---

## P2.16 R19–R22 HK3 / НИР

### R19 — Research Language Foundation
- topic;
- problem;
- relevance;
- objective;
- research tasks;
- research question;
- hypothesis.

### R20 — Literature · Methods · Evidence
- abstract;
- contribution;
- compare papers;
- sources;
- method;
- dataset;
- experimental design;
- evidence;
- limitations.

### R21 — Seminar · Argumentation · Critique
- position;
- reason;
- evidence;
- agree/disagree;
- clarification;
- challenge;
- counterargument;
- defend;
- admit limitation.

### R22 — НИР Production
- structure;
- introduction;
- objectives/tasks;
- method;
- data;
- experiment;
- result;
- discussion;
- limitation;
- conclusion;
- oral report;
- Q&A.

HK3 gate:
3–5 minute НИР presentation + unscripted Q&A.

---

## P2.17 R23–R26 HK4 / ВКР

### R23 — ВКР Academic Writing
- structure;
- introduction;
- problem;
- methodology;
- system/model;
- experiment;
- results;
- discussion;
- limitations;
- conclusion;
- abstract.

### R24 — Figures · Tables · Slides
- tables;
- graphs;
- trends;
- maxima/minima;
- comparison;
- architecture diagram;
- algorithm diagram;
- slide transitions;
- presentation signposting.

### R25 — Defense Q&A
- direct answers;
- clarify question;
- ask repetition;
- justify method;
- explain choice;
- limitation;
- criticism;
- unknown answer;
- insufficient data;
- future work;
- unexpected questions.

### R26 — Final Bauman Russian Capstone
- survival regression;
- classroom regression;
- technical reading;
- lecture listening;
- technical explanation;
- academic writing;
- research presentation;
- defense;
- unexpected Q&A;
- remediation;
- reassessment.

Final capstone:
new technical scenario → read → listen → note → explain → present → defend.

---

## P2.18 SPIRAL CURRICULUM

Phonetics không kết thúc ở R01.

Grammar không kết thúc ở R08.

Speaking tăng:

sentence
→ dialogue
→ explanation
→ presentation
→ research
→ defense.

Listening tăng:

sound
→ sentence
→ announcement
→ classroom
→ technical explanation
→ lecture
→ seminar
→ defense.

Writing tăng:

letters
→ sentences
→ forms
→ emails
→ notes
→ reports
→ НИР
→ ВКР.

---

# PART IV — P3 CONTENT SCHEMA CONSTITUTION

## P3.0 GOLDEN RULE

> **ONE FACT · ONE OWNER · MANY USES**

Không copy cùng linguistic fact vào nhiều source.

---

## P3.1 CANONICAL ENTITY TYPES

Canonical:

1. Stage
2. Macro Module
3. Unit
4. Micro-Lesson
5. Competency
6. Linguistic Function
7. Phonetic Concept
8. Grammar Concept
9. Lexical Entry
10. Phrase/Collocation
11. Listening Item
12. Speaking Item
13. Dialogue Scenario
14. Deep Speaking Task
15. Reading Text
16. Writing Task
17. Technical Concept
18. Academic Function
19. Exercise
20. Assessment Item
21. Performance Task
22. Error Pattern
23. Remediation Path
24. Media Asset
25. Provenance Record

Derived only:

- search indexes;
- knowledge index when used as index;
- speaking-link-index;
- review queues;
- recommendation caches;
- route manifests;
- dashboard aggregations.

Derived data must be regenerable.

---

## P3.2 ID CONSTITUTION

IDs:

- stable;
- machine-readable;
- no version;
- no UI dependency;
- no date unless identity truly depends on date;
- immutable once learner state references them.

Possible namespaces:

- `MOD-`
- `UNIT-`
- `ML-`
- `COMP-`
- `PHON-`
- `GRAM-`
- `LEX-`
- `PHRASE-`
- `LST-`
- `SPK-`
- `DLG-`
- `DSP-`
- `READ-`
- `WRITE-`
- `TECH-`
- `ACAD-`
- `EX-`
- `ASM-`
- `PERF-`
- `ERR-`
- `REM-`
- `MEDIA-`.

Renaming title must not change ID.

---

## P3.3 SCHEMA VERSIONING

Separate:

`schemaVersion`

from:

`contentRevision`.

Do not expose technical version in learner UI.

---

## P3.4 CURRICULUM SCHEMAS

### Stage

Fields conceptually include:

- id;
- title;
- sequence;
- goals;
- entry competencies;
- exit competencies;
- module IDs;
- performance gate.

### Macro Module

- id;
- legacy ID;
- stage ID;
- target levels;
- purpose;
- competencies;
- prerequisites;
- units;
- diagnostics;
- exit performance tasks;
- review concepts.

### Unit

- id;
- module;
- title;
- purpose;
- objectives;
- prerequisites;
- competencies;
- grammar IDs;
- lexical IDs;
- phrase IDs;
- phonetic IDs;
- function IDs;
- micro-lessons;
- performance tasks;
- remediation.

### Micro-Lesson

- id;
- unit;
- title;
- objective;
- estimated minutes;
- prerequisites;
- input refs;
- examples;
- activities;
- retrieval;
- production;
- assessment;
- remediation;
- mastery evidence.

Không embed full canonical objects vào lesson.

---

## P3.5 COMPETENCY MODEL

Competency = khả năng learner thực hiện.

Skills:

- phonetics;
- listening;
- speaking;
- reading;
- writing;
- grammar-recognition;
- grammar-production;
- vocabulary-recognition;
- vocabulary-production;
- interaction;
- academic;
- technical;
- research.

`requires` dependency phải không tạo cycle.

---

## P3.6 PHONETIC MODEL

Phonetic concept có:

- id;
- level;
- description;
- contrasts;
- lexical examples;
- listening links;
- speaking links;
- error-pattern links.

Stress là first-class data.

---

## P3.7 GRAMMAR MODEL

Grammar concept phải phân biệt:

**FORM**

và:

**FUNCTION**.

Case family không đồng nghĩa learner mastered mọi use.

Government phải structured, ví dụ:

`head lexical ID + pattern + case + meaning`.

---

## P3.8 LEXICAL MODEL

Lexical entry có thể gồm:

- lemma;
- stress display;
- POS;
- level;
- frequency;
- domains;
- active/passive status;
- senses;
- morphology;
- government;
- aspect;
- collocation IDs;
- word family IDs;
- confusables;
- examples;
- lesson links;
- provenance.

Không fake morphology.

Polysemy dùng senses, không tạo duplicate lemma vô nghĩa.

---

## P3.9 LISTENING MODEL

Listening item:

- level;
- difficulty;
- audio;
- transcript;
- speaker metadata;
- concepts;
- vocabulary;
- tasks;
- reveal policy;
- provenance.

Transcript trong exam không auto-visible.

---

## P3.10 BASIC SPEAKING MODEL

Canonical owner:

`speaking.json`.

Modes:

- repeat;
- shadow;
- answer;
- roleplay.

Evaluation config mô tả signals.

Không lưu fake precision.

---

## P3.11 DIALOGUE MODEL

Canonical owner:

`dialogue-bauman-az.json`.

Dialogue contains:

- scenario;
- level;
- stage;
- roles;
- language functions;
- grammar refs;
- lexical refs;
- turns;
- variations;
- repair strategies;
- Deep Speaking links.

Variations:

- paraphrase;
- faster;
- unexpected;
- problem;
- repair;
- role reversal.

---

## P3.12 DEEP SPEAKING MODEL

Canonical owner:

`deep-speaking-bauman.json`.

Task types:

- monologue;
- explanation;
- comparison;
- problem-solution;
- technical-description;
- research-summary;
- argument;
- defense-question;
- pressure-Q&A.

Includes:

- prep time;
- target duration;
- competencies;
- concepts;
- lexical support;
- rubric;
- follow-up questions;
- remediation.

---

## P3.13 READING / WRITING / TECHNICAL / ACADEMIC

Reading text types:

- sign;
- form;
- message;
- notice;
- email;
- article;
- textbook;
- technical instruction;
- documentation;
- abstract;
- paper fragment.

Writing task:

- purpose;
- audience;
- register;
- required functions;
- recommended vocabulary;
- rubric;
- model policy;
- remediation.

Technical concept links:

lexical entities + phrases + examples + speaking/reading/assessment.

Academic function = discourse ability, not phrasebook entry.

---

## P3.14 ERROR CORPUS

Error record:

- category;
- level;
- learner profile;
- wrong example;
- correct example;
- explanation;
- Vietnamese interference reason;
- concepts;
- repair task;
- production check.

Severity should distinguish:

- communication-blocking;
- meaning-changing;
- high-frequency;
- accuracy;
- register.

---

## P3.15 EXERCISE & ASSESSMENT

Exercise:

- practice mode;
- objective IDs;
- concepts;
- prompt;
- response schema;
- feedback;
- hint policy;
- remediation.

Assessment:

- diagnostic/checkpoint/exam;
- objectives;
- competencies;
- concepts;
- skill;
- difficulty;
- scoring policy;
- reveal policy;
- first-attempt preservation.

Non-diagnostic assessment must map to taught objective/competency.

---

## P3.16 PERFORMANCE TASK & RUBRIC

Performance tasks define:

- scenario;
- competencies;
- inputs;
- deliverables;
- rubric;
- required evidence;
- remediation.

Rubric defines criteria.

Assessment engine owns scoring/persistence.

Presentation only displays.

---

## P3.17 REMEDIATION

Remediation maps:

error/concept
→ prerequisite check
→ repair activity
→ retrieval
→ new example
→ production
→ exit check.

Do not map every failure to “redo lesson”.

---

## P3.18 CONTENT GRAPH

Nodes:

canonical IDs.

Edges:

- requires;
- teaches;
- uses;
- reviews;
- tests;
- contrasts;
- extends;
- remediates;
- contains;
- belongs-to;
- derived-from.

Validator flags:

- dangling node;
- unknown relation;
- requires-cycle;
- assessment without teaching;
- lesson without competency.

---

## P3.19 SEARCH / INDEX POLICY

Search and knowledge indexes are DERIVED unless explicitly proven otherwise.

Search should resolve:

- lemma;
- stressless form;
- ё/е normalization where appropriate;
- inflected forms if supported;
- Vietnamese;
- Russian definition;
- domain;
- tags.

Search result returns canonical ID.

---

## P3.20 PROVENANCE

Source types:

- AUTHORITATIVE;
- CURATED;
- GENERATED;
- DERIVED;
- LEGACY;
- UNKNOWN.

GENERATED does not become CURATED just because JSON validates.

---

## P3.21 MIGRATION CONSTITUTION

Every significant migration needs:

- migration ID;
- from schema;
- to schema;
- affected entities;
- aliases;
- validation;
- rollback.

No silent learner-state reset.

Prefer idempotent migration.

Possible strategy:

`read old → migrate → write new`.

Running twice must not duplicate anything.

---

## P3.22 OFFLINE / PACKAGING

Possible content packs:

- core;
- foundation;
- survival;
- prep;
- university;
- technical;
- research;
- dialogue;
- deep-speaking.

Pack ≠ owner.

Large datasets lazy-load where possible.

Derived outputs generated through reproducible build pipeline.

---

## P3.23 OWNER REGISTRY

Create:

`RUSSIAN_CONTENT_OWNER_REGISTRY.json`.

At minimum explicitly resolve canonical owners for:

- vocab;
- grammar;
- basic speaking;
- dialogue;
- deep speaking;
- curriculum;
- assessment;
- media;
- derived indexes.

Do not assume ownership without P1 evidence.

---

# PART V — P4 ASSESSMENT & MASTERY CONSTITUTION

## P4.0 MISSION

Thiết lập một hệ thống đánh giá và mastery **trung thực**, bảo toàn first attempt, đo năng lực thay vì đo click, hỗ trợ SRS/remediation nhưng không để Presentation hoặc AI tự cấp mastery.

P4 là vùng có rủi ro cao.

Không thay state schema hoặc scoring persistence trước khi P1/P3 đã xác định owner.

---

## P4.1 FUNDAMENTAL SEPARATION

Bốn layer phải tách:

### Content
Xác định:
- học gì;
- objective;
- concept;
- assessment specification.

### Learning Engine
Xác định:
- progression;
- review scheduling;
- pass logic;
- remediation routing.

### Learner State
Lưu:
- attempt;
- evidence;
- score;
- mastery signal;
- review due date;
- history.

### Presentation
Chỉ:
- render;
- collect user input;
- display feedback.

Presentation KHÔNG được tự:

- tăng mastery;
- tăng progress vì mở lesson;
- đánh dấu pass chỉ vì click;
- ghi score authoritative.

---

## P4.2 COMPLETION ≠ MASTERY

Phân biệt:

`visited`

`started`

`completed`

`passed`

`mastered`

`retained`.

Ví dụ:

learner đã xem hết bài:

`completed = true`

không đồng nghĩa:

`mastered = true`.

---

## P4.3 PROGRESS MODEL

Progress có thể gồm:

- content completion;
- competency progress;
- stage progress.

Không dùng một phần trăm duy nhất để thay thế mọi thứ.

Nếu UI cần một số tổng:

nó phải là derived summary.

Không phải canonical mastery.

---

## P4.4 MASTERY VECTOR

Ưu tiên mastery theo dimensions:

- phonetics;
- listening;
- speaking;
- reading;
- writing;
- vocabulary recognition;
- vocabulary production;
- grammar recognition;
- grammar production;
- interaction;
- academic;
- technical;
- research.

Một learner có thể:

vocab recognition mạnh

nhưng:

speaking production yếu.

Hệ thống phải bảo toàn khác biệt đó.

---

## P4.5 MASTERY DEPTH

Concept mastery có thể phân cấp:

M0 — not exposed.

M1 — recognized.

M2 — recalled.

M3 — controlled production.

M4 — contextual production.

M5 — transfer.

M6 — retained after delay.

Không bắt buộc dùng đúng labels này trong storage.

Nhưng semantic distinction phải tồn tại.

---

## P4.6 EVIDENCE-FIRST MASTERY

Mastery chỉ tăng khi có evidence.

Evidence examples:

- correct retrieval;
- produced form;
- listening comprehension;
- spoken answer;
- written answer;
- performance task;
- delayed successful review.

Không tăng mastery do:

- opening route;
- scrolling;
- playing audio;
- pressing Next;
- viewing answer.

---

## P4.7 FIRST ATTEMPT IMMUTABILITY

Mọi assessment quan trọng phải bảo toàn:

- first answer;
- first timestamp;
- first score/evidence;
- attempt mode;
- assessment version/content revision if relevant.

Retry không overwrite first attempt.

History tối thiểu:

Attempt 1
Attempt 2
Attempt 3...

UI có thể hiển thị best/current score nhưng canonical history phải giữ.

---

## P4.8 ANSWER REVEAL POLICY

Practice:
có thể reveal theo policy.

Exam:
không reveal trước submit.

Listening:
transcript hidden theo task policy.

Speaking:
target text không được làm task thành reading nếu mục tiêu là spontaneous production.

---

## P4.9 DIAGNOSTIC

Diagnostic dùng để xác định entry point.

Không nên:

- punish;
- create permanent low mastery;
- lock learner unnecessarily.

Diagnostic có thể kiểm tra:

- Cyrillic;
- basic listening;
- vocabulary;
- grammar;
- speaking sample.

---

## P4.10 PRACTICE

Practice mode cho phép:

- hints;
- immediate feedback;
- explanation;
- retry;
- remediation.

Practice evidence có weight khác exam/performance nếu mastery engine dùng weighting.

Không giả định mọi evidence ngang nhau.

---

## P4.11 RETRIEVAL REVIEW

Review phải yêu cầu recall trước reveal.

Không coi rereading là retrieval.

Examples:

- word → meaning recall;
- meaning → Russian recall;
- sentence completion;
- case production;
- listening discrimination;
- short oral response.

---

## P4.12 SRS PRINCIPLES

SRS ưu tiên:

- due;
- weak;
- recently failed;
- high-value;
- prerequisite;
- current stage relevance.

Không random toàn bộ 8.000 vocab.

Không ép production mastery cho mọi passive/reference word.

---

## P4.13 ACTIVE / PASSIVE SRS

Different review policies:

### Active core
Need productive retrieval.

### Academic/Technical active
Need phrase/collocation/context production.

### Passive
Recognition may be enough.

### Reference
No compulsory SRS unless activated by learner/course.

---

## P4.14 SRS ITEM IDENTITY

SRS state phải key bằng stable canonical content/concept identity.

Không key bằng display text.

Renaming content không reset review history.

---

## P4.15 SRS CONTENT REVISION

Nếu content meaning materially changes:

review migration policy.

Không silently reuse mastery evidence cho một entity đã đổi semantic identity.

---

## P4.16 WEAKNESS DIAGNOSIS

Sai answer phải phân biệt root cause.

Ví dụ:

`Я живу в общежитие.`

có thể là:

- không hiểu static location;
- biết concept nhưng quên ending;
- không biết lexical form;
- careless execution.

Remediation không được luôn giống nhau.

---

## P4.17 REMEDIATION LOOP

`FAILURE`
→ `CLASSIFY ERROR`
→ `CHECK PREREQUISITE`
→ `EXPLAIN/CONTRAST`
→ `CONTROLLED REPAIR`
→ `RETRIEVE`
→ `NEW EXAMPLE`
→ `PRODUCE`
→ `EXIT CHECK`.

Nếu exit check fail:

route deeper prerequisite.

---

## P4.18 NO ENDLESS PUNISHMENT

Không lặp đúng một câu 20 lần.

Nếu learner fail repeatedly:

change representation;

reduce difficulty;

repair prerequisite;

use contrast;

then retry transfer.

---

## P4.19 ASSESSMENT PYRAMID

Level 1 — Recognition.

Level 2 — Recall.

Level 3 — Controlled production.

Level 4 — Contextual production.

Level 5 — Transfer.

Level 6 — Performance.

Stage mastery không được dựa chủ yếu vào Level 1.

---

## P4.20 VOCABULARY ASSESSMENT

Không chỉ:

“машина nghĩa là gì?”

Assessment ladder:

recognize

→ recall meaning

→ recall Russian form

→ collocation

→ government

→ listen in sentence

→ produce sentence

→ use in interaction.

---

## P4.21 GRAMMAR ASSESSMENT

Không chỉ multiple choice.

Include:

- choose;
- transform;
- produce ending;
- complete sentence;
- correct error;
- answer in context;
- spontaneous use.

---

## P4.22 LISTENING ASSESSMENT

Measure separately:

- gist;
- detail;
- numbers;
- instruction;
- sequence;
- lecture structure;
- note-taking;
- technical extraction.

Transcript must follow reveal policy.

---

## P4.23 SPEAKING ASSESSMENT

Dimensions:

- task completion;
- comprehensibility;
- pronunciation;
- grammar control;
- lexical appropriacy;
- fluency;
- interaction;
- repair ability.

Không collapse thành fake `97.3% pronunciation`.

---

## P4.24 SPEECH RECOGNITION LIMIT

Browser speech recognition:

signal only.

Failure cases:

- unsupported browser;
- microphone denied;
- network/provider unavailable;
- inaccurate transcript.

Must have fallback.

System must not mark learner failed solely because API failed.

---

## P4.25 ORAL EVIDENCE

Possible evidence:

- recording;
- recognized transcript;
- keyword coverage;
- rubric;
- self-check fallback;
- teacher/manual review if available.

No single signal is universally authoritative.

---

## P4.26 WRITING ASSESSMENT

Criteria:

- task completion;
- organization;
- grammar;
- vocabulary;
- cohesion;
- register;
- technical accuracy.

Research writing additionally:

- problem/objective clarity;
- method;
- results;
- interpretation;
- limitation.

---

## P4.27 PERFORMANCE TASKS

Performance tasks integrate multiple skills.

Examples:

### A0
Dorm registration dialogue.

### A2
Resolve administrative problem.

### B1
Read assignment + ask clarification.

### B2
Explain algorithm/system.

### НИР
3–5 minute research report.

### ВКР
presentation + defense Q&A.

---

## P4.28 PERFORMANCE TASK EVIDENCE

A performance task may require:

- text response;
- audio;
- selected actions;
- structured outputs;
- rubric evidence.

Do not require unavailable browser capability as the only path.

---

## P4.29 STAGE EXIT GATES

### Foundation gate
Survival simulation.

### Prep gate
Classroom + academic task.

### HK1 gate
Lecture comprehension + explanation.

### HK2 gate
Technical report.

### HK3 gate
НИР presentation + Q&A.

### HK4 gate
ВКР-style integrated defense.

---

## P4.30 GATE POLICY

A stage gate should evaluate critical competencies.

Do not simply average all scores.

Example:

A learner should not pass defense gate with:

excellent vocabulary quiz

but:

unable to answer a question orally.

Critical skill thresholds may coexist with overall score.

---

## P4.31 PASS POLICY

Pass policy must be explicit and machine-readable.

Possible components:

- required competencies;
- minimum critical evidence;
- overall evidence;
- no unresolved blocking prerequisite.

Do not choose thresholds arbitrarily without documenting rationale.

---

## P4.32 CURRENT 100 QUESTIONS / 80% RULE

If existing system uses:

`answered >= 100 && percent >= 80`

audit what this actually proves.

Do not remove blindly.

But do not treat it as sufficient mastery evidence if questions are mostly recognition.

It may remain:

an assessment gate component,

not total mastery authority.

---

## P4.33 7/14/21/28-DAY ASSESSMENTS

Nếu hệ thống hiện tại có chu kỳ:

- 7 ngày;
- 14 ngày;
- 21 ngày;
- 28 ngày;

giữ compatibility nếu evidence cho thấy đang dùng.

Nhưng định nghĩa lại vai trò rõ:

### Day 7
Early retention / repair.

### Day 14
Mid retention.

### Day 21
Transfer/weakness check.

### Day 28
Longer retention / stage consolidation.

Không chỉ lặp cùng ngân hàng câu hỏi.

---

## P4.34 SPACED ASSESSMENT COMPOSITION

Mỗi cycle nên ưu tiên:

- previously failed;
- weak competencies;
- due concepts;
- important prerequisites;
- sampled retained strengths;
- production/transfer where feasible.

Không chỉ random 40 câu.

---

## P4.35 QUESTION BANK INTEGRITY

Question bank phải track:

- objective;
- concept;
- skill;
- difficulty;
- mode;
- source/provenance;
- exposure history if needed.

Avoid duplicate questions masquerading as variety.

---

## P4.36 QUESTION GENERATION

Generated questions:

must be validated.

Do not generate authoritative answer keys from unvalidated AI output.

For technical/linguistic high-risk questions:

stronger validation.

---

## P4.37 FIRST-ATTEMPT ANALYTICS

Analytics should be able to distinguish:

first-attempt performance

vs

post-feedback performance.

Both useful.

Do not mix them silently.

---

## P4.38 CURRENT SCORE VS BEST SCORE

If UI shows:

current;

best;

first;

all must have explicit meaning.

Canonical history must not be reduced to best score only.

---

## P4.39 MASTERY DECAY / RETENTION

Do not necessarily “subtract mastery” every day.

Prefer tracking:

last evidence;
review due;
retention confidence/state.

If using decay model:

document algorithm and test it.

---

## P4.40 CONFIDENCE

Self-confidence can be stored separately.

Confidence ≠ mastery.

Useful signals:

- learner says easy;
- hard;
- guessed;
- confident.

But no direct authoritative mastery write.

---

## P4.41 AI MENTOR & ASSESSMENT

AI Mentor may:

- explain;
- coach;
- generate temporary practice;
- roleplay;
- provide feedback.

AI Mentor must NOT:

- write official score directly;
- unlock stage;
- increase mastery;
- alter canonical answer key;
- overwrite first attempt.

Any AI-assisted rubric score must be clearly identified as a signal unless validated as authoritative process.

---

## P4.42 AI FEEDBACK SAFETY

If AI uncertain:

say uncertain.

Do not fabricate pronunciation or grammar diagnosis.

Store official learner state only through canonical engine.

---

## P4.43 ERROR TAXONOMY

Errors can map to:

- phonetic;
- stress;
- morphology;
- case;
- agreement;
- aspect;
- motion;
- word order;
- preposition;
- government;
- vocabulary;
- collocation;
- listening;
- comprehension;
- register;
- technical concept;
- task misunderstanding.

---

## P4.44 MASTERY OWNERSHIP MATRIX

Create machine-readable matrix:

Capability
→ canonical engine
→ state store
→ writer
→ readers
→ evidence source
→ migration.

Flag:

- ONE OWNER
- MULTIPLE OWNER
- UNCLEAR OWNER.

Do not proceed with schema rewrite if mastery writer is unclear.

---

## P4.45 STATE EVENT MODEL

Prefer explicit events when practical:

- lesson_started;
- item_attempted;
- answer_submitted;
- answer_evaluated;
- remediation_started;
- remediation_passed;
- review_completed;
- performance_task_completed;
- stage_gate_passed.

Event does not automatically mean mastery.

Engine decides state transition.

---

## P4.46 ATTEMPT RECORD

Attempt record should be able to preserve:

- attempt ID;
- assessment/item ID;
- content revision;
- mode;
- timestamp;
- response;
- evaluation;
- feedback shown;
- first-attempt flag;
- device/browser metadata only if actually needed and privacy-safe.

Do not collect unnecessary personal data.

---

## P4.47 IDEMPOTENT WRITES

Reload/rerender must not duplicate attempt.

Double click must not double-write mastery.

Submission needs stable transaction/attempt identity where practical.

---

## P4.48 RENDER MUST BE PURE WITH RESPECT TO MASTERY

Rendering:

must not write progress/mastery.

`open lesson → mastery++`

is CRITICAL BUG.

`rerender → localStorage write mastery`

is CRITICAL BUG.

---

## P4.49 RETRY POLICY

Retry may:

- generate new attempt;
- update remediation evidence;
- improve current skill estimate.

But first attempt stays.

No destructive overwrite.

---

## P4.50 REMEDIATION COMPLETION

Do not auto-clear weakness because learner opened remediation card.

Need exit evidence.

---

## P4.51 WEAKNESS LIFECYCLE

Possible states:

- detected;
- active;
- repairing;
- rechecked;
- resolved;
- recurring.

Do not use only boolean weak/not weak if deeper model useful.

---

## P4.52 REVIEW QUEUE OWNERSHIP

One canonical scheduler should own due review state.

Vocabulary UI must not maintain independent SRS schedule if a canonical SRS engine exists.

Avoid duplicate review queues.

---

## P4.53 SRS ALGORITHM

Do not replace algorithm merely because another algorithm is fashionable.

Audit current scheduler first.

Required properties:

- deterministic enough to test;
- due-date integrity;
- no accidental mass reset;
- migration support;
- priority support.

---

## P4.54 SRS SIGNALS

Potential signals:

- correctness;
- response latency;
- hint usage;
- confidence;
- repeated failure;
- production vs recognition;
- delayed success.

Do not add signals unless engine can interpret them meaningfully.

---

## P4.55 PRIORITY MODEL

Recommended priority factors:

- due;
- weakness;
- prerequisite importance;
- active stage;
- high-value vocabulary;
- recent failure;
- long overdue.

Avoid black-box priority impossible to debug.

---

## P4.56 EXAM MODE

Exam must:

- freeze answer reveal;
- preserve first response;
- prevent accidental scoring from navigation;
- support reload/recovery when feasible;
- not silently lose attempt.

---

## P4.57 PRACTICE MODE

Practice may:

- show hints;
- show immediate feedback;
- explain;
- route remediation.

Do not mix practice and exam result history without mode metadata.

---

## P4.58 OFFLINE ASSESSMENT

Offline attempt must remain valid locally.

When later syncing/bridging:

no duplicate attempt.

No data loss.

If system is fully local:

still preserve durable storage contract.

---

## P4.59 CORRUPT STATE

Malformed learner state:

do not silently reset.

Strategy:

- detect;
- preserve raw backup;
- attempt recovery/migration;
- report;
- fallback safely.

---

## P4.60 MASTERy MIGRATION

Any change to mastery schema requires:

- old fixtures;
- migration;
- validation;
- rollback;
- repeated migration test;
- data preservation evidence.

---

## P4.61 ANALYTICS

Analytics must distinguish:

- activity count;
- completion;
- attempts;
- correctness;
- retention;
- production evidence;
- performance tasks.

Do not call activity “mastery”.

---

## P4.62 DASHBOARD

Dashboard may summarize:

- due reviews;
- weak skills;
- current stage;
- next task;
- recent achievement.

Numbers must derive from canonical state.

No decorative fake percentages.

---

## P4.63 LEVEL CLAIMS

Do not claim:

“A2 mastered”

or:

“B2 achieved”

solely based on internal quiz score.

Use phrasing consistent with validated competency framework.

Formal CEFR/TRKI claims require evidence beyond app-internal label.

---

## P4.64 SPEAKING RUBRIC

Recommended criteria:

- task completion;
- comprehensibility;
- pronunciation;
- grammar control;
- lexical appropriacy;
- fluency;
- interaction;
- repair.

Technical speaking additionally:

- terminology;
- explanation;
- logical structure.

Research/defense additionally:

- evidence;
- argumentation;
- limitation awareness;
- question response.

---

## P4.65 WRITING RUBRIC

Recommended:

- task completion;
- organization;
- grammar;
- vocabulary;
- cohesion;
- register;
- technical accuracy.

Research:

- objective clarity;
- method;
- result;
- interpretation;
- limitations.

---

## P4.66 LISTENING RUBRIC/EVIDENCE

Do not infer listening mastery only from:

“played audio”.

Evidence needs learner response.

---

## P4.67 PRONUNCIATION EVIDENCE

Do not promise phoneme-level accuracy unless engine actually supports it.

Record + comparison + structured self/engine signal may be used honestly.

---

## P4.68 MANUAL OVERRIDE

If admin/teacher override exists:

record:

- who/role;
- what changed;
- reason;
- timestamp.

Do not silently mutate evidence history.

---

## P4.69 RESET

Reset must be scoped:

- current exercise;
- current review queue;
- stage progress;
- full learner history.

Full reset needs explicit confirmation.

Never make “restore data” accidentally erase history.

---

## P4.70 IMPORT/EXPORT

Export learner state should preserve:

- schema version;
- history;
- SRS;
- mastery evidence;
- attempts.

Import must validate and migrate.

---

## P4.71 PERFORMANCE BASELINE

Before changing mastery:

capture:

- storage keys;
- state schema;
- attempt counts;
- review queue behavior;
- stage gate logic;
- write paths;
- reset behavior.

---

## P4.72 REQUIRED DELIVERABLES

Create:

- `RUSSIAN_ASSESSMENT_MASTERY_CONSTITUTION.md`
- `RUSSIAN_MASTERY_OWNERSHIP_MATRIX.md`
- `RUSSIAN_ATTEMPT_STATE_SCHEMA.json`
- `RUSSIAN_MASTERY_STATE_SCHEMA.json`
- `RUSSIAN_SRS_STATE_SCHEMA.json`
- `RUSSIAN_REMEDIATION_STATE_SCHEMA.json`
- `RUSSIAN_STAGE_GATE_MATRIX.md`
- `RUSSIAN_ASSESSMENT_ALIGNMENT_MATRIX.md`
- `RUSSIAN_FIRST_ATTEMPT_INTEGRITY_REPORT.md`
- `RUSSIAN_ASSESSMENT_MIGRATION_PLAN.md`

If architecture prefers fewer artifacts, consolidate machine-readable schemas where sensible, but do not lose responsibilities.

---

## P4.73 TEST GATES

Must test:

- first attempt preserved;
- retry separate;
- answer not revealed early;
- presentation cannot write mastery;
- render/reload does not increment progress;
- duplicate click does not duplicate attempt;
- remediation requires evidence;
- stage gate critical skill logic;
- SRS due dates stable;
- old state migrates;
- malformed state does not silently reset;
- offline attempt survives;
- package/runtime parity.

---

## P4.74 FAILURE CONDITIONS

P4 FAIL if:

- click creates mastery;
- open lesson creates mastery;
- UI renderer writes official score;
- retry overwrites first attempt;
- exam reveals answer before submit;
- one recognition score claims full mastery;
- speech API failure marks learner wrong;
- SRS history resets on content rename;
- 7/14/21/28 tests just repeat same questions without purpose;
- weak state clears by opening remediation;
- AI Mentor directly unlocks stage;
- malformed localStorage resets learner history;
- progress dashboard uses fake numbers.

---

## P4.75 PASS CONDITIONS

PASS when:

1. Completion and mastery are distinct.
2. First attempts are immutable.
3. Retry history is preserved.
4. Mastery has canonical owner.
5. SRS has canonical owner.
6. Remediation maps to root cause.
7. Recognition and production are distinct.
8. Speaking evaluation is honest.
9. Listening requires response evidence.
10. Stage gates measure critical competencies.
11. 7/14/21/28 cycles have distinct retention purpose.
12. Assessment aligns with objectives.
13. AI Mentor is non-authoritative.
14. Rendering is state-safe.
15. Offline attempts are durable.
16. State migrations are idempotent.
17. No silent reset.
18. Dashboard derives from canonical state.
19. Tests prove runtime behavior.
20. Learning evidence survives reload/package.

---

## P4.76 FINAL PRINCIPLE

The system must answer:

> **What evidence proves the learner can actually do this?**

If the only evidence is:

- clicked;
- opened;
- watched;
- scrolled;
- viewed answer;

then mastery has NOT been proven.

The valid learning chain is:

`LEARN`
→ `RETRIEVE`
→ `PRODUCE`
→ `TRANSFER`
→ `RETAIN`.

**RUSSIAN ASSESSMENT & MASTERY CONSTITUTION COMPLETE**

---


# PART VI — P5 ADAPTIVE SRS & PERSONALIZATION CONSTITUTION

## P5.0 MISSION

Xây một cơ chế học thích nghi cho môn Tiếng Nga nhưng phải giữ nguyên nguyên tắc:

> **PERSONALIZE THE PATH · DO NOT PERSONALIZE THE TRUTH**

Hệ thống được phép cá nhân hóa:

- thứ tự ôn tập;
- mức độ hỗ trợ;
- độ khó;
- số lần lặp;
- loại bài tập;
- ưu tiên kỹ năng;
- thời điểm review;
- remediation;
- khối lượng học trong ngày.

Hệ thống KHÔNG được cá nhân hóa:

- đáp án đúng;
- grammar truth;
- stress;
- technical terminology;
- official mastery evidence;
- canonical learning objectives.

Personalization chỉ thay đổi **con đường học**, không thay đổi **chuẩn kiến thức**.

---

## P5.1 ADAPTIVE INPUTS

Adaptive engine chỉ được sử dụng các tín hiệu có owner rõ.

Possible signals:

- mastery evidence;
- SRS due state;
- first-attempt results;
- repeated failures;
- review latency;
- hint usage;
- confidence/self-rating;
- speaking weakness;
- listening weakness;
- reading weakness;
- writing weakness;
- active stage;
- current macro module;
- prerequisite gaps;
- recent study load;
- session duration;
- learner-selected priority.

Không dùng:

- UI hover;
- decorative clicks;
- time spent on a page đơn thuần;
- scroll depth;
- route visit count;

làm mastery signal.

---

## P5.2 PERSONALIZATION STATE ≠ LEARNER MASTERY

Tách riêng:

### Mastery state
Chứng minh learner làm được gì.

### Personalization state
Hệ thống đang ưu tiên học gì tiếp theo.

Ví dụ:

learner có thể mastered A2 location grammar nhưng personalization vẫn đưa vào review nếu:

- overdue lâu;
- là prerequisite của unit mới;
- learner tự chọn ôn lại.

Không ghi review priority ngược trở lại mastery.

---

## P5.3 DAILY LEARNING PLAN

Daily planner có thể xây từ:

1. Due review.
2. Critical weakness.
3. Current-stage lesson.
4. Prerequisite repair.
5. Active vocabulary.
6. Listening/speaking exposure.
7. Optional enrichment.

Không để một loại task chiếm toàn bộ ngày học.

Ví dụ:

50 vocab reviews

không được làm mất toàn bộ:

listening;
speaking;
lesson progression.

---

## P5.4 DAILY PLAN CATEGORIES

Recommended categories:

`MUST_DO`

`SHOULD_DO`

`OPTIONAL`

`ENRICHMENT`.

### MUST_DO
Critical overdue hoặc blocker prerequisite.

### SHOULD_DO
Current stage / due review.

### OPTIONAL
Additional practice.

### ENRICHMENT
Advanced/interest-based content.

Không dùng priority label để tạo áp lực sai lệch.

---

## P5.5 PRIORITY FUNCTION

Adaptive priority nên giải thích được.

Potential factors:

- due;
- weakness;
- prerequisite importance;
- active stage;
- production deficit;
- recent failure;
- high-value vocabulary;
- long overdue;
- learner-selected focus.

Không dùng opaque black-box ranking nếu không debug được.

---

## P5.6 PRIORITY EXPLAINABILITY

Khi debug/admin mode cần biết:

“Why is this item here?”

Ví dụ:

`Reason: overdue 6 days + failed twice + prerequisite for R09-U04`.

Không cần hiển thị technical detail cho learner mặc định.

Nhưng engine phải trace được.

---

## P5.7 ADAPTIVE LOAD

Không áp một số lượng task cố định cho mọi learner.

Daily load có thể dựa trên:

- learner-selected session length;
- backlog size;
- current stage;
- recent completion;
- weak-skill distribution.

Không giảm chất lượng để “clear queue”.

---

## P5.8 SESSION LENGTH

Support session presets như:

- 10 phút;
- 20 phút;
- 30 phút;
- 60 phút;
- custom.

Nhưng planner phải ưu tiên:

critical review

+ at least one meaningful productive task

khi thời lượng cho phép.

---

## P5.9 SHORT SESSION POLICY

Nếu learner chỉ có 10 phút:

ưu tiên:

1. critical overdue;
2. high-value active vocabulary;
3. one speaking/listening retrieval;
4. one weak prerequisite.

Không cố nhồi full lesson.

---

## P5.10 LONG SESSION POLICY

Nếu 60–120 phút:

phải có balanced mix:

- review;
- new content;
- listening;
- speaking;
- reading/writing;
- performance/retrieval.

Không kéo dài chỉ bằng thêm flashcards.

---

## P5.11 SKILL BALANCING

Planner phải tránh skill starvation.

Ví dụ nếu 7 ngày liên tục learner chỉ làm vocab:

flag:

`SPEAKING_STARVATION`

`LISTENING_STARVATION`

nếu stage yêu cầu các skill đó.

Không auto-fail mastery.

Chỉ điều chỉnh plan.

---

## P5.12 PRODUCTION DEFICIT

Nếu:

recognition strong

nhưng:

production weak

planner ưu tiên:

- recall;
- sentence production;
- speaking;
- writing;
- transfer.

Không tiếp tục spam recognition MCQ.

---

## P5.13 RECOGNITION DEFICIT

Nếu learner chưa recognize concept:

không đẩy ngay free production.

Route:

input

→ noticing

→ controlled practice

→ recall

→ production.

---

## P5.14 PREREQUISITE REPAIR

Nếu unit advanced fail do prerequisite:

planner chèn:

`REPAIR BLOCK`.

Ví dụ:

motion prefixes weak because directional/multidirectional distinction weak.

Repair base distinction trước.

---

## P5.15 WEAKNESS CONFIDENCE

Không kết luận weakness từ một lỗi đơn.

Có thể dùng:

- repeated errors;
- cross-task failure;
- delayed failure;
- high-confidence wrong answer.

Một error đơn:

`possible weakness`.

Repeated evidence:

`confirmed weakness`.

---

## P5.16 STRENGTH CONFIDENCE

Không mark strong chỉ vì:

one lucky multiple-choice answer.

Strength cần:

- repeated correct evidence;
- varied context;
- preferably production/transfer;
- delayed retention when relevant.

---

## P5.17 SRS SCHEDULING LAYERS

SRS có thể schedule theo:

### Lexical item
word/phrase review.

### Grammar concept
rule/use retrieval.

### Skill pattern
listening discrimination;
pronunciation;
sentence production.

### Performance reminder
less frequent integrated practice.

Không ép mọi content type vào cùng một SRS algorithm nếu semantics khác.

---

## P5.18 VOCAB SRS

Vocabulary scheduling phải phân biệt:

- recognition;
- recall;
- production;
- phrase/collocation;
- listening occurrence.

Không coi một card đúng là toàn bộ lexical mastery.

---

## P5.19 GRAMMAR SRS

Grammar review nên ưu tiên:

- meaning/function retrieval;
- contrast;
- form production;
- sentence application.

Không chỉ:

“chọn ending đúng”.

---

## P5.20 SPEAKING REVIEW

Speaking item không nhất thiết có daily card schedule như vocab.

Có thể schedule theo:

- weak function;
- weak pronunciation target;
- dialogue scenario;
- periodic production check.

---

## P5.21 LISTENING REVIEW

Listening review không lặp cùng audio vô hạn.

Có thể use:

same concept

+ new audio.

Mục tiêu kiểm tra transfer.

---

## P5.22 SPACING VS VARIATION

Review cần cả:

`SPACING`

và:

`VARIATION`.

Nếu learner nhớ câu nguyên văn:

không chắc đã mastered concept.

Use novel but aligned contexts.

---

## P5.23 ITEM EXPOSURE CONTROL

Track exposure count khi cần để tránh:

same item repeated quá thường.

Assessment nên ưu tiên:

concept coverage

không phải memorized question recall.

---

## P5.24 ANTI-MEMORIZATION POLICY

Nếu learner gặp cùng question quá nhiều:

question becomes weak mastery evidence.

Engine nên:

- lower evidence weight;
- use variant;
- use production;
- use transfer.

---

## P5.25 REVIEW QUEUE ORDER

A possible deterministic priority order:

1. blocker prerequisite overdue;
2. confirmed weakness overdue;
3. active-core vocab overdue;
4. current-stage due;
5. production deficit;
6. retained-strength sample;
7. enrichment.

Exact algorithm phải document.

Không hard-code magic weights không giải thích.

---

## P5.26 OVERDUE BACKLOG

Nếu backlog quá lớn:

không bắt learner clear toàn bộ trước khi học mới.

Use backlog recovery mode.

Possible approach:

- prioritize critical/high-value;
- cap legacy backlog per session;
- allow current-stage learning;
- gradually recover.

---

## P5.27 BACKLOG RECOVERY

Backlog categories:

`CRITICAL`

`HIGH_VALUE`

`NORMAL`

`REFERENCE`.

Reference overdue có thể không cần urgent review.

---

## P5.28 NEW ITEM BUDGET

Adaptive planner phải có new-content budget.

Nếu review debt cao:

reduce new items.

Không nhất thiết zero new content.

Nếu review debt thấp:

allow more new material.

---

## P5.29 ACTIVE VOCAB BUDGET

Do not promote 8,000 words to active production.

Activate according to:

- stage;
- course;
- domain;
- learner need.

Passive/reference vocabulary can remain discoverable.

---

## P5.30 STAGE-AWARE VOCAB

Example:

Foundation:
survival core.

Prep:
classroom + basic academic.

HK1:
university + math.

HK2:
technical.

HK3:
research.

HK4:
defense.

Planner should prioritize stage-relevant active vocabulary.

---

## P5.31 DOMAIN FOCUS

Learner may choose temporary domain focus:

- AI;
- Database;
- Control;
- Mathematics;
- Research.

This modifies priority,

not canonical curriculum prerequisites.

---

## P5.32 LEARNER GOAL OVERRIDE

Learner may select:

“ưu tiên nghe-nói”

or

“chuẩn bị seminar”.

Planner can adapt.

But must warn internally if required prerequisite is being neglected.

Do not erase standard path.

---

## P5.33 TEMPORARY INTENSIVE MODE

Support short intensive mode such as:

- visa/admin survival;
- arrival week;
- exam week;
- presentation preparation;
- defense preparation.

Intensive mode has:

start;
end;
focus;
priority overrides.

After end:

return to canonical plan.

---

## P5.34 NO PERMANENT DISTORTION

Temporary intensive focus must not permanently distort:

mastery;

stage progression;

SRS history.

Only plan priority changes.

---

## P5.35 ARRIVAL MODE

Possible focused pack:

- airport;
- immigration;
- transport;
- dorm;
- SIM;
- bank;
- administration.

Useful before travel/arrival.

Still references canonical content.

No duplicate “arrival vocab database”.

---

## P5.36 EXAM MODE PERSONALIZATION

Before exam:

planner may prioritize:

- weak objectives;
- due concepts;
- exam blueprint;
- production practice.

Must NOT:

expose answer keys;
repeat exact exam questions excessively.

---

## P5.37 DEFENSE MODE

Before ВКР defense:

prioritize:

- presentation fluency;
- figure description;
- method explanation;
- limitations;
- Q&A;
- repair language.

Does not remove general Russian state.

---

## P5.38 DIFFICULTY ADAPTATION

Difficulty may adapt through:

- input length;
- audio speed;
- support amount;
- vocabulary novelty;
- syntax complexity;
- time pressure;
- response openness;
- context novelty.

Do not adapt by making content linguistically unnatural.

---

## P5.39 SUPPORT FADING

Scaffolding progression:

full translation

→ partial support

→ Russian hints

→ keywords only

→ no support.

Support can return after repeated failure.

---

## P5.40 HINT POLICY

Hints can be layered:

H1 — remind function.

H2 — show pattern.

H3 — show first part.

H4 — full explanation.

Hint usage should be recorded as evidence metadata if relevant.

Do not treat hinted success equal to unaided success automatically.

---

## P5.41 RESPONSE LATENCY

Latency can be a weak signal.

Never use alone.

Slow but correct answer may still be meaningful learning.

Use latency only if:

- task type supports it;
- measurement is reliable;
- algorithm documented.

---

## P5.42 CONFIDENCE INPUT

Optional learner rating:

- guessed;
- unsure;
- okay;
- confident.

Can adjust review priority.

Cannot override incorrect answer.

---

## P5.43 FALSE CONFIDENCE

High-confidence wrong answer is valuable signal.

Possible priority boost for remediation.

Do not shame learner.

---

## P5.44 LOW-CONFIDENCE CORRECT

Correct but low-confidence may need earlier review.

Do not automatically mark weak if repeated evidence strong.

---

## P5.45 ADAPTIVE REMEDIATION

Remediation depth can adapt:

Level 1:
quick correction.

Level 2:
contrast.

Level 3:
prerequisite review.

Level 4:
micro-lesson replay.

Level 5:
rebuild foundation.

Choose based on failure history.

---

## P5.46 REMEDIATION ESCALATION

Do not escalate after one typo.

Escalate when:

- repeated failure;
- concept confusion;
- prerequisite failure;
- cross-context failure.

---

## P5.47 REMEDIATION DE-ESCALATION

After successful exit check:

reduce support.

Do not keep learner trapped in weak mode forever.

---

## P5.48 INTERLEAVING

Planner should mix:

- old/new;
- vocab/grammar;
- recognition/production;
- listening/speaking;

with rationale.

Avoid pure random shuffle.

---

## P5.49 BLOCK PRACTICE

Block practice still useful for:

- introducing new concept;
- pronunciation drill;
- initial morphology pattern.

Adaptive engine may transition:

block → interleaved.

---

## P5.50 RETENTION SAMPLING

Even mastered concepts should be sampled occasionally.

Do not review everything equally.

Use low-frequency retention checks.

---

## P5.51 LONG-TERM RETENTION

Track:

- last successful evidence;
- delayed review results;
- recurrence of error.

Do not equate old timestamp with forgotten.

---

## P5.52 PERSONALIZATION EXPLANATION TO LEARNER

Learner-facing text should be simple:

“Ôn lại vì bạn vừa sai phần này.”

“Bài này là nền cho bài tiếp theo.”

“Phần nói đang ít luyện hơn nghe.”

Do not expose opaque numeric scoring unless useful.

---

## P5.53 OVERRIDE CONTROL

Learner can:

- skip optional item;
- postpone;
- choose another skill;
- request review.

But critical prerequisite skip should be recorded.

System can recommend, not coerce.

---

## P5.54 SKIP ≠ FAILURE

Skipping task:

does not mean incorrect.

Store separate state if needed.

---

## P5.55 POSTPONE

Postponed review should get new scheduling state.

Avoid infinite snooze loops.

Could cap or surface persistent overdue status.

---

## P5.56 PERSONALIZATION PRIVACY

Use only data needed for learning.

Do not infer sensitive personal traits.

Do not personalize political, health, psychological or unrelated content.

This engine is educational personalization only.

---

## P5.57 CROSS-DEVICE STATE

If future sync exists:

personalization state must merge safely.

Conflicts must not duplicate due items or erase mastery.

If no sync exists:

keep design compatible with future sync.

---

## P5.58 OFFLINE PERSONALIZATION

Planner must function offline from local canonical state.

No cloud AI dependency required to decide basic daily plan.

AI may enrich, not own essential scheduling.

---

## P5.59 AI PERSONALIZATION ROLE

AI Mentor may suggest:

- extra explanation;
- temporary examples;
- conversation practice.

AI must not become:

canonical scheduler;
mastery writer;
SRS owner.

Adaptive engine should remain deterministic/testable at core.

---

## P5.60 RECOMMENDATION ENGINE

Recommendation output:

- next unit;
- due review;
- weak skill task;
- optional enrichment.

Each recommendation must have:

reason;
source state;
expiry/re-evaluation condition.

---

## P5.61 STALE RECOMMENDATIONS

On meaningful new evidence:

recalculate.

Do not keep old recommendation cards indefinitely.

---

## P5.62 RECOMMENDATION DEDUPLICATION

Avoid:

same task appearing simultaneously in:

Today;
Weakness;
Review;
Recommended.

One task can have multiple reasons but one canonical plan entry.

---

## P5.63 TODAY PLAN OWNERSHIP

One canonical planner owns “Today”.

Dashboard, Hub bridge and Russian UI consume the same plan.

Do not create multiple independent Today engines.

---

## P5.64 HUB INTEGRATION

Main Hub may provide:

- available time;
- schedule;
- stage;
- high-level goal.

Russian subject owns:

- internal skill priority;
- SRS;
- remediation;
- learning task selection.

Hub must not directly mutate internal mastery.

---

## P5.65 PLANNER OUTPUT CONTRACT

Possible plan item:

- task ID;
- source entity ID;
- task type;
- priority;
- reason codes;
- estimated minutes;
- stage;
- skill;
- due metadata;
- required/optional;
- completion evidence type.

Avoid embedding full content object.

---

## P5.66 REASON CODES

Examples:

`OVERDUE`

`WEAK_CONCEPT`

`PREREQUISITE`

`CURRENT_STAGE`

`PRODUCTION_DEFICIT`

`SKILL_STARVATION`

`LEARNER_PRIORITY`

`RETENTION_SAMPLE`

`INTENSIVE_MODE`.

---

## P5.67 ADAPTIVE STATE SCHEMA

Create separate personalization state if needed:

- active focus;
- session preference;
- current intensive mode;
- backlog status;
- planner history;
- recommendation history.

Do not duplicate mastery.

---

## P5.68 PLANNER HISTORY

Planner history can help debug:

what was recommended;

why;

whether learner did/skipped/postponed.

Do not let planner history become mastery evidence by itself.

---

## P5.69 A/B EXPERIMENT SAFETY

If future experimentation exists:

never randomize:

- answer truth;
- grammar correctness;
- mastery definition.

May test:

- ordering;
- UI presentation;
- reminder timing;
- explanation style.

Must not corrupt learner history.

---

## P5.70 ALGORITHM VERSIONING

Adaptive algorithm can have internal version.

Store version only when needed for reproducibility.

Do not expose to learner UI.

Algorithm change must not require resetting learner state.

---

## P5.71 MIGRATION

Personalization algorithm migration:

must preserve:

- mastery;
- SRS due state;
- attempts.

Planner cache/recommendations may be safely regenerated if explicitly derived.

---

## P5.72 FAIL-SAFE

If adaptive engine fails:

fallback to deterministic canonical sequence + due reviews.

Never block learning entirely.

---

## P5.73 NO DATA LOSS

Corrupt planner state:

reset planner cache if safe.

Do not reset mastery/state just because recommendation cache is broken.

---

## P5.74 PERFORMANCE

Planner must not scan all 8,000 vocab + all dialogues on every render.

Use:

- indexed candidates;
- due queue;
- stage filters;
- incremental recalculation.

---

## P5.75 CANDIDATE GENERATION

Recommended architecture:

1. Generate candidate tasks from relevant indexes.
2. Filter prerequisites.
3. Apply due/weakness/stage priority.
4. Balance skills.
5. Fit session budget.
6. Deduplicate.
7. Emit plan.

---

## P5.76 CANDIDATE LIMIT

Do not rank entire universe if unnecessary.

Query top relevant candidate pools.

Token/runtime efficient.

---

## P5.77 DAILY PLAN STABILITY

Plan should not reshuffle completely on every refresh.

Use stable plan identity until meaningful evidence changes.

---

## P5.78 COMPLETION REPLANNING

After completing task:

update only affected dependencies.

Avoid recomputing everything if not needed.

---

## P5.79 SKILL STARVATION WINDOW

Choose configurable observation window.

Example conceptually:

several study sessions/days.

Do not hard-code arbitrary 7 days unless justified.

---

## P5.80 BALANCE BY STAGE

Foundation:

listening/speaking heavy.

Prep:

language + classroom + grammar.

HK1:

lecture/reading/explanation.

HK2:

technical production.

HK3/HK4:

research/presentation/Q&A.

Adaptive balance follows stage goals.

---

## P5.81 VIETNAM-FIRST POLICY

During early Vietnam stage, preserve existing strategy:

Listening/Speaking/Video prioritized.

Vocabulary and grammar support immediate use.

Do not let SRS backlog invert this into flashcard-only learning.

---

## P5.82 REVIEW CAPS

Can cap review workload per session.

But critical prerequisites may exceed cap if learner chooses.

Do not silently discard due items.

Remaining items stay due/backlog.

---

## P5.83 LEARNER FATIGUE SIGNALS

Do not infer medical/psychological fatigue.

Only use explicit educational signals like:

- user chooses shorter session;
- repeated postponement;
- user requests lighter session.

Do not diagnose learner.

---

## P5.84 MOTIVATION MECHANICS

Achievements/streaks may support engagement.

They must not:

- inflate mastery;
- punish legitimate rest;
- override learning priorities.

---

## P5.85 STREAK POLICY

Streak is engagement metadata only.

No mastery bonus.

No score bonus.

---

## P5.86 ACHIEVEMENT POLICY

Achievements can recognize:

- completing first dialogue;
- first technical presentation;
- consistent review;
- first successful stage gate.

Avoid achievements for meaningless clicks.

---

## P5.87 PERSONALIZED DIAGNOSTIC REFRESH

Periodic diagnostic may update plan.

Do not force full diagnostic frequently.

Use targeted checks after evidence drift.

---

## P5.88 DRIFT DETECTION

If previously strong skill repeatedly fails:

mark potential regression.

Schedule targeted recheck.

Do not immediately wipe mastery.

---

## P5.89 RECOVERY

If recheck passes:

retain mastery with updated evidence.

If recheck fails:

downgrade confidence/route remediation according to canonical mastery policy.

---

## P5.90 DOMAIN EXPANSION

When learner enters new domain:

AI, DB, Control...

activate:

relevant lexical/technical concepts.

Do not clone course.

---

## P5.91 DOMAIN PREREQUISITES

Technical domain unit may require:

general academic language

+ specific technical vocabulary.

Planner checks both.

---

## P5.92 CONTENT AVAILABILITY

Planner only recommends content that exists and validates.

No dangling recommendation.

---

## P5.93 OFFLINE AVAILABILITY

If offline:

planner filters tasks requiring unavailable external media unless cached/fallback exists.

---

## P5.94 ADAPTIVE AUDIO

If supported:

start controlled speed.

Then use normal speed.

Do not permanently slow audio just because learner failed once.

---

## P5.95 ADAPTIVE TRANSLATION

Support can fade:

RU+VI
→ RU dominant
→ Russian-only.

If learner repeatedly fails comprehension:

temporary VI scaffold may return.

No permanent regression unless needed.

---

## P5.96 ADAPTIVE WRITING SUPPORT

Progression:

model

→ outline

→ keywords

→ independent writing.

Do not keep model answer always visible.

---

## P5.97 ADAPTIVE SPEAKING SUPPORT

Progression:

full target

→ chunks

→ keywords

→ prompt only

→ unexpected follow-up.

---

## P5.98 ADAPTIVE READING SUPPORT

Progression:

glossed text

→ limited glossary

→ Russian definitions

→ independent technical reading.

---

## P5.99 PERFORMANCE TASK READINESS

Planner should not schedule high-stakes integrated task before critical prerequisites.

Can schedule diagnostic rehearsal earlier.

---

## P5.100 STAGE GATE PREPARATION

Before stage gate:

show:

- readiness by competency;
- unresolved blockers;
- recommended targeted practice.

Do not give actual exam answers.

---

## P5.101 READINESS ≠ PASS

Readiness estimate:

recommendation only.

Official pass comes from assessment evidence.

---

## P5.102 EXPLAINABLE READINESS

Readiness based on:

- recent evidence;
- required competencies;
- retention;
- production.

Not cosmetic progress bar.

---

## P5.103 MANUAL STUDY MODE

Learner can bypass recommendations and browse course.

Adaptive engine observes valid evidence from manual study only when canonical engine records it.

Do not punish manual navigation.

---

## P5.104 DISCOVERY MODE

Allow exploring advanced content without unlocking mastery.

Exploration:

does not equal completion.

---

## P5.105 PREVIEW MODE

Preview advanced lesson:

read-only/limited practice if policy allows.

No stage advancement from preview alone.

---

## P5.106 ADMIN/TEACHER OVERRIDE

If manual plan override exists:

log:

- override;
- reason;
- scope;
- expiry.

Do not mutate mastery merely by assigning task.

---

## P5.107 PERSONALIZATION TEST MATRIX

Test at least:

- new learner;
- strong learner;
- weak speaking;
- weak grammar;
- huge backlog;
- no backlog;
- short session;
- long session;
- offline;
- unsupported speech API;
- stage transition;
- intensive mode;
- manual browsing.

---

## P5.108 DETERMINISM TEST

Given same canonical state and same planner algorithm/version:

plan should be reproducible unless randomness explicitly configured.

If shuffle used:

seed/control for tests.

---

## P5.109 SKILL BALANCE TEST

Verify planner does not starve:

- speaking;
- listening;
- writing;
- technical production

under large vocab backlog.

---

## P5.110 BACKLOG TEST

10,000 hypothetical due items must not:

- freeze UI;
- create unusable plan;
- load all full content objects.

---

## P5.111 STATE SAFETY TEST

Planner rerender:

must not mutate mastery.

Opening Today page:

must not mark tasks done.

---

## P5.112 DUPLICATE TASK TEST

One canonical task:

one plan item.

Multiple reasons:

merge reason codes.

---

## P5.113 OFFLINE TEST

Open app offline.

Planner generates usable plan from local state.

Complete offline task.

Reload.

State survives.

---

## P5.114 MIGRATION TEST

Old planner/personalization state:

migrate.

Mastery/SRS intact.

No duplicate due items.

---

## P5.115 REQUIRED DELIVERABLES

Create:

- `RUSSIAN_ADAPTIVE_SRS_PERSONALIZATION_CONSTITUTION.md`
- `RUSSIAN_DAILY_PLANNER_CONTRACT.json`
- `RUSSIAN_PERSONALIZATION_STATE_SCHEMA.json`
- `RUSSIAN_RECOMMENDATION_REASON_CODES.json`
- `RUSSIAN_ADAPTIVE_PRIORITY_POLICY.md`
- `RUSSIAN_BACKLOG_RECOVERY_POLICY.md`
- `RUSSIAN_SKILL_BALANCE_POLICY.md`
- `RUSSIAN_INTENSIVE_MODE_POLICY.md`
- `RUSSIAN_PERSONALIZATION_TEST_MATRIX.md`

If keeping one-master-file philosophy for prompt documentation, these are implementation deliverables inside repository, not new competing prompt files.

---

## P5.116 FAIL CONDITIONS

P5 FAIL if:

- planner writes mastery;
- recommendation click counts as evidence;
- backlog blocks all new learning;
- vocab reviews starve speaking/listening;
- same item appears multiple times in Today;
- plan reshuffles on every render;
- personalization requires cloud AI to function;
- AI becomes SRS owner;
- support never fades;
- speech API failure corrupts priority;
- temporary intensive mode permanently distorts curriculum;
- planner scans all rich datasets every render;
- learner state resets after algorithm change.

---

## P5.117 PASS CONDITIONS

PASS when:

1. Planner has one canonical owner.
2. Mastery and personalization state are separate.
3. Daily plan is explainable.
4. Due + weakness + stage priorities coexist.
5. Skill starvation is prevented.
6. Recognition/production deficits route differently.
7. Prerequisite repair works.
8. Backlog recovery works.
9. Active/passive vocabulary are treated differently.
10. Intensive modes are temporary.
11. Support fades adaptively.
12. Recommendations deduplicate.
13. Plan stable across refresh.
14. Offline planner works.
15. AI is optional/non-authoritative.
16. Migration preserves mastery/SRS.
17. Large backlog does not freeze app.
18. Tests cover major learner profiles.
19. Manual browsing remains possible.
20. Learner can understand why a task is recommended.

---

## P5.118 FINAL PRINCIPLE

Adaptive learning is not:

“AI chooses random things for learner.”

Adaptive learning is:

> **use trustworthy learner evidence to choose the next highest-value learning action while preserving canonical curriculum, learner agency and state integrity.**

The engine should answer:

1. What should the learner do next?
2. Why?
3. Which evidence caused that recommendation?
4. What prerequisite does it depend on?
5. What happens if learner skips it?
6. What evidence will prove it helped?

If those questions cannot be answered:

personalization is not mature enough.

**RUSSIAN ADAPTIVE SRS & PERSONALIZATION CONSTITUTION COMPLETE**

---


# PART VI — P6 LISTENING · SPEAKING · AUDIO INTERACTION ENGINE CONSTITUTION

## P6.0 MISSION

P6 hoàn thiện tầng móng cuối cùng:

> **biến audio, pronunciation, recording, speech recognition, dialogue và Deep Speaking thành một hệ thống tương tác có owner rõ, fallback rõ, state rõ và đánh giá trung thực.**

P6 không tạo lại curriculum.

P6 không tự thay mastery truth của P4.

P6 không tự thay adaptive priority của P5.

P6 cung cấp **interaction/evidence layer** cho P2–P5 sử dụng.

---

## P6.1 CANONICAL RESPONSIBILITY SPLIT

Phải xác định owner cho:

- audio asset;
- audio player;
- playback state;
- playback speed;
- transcript;
- transcript reveal policy;
- microphone permission;
- recording;
- recorded blob/session;
- speech recognition adapter;
- recognition transcript;
- pronunciation signal;
- speaking task state;
- dialogue state;
- Deep Speaking state;
- audio cache/offline fallback;
- speaking evidence submission.

Không để UI component tự sở hữu state dài hạn nếu domain engine đã có.

---

## P6.2 AUDIO SOURCE TYPES

Distinguish:

`RECORDED_AUTHENTIC`

`RECORDED_PEDAGOGICAL`

`TTS`

`GENERATED`

`EXTERNAL`

`UNKNOWN`.

Source type phải có provenance khi cần.

Không nói “native audio” nếu là TTS.

---

## P6.3 AUDIO ASSET CONTRACT

Audio asset nên có:

- stable media ID;
- source type;
- path/source reference;
- language;
- transcript reference;
- duration if known;
- speaker metadata if verified;
- speed metadata if measured/known;
- offline availability;
- provenance.

Không fabricate speaker attributes.

---

## P6.4 AUDIO PLAYER CONTRACT

Player capabilities:

- play;
- pause;
- seek;
- restart;
- speed control where pedagogically allowed;
- repeat segment if supported;
- keyboard/touch accessibility;
- current time/duration;
- error/fallback state.

Player must not:

- mark item correct simply because played;
- write mastery on playback.

---

## P6.5 SPEED POLICY

Possible speeds:

slow pedagogical;
normal;
faster/lecture.

Do not permanently train learner on slowed audio.

Recommended progression:

controlled

→ normal

→ variable authentic speed.

If browser audio playbackRate is used:

do not claim voice remains perfectly natural at every rate.

---

## P6.6 LISTENING FIRST ATTEMPT

For comprehension task:

first listen state may matter.

Track when pedagogically needed:

- listen count;
- transcript revealed?
- replay used?
- speed changed?

These are support/evidence metadata.

Not automatic mastery penalties.

---

## P6.7 TRANSCRIPT REVEAL

Policies:

`HIDDEN`

`AFTER_ATTEMPT`

`AFTER_SUBMIT`

`ALWAYS_AVAILABLE`

`ACCESSIBILITY_OVERRIDE`

Exam/listening assessment:

must respect configured reveal policy.

Opening transcript must not silently mark failure.

---

## P6.8 SEGMENTED AUDIO

For pronunciation/shadowing:

support short segment units.

Segment identity:

must reference canonical phrase/sentence/task.

Avoid duplicate audio chunks unless packaging requires derived segment.

---

## P6.9 SHADOWING CONTRACT

Shadowing is practice, not proof of spontaneous speaking mastery.

State may track:

- listened;
- repeated;
- recorded;
- self-reviewed.

But mastery requires separate productive evidence.

---

## P6.10 MICROPHONE PERMISSION

Explicit states:

`UNKNOWN`

`REQUESTING`

`GRANTED`

`DENIED`

`UNAVAILABLE`

`ERROR`.

Do not repeatedly spam permission request after denial.

Give fallback.

---

## P6.11 RECORDING CONTRACT

Recording engine must handle:

- start;
- stop;
- cancel;
- max duration;
- accidental navigation;
- permission denial;
- device interruption;
- unsupported browser;
- storage cleanup.

Recording UI must show clear active state.

---

## P6.12 RECORDING PRIVACY

Default principle:

recordings remain local unless a feature explicitly requires upload and user action/authorized system contract supports it.

Do not silently upload voice.

If persisted locally:

document retention and cleanup.

---

## P6.13 RECORDING STORAGE

Do not accumulate unbounded blobs.

Need policy:

- transient practice recordings;
- retained assessment recordings;
- user-deletable recordings;
- storage quota handling.

If recording not needed after evaluation:

release safely according to policy.

---

## P6.14 RECORDING FAILURE

If recording fails:

learning path must still work.

Fallback examples:

- self-assessment;
- typed response;
- manual confirmation;
- retry on supported browser.

Do not block whole lesson.

---

## P6.15 SPEECH RECOGNITION ADAPTER

Speech recognition must be behind a canonical adapter.

UI should not call browser/provider API independently in multiple places.

Adapter owns:

- capability detection;
- start/stop;
- language;
- interim/final transcript;
- timeout;
- errors;
- provider/browser differences.

---

## P6.16 SPEECH RECOGNITION SUPPORT STATE

Explicit support:

`SUPPORTED`

`PARTIAL`

`UNSUPPORTED`

`PERMISSION_BLOCKED`

`RUNTIME_ERROR`.

Do not silently fail.

---

## P6.17 RECOGNITION TRANSCRIPT ≠ SPEECH TRUTH

Recognition output is noisy.

It can support:

- keyword match;
- rough completeness;
- user feedback.

It cannot alone prove:

- phonetic accuracy;
- natural stress;
- intonation quality;
- full speaking mastery.

---

## P6.18 PRONUNCIATION SIGNAL MODEL

Possible signals:

- transcript similarity;
- target keyword presence;
- syllable/phoneme signal if real engine supports;
- timing;
- self-comparison;
- teacher/manual signal.

Every signal must declare confidence/limitations.

No fake `98.7% pronunciation score`.

---

## P6.19 PRONUNCIATION FEEDBACK

Feedback should identify actionable target:

- stress;
- vowel reduction;
- hard/soft consonant;
- difficult consonant;
- phrase rhythm.

Do not generate specific phonetic diagnosis without evidence engine capable of detecting it.

---

## P6.20 STRESS PRACTICE

Target word data should use canonical stress representation.

Speaking task can display:

lemma

or:

stress-highlighted display

according to practice mode.

Assessment can hide support.

---

## P6.21 VIETNAMESE ERROR TARGETING

P6 consumes error corpus from P2/P3.

Can route practice toward:

- ы / и;
- ш / щ;
- ж;
- ц / ч;
- х;
- р;
- hard/soft;
- unstressed о;
- stress;
- clusters;
- intonation.

P6 does not invent error corpus itself.

---

## P6.22 BASIC SPEAKING ENGINE

Canonical basic task owner:

`speaking.json`

or owner confirmed by P1/P3.

Supports modes:

- listen;
- repeat;
- shadow;
- substitution;
- answer;
- roleplay;
- short production.

No deep research Q&A here.

---

## P6.23 SPEAKING TASK STATE

State should distinguish:

`NOT_STARTED`

`LISTENED`

`PRACTICED`

`ATTEMPTED`

`SUBMITTED`

`FEEDBACK_RECEIVED`

`REMEDIATION`

`PASSED`

where relevant.

Do not map all tasks to identical lifecycle if unnecessary.

---

## P6.24 DIALOGUE ENGINE

Dialogue engine responsibilities:

- role selection;
- turn order;
- expected function;
- optional canonical line;
- variation;
- learner response;
- unexpected turn;
- repair path;
- completion evidence.

Dialogue UI must not be static transcript viewer only.

---

## P6.25 ROLE REVERSAL

Where useful:

learner plays Role A

then Role B.

This improves interaction flexibility.

Not mandatory for every dialogue.

---

## P6.26 DIALOGUE VARIATION

Supported conceptual variants:

- lexical paraphrase;
- changed detail;
- faster audio;
- unexpected response;
- misunderstanding;
- missing information;
- problem escalation.

Purpose:

prevent script memorization.

---

## P6.27 REPAIR LANGUAGE

Dialogue engine should explicitly train:

- repeat please;
- slower please;
- clarification;
- confirmation;
- rephrase;
- self-correction.

Repair ability is first-class interaction skill.

---

## P6.28 DIALOGUE MEMORY

Within one dialogue session:

track turn context.

Do not require global AI context for deterministic scripted scenarios.

For AI-enhanced free dialogue:

separate AI layer from canonical dialogue state.

---

## P6.29 DEEP SPEAKING ENGINE

Canonical Deep Speaking owner:

`deep-speaking-bauman.json`

or P3-resolved owner.

Task types include:

- monologue;
- technical explanation;
- compare;
- justify;
- problem-solution;
- research summary;
- seminar response;
- defense Q&A.

---

## P6.30 PREPARATION TIME

Deep task may configure:

- preparation seconds;
- target duration;
- notes allowed;
- lexical support allowed.

Do not hard-code same timing.

---

## P6.31 TIME PRESSURE

Pressure is advanced progression tool.

Not default beginner behavior.

Adaptive system P5 may choose when readiness supports it.

---

## P6.32 FOLLOW-UP QUESTION ENGINE

Follow-up questions may come from:

- validated deterministic pool;
- AI-generated temporary questions;
- teacher/admin set.

Official assessment must know source type.

AI-generated follow-up should not become canonical automatically.

---

## P6.33 SPEAKING RUBRIC INTEGRATION

P6 produces evidence for P4 rubric.

P6 does not own official mastery.

Evidence may include:

- task completion;
- transcript;
- keyword coverage;
- recording;
- timing;
- interaction turns;
- repair actions.

P4 decides scoring/mastery.

---

## P6.34 LISTENING ENGINE

Listening task lifecycle:

`LOAD AUDIO`
→ `PLAY`
→ `COLLECT RESPONSE`
→ `SUBMIT`
→ `EVALUATE`
→ `FEEDBACK`
→ `REMEDIATE/CONTINUE`.

Playing audio alone is not completion evidence.

---

## P6.35 LISTENING VARIATION

Same concept can be tested with:

different speaker;
different sentence;
different context;
different speed.

Do not overfit learner to one recording.

---

## P6.36 DICTATION

Dictation task must normalize only safe orthographic variations.

Do not over-normalize:

case endings;
stress-relevant spelling;
meaning-changing errors.

Normalization policy must be documented.

---

## P6.37 NUMBER/DATE LISTENING

Special tasks for:

- phone;
- money;
- dates;
- room numbers;
- measurements.

Need robust parsing/evaluation rules.

---

## P6.38 CLASSROOM LISTENING

Audio scenarios:

- instruction;
- deadline;
- task change;
- teacher correction;
- homework;
- room change.

Learner response may be action/selection/summary.

---

## P6.39 LECTURE LISTENING

Advanced tasks should measure:

- topic;
- structure;
- definition;
- example;
- cause/effect;
- assignment;
- key terminology.

Not word-for-word transcription.

---

## P6.40 NOTE-TAKING INTERACTION

Allow note area if useful.

Notes are learner state, not canonical content.

Do not auto-grade notes as mastery unless a defined rubric exists.

---

## P6.41 AUDIO PRELOAD POLICY

Do not preload entire audio library.

Preload:

current/next small set

when beneficial.

Large media:

lazy load.

---

## P6.42 OFFLINE AUDIO

Classify:

`REQUIRED_OFFLINE`

`OPTIONAL_OFFLINE`

`ONLINE_ONLY_WITH_FALLBACK`.

Core lessons should not silently break offline.

---

## P6.43 CACHE POLICY

Audio cache needs:

- version;
- invalidation;
- quota awareness;
- stale handling.

P14 later hardens packaging/cache globally.

P6 only defines audio-specific contract.

---

## P6.44 NETWORK FAILURE

If audio unavailable:

display meaningful fallback.

Do not spin forever.

Possible fallback:

- cached audio;
- text/transcript practice;
- alternate local item.

---

## P6.45 TTS FALLBACK

TTS may be used when approved.

Clearly classify it.

Do not substitute TTS for authentic listening everywhere.

---

## P6.46 TTS VOICE SELECTION

If platform voice varies:

do not assume same speaker/quality across devices.

Core learning should tolerate voice availability differences.

---

## P6.47 TTS OFFLINE LIMITATION

If browser/device lacks Russian voice offline:

fallback must exist.

Do not make core lesson dependent solely on installed voice.

---

## P6.48 AUDIO NORMALIZATION

If build pipeline normalizes loudness/format:

derived media must map to canonical media ID.

Do not change linguistic content.

---

## P6.49 MEDIA FORMATS

Prefer broadly compatible browser formats.

If multiple formats needed:

treat as variants of one media asset.

---

## P6.50 MOBILE AUDIO

Test:

- screen lock behavior where relevant;
- Bluetooth/headphones;
- touch play;
- mobile autoplay restrictions;
- microphone permission.

Do not assume desktop behavior.

---

## P6.51 IOS/SAFARI FALLBACK

Where browser APIs differ:

feature-detect.

Do not browser-sniff unless necessary.

Provide fallback instead of broken controls.

---

## P6.52 ANDROID/CHROME

Test mic/audio lifecycle.

But do not make Android-specific code canonical if standards adapter can handle.

---

## P6.53 DESKTOP

Test:

keyboard;
headset mic;
multiple input devices if browser supports.

No need complex device selector unless actual product need exists.

---

## P6.54 ACCESSIBILITY

Audio controls require:

- semantic buttons;
- labels;
- keyboard;
- focus;
- transcript alternative where appropriate;
- visible recording state;
- no color-only status.

---

## P6.55 REDUCED MOTION

Recording waveform/animations must respect reduced motion if applicable.

Waveform is decorative unless functional.

---

## P6.56 CAPTION / TRANSCRIPT ACCESSIBILITY

Transcript may serve accessibility.

Assessment reveal policy may require alternate accessible design.

Do not remove accessibility without equivalent accommodation.

---

## P6.57 ERROR MESSAGES

Distinguish:

- mic denied;
- no mic;
- recognition unsupported;
- recognition timeout;
- audio load failed;
- recorder failed;
- offline unavailable.

Do not show generic red error forever.

---

## P6.58 ERROR LIFECYCLE

Errors should:

appear when relevant;

clear when resolved;

not persist globally after route change unless actionable.

---

## P6.59 EVENT LISTENERS

Audio/recording components must not duplicate event listeners after rerender.

Test repeated route open/close.

---

## P6.60 MUTATION / RERENDER SAFETY

Rerender must not:

- restart recording;
- submit duplicate evidence;
- replay audio unexpectedly;
- request mic permission again;
- create duplicate speech recognizers.

---

## P6.61 SINGLE ACTIVE RECORDER

Only one recorder active per learning session unless deliberate multi-track feature exists.

Starting another must stop/reject safely.

---

## P6.62 SINGLE ACTIVE RECOGNIZER

Avoid overlapping recognizers.

Canonical adapter manages concurrency.

---

## P6.63 ROUTE EXIT

If leaving speaking route while recording:

explicitly stop/cancel.

Do not leave hidden microphone recording.

---

## P6.64 VISIBILITY CHANGE

Browser/tab visibility change:

handle recorder/recognizer safely.

Do not assume hidden tab continues reliably.

---

## P6.65 TIMEOUTS

Recognition/recording/network timeout must be explicit and recoverable.

No infinite pending state.

---

## P6.66 SPEAKING EVIDENCE IDENTITY

Each official attempt needs stable attempt ID from P4.

P6 attaches audio/transcript signals to that attempt.

P6 must not create second official attempt on rerender.

---

## P6.67 PRACTICE RECORDINGS

Practice may be ephemeral.

Do not flood official attempt history with every rehearsal unless policy says so.

---

## P6.68 PERFORMANCE TASK RECORDING

For НИР/ВКР simulations:

support longer recordings if required.

Need memory/quota strategy.

Potentially chunk/stream only if architecture supports and needed.

Do not overengineer prematurely.

---

## P6.69 TECHNICAL SPEAKING

Tasks should support:

- formula description;
- algorithm explanation;
- system architecture;
- experiment;
- chart;
- limitation.

P6 engine is domain-agnostic.

P8/P9 provide validated content.

---

## P6.70 PRESSURE Q&A

Pressure mode may:

- limit prep;
- add follow-up;
- remove phrase support.

Must still preserve learner agency:

pause/cancel allowed outside formal exam policy.

---

## P6.71 AI CONVERSATION BOUNDARY

If AI powers conversation:

AI supplies temporary conversational turn.

Canonical dialogue engine owns:

- scenario state;
- objectives;
- evidence capture;
- completion.

AI must not own mastery.

---

## P6.72 AI HALLUCINATION GUARD

AI-generated Russian response used in official content:

must not become canonical without validation.

For ephemeral practice:

label internal source and avoid persistence as truth.

---

## P6.73 AI ROLE STABILITY

Prompt AI with clear role:

teacher;
clerk;
lecturer;
reviewer;
committee member.

Do not let AI drift scenario silently.

---

## P6.74 AI DIFFICULTY CONTROL

P5 may request difficulty.

P6 passes constraints:

- level;
- vocabulary;
- grammar;
- scenario;
- response length.

AI output must remain bounded.

---

## P6.75 AUDIO SEARCH / INDEX

Media search index is derived.

Search result points to media/content IDs.

Do not duplicate transcripts as independent truth.

---

## P6.76 DATA LOADING

Basic speaking can be core/local.

Dialogue/Deep Speaking remain lazy if large.

P6 must not force all large speaking datasets into startup.

---

## P6.77 MEMORY BASELINE

Measure representative:

- audio buffer;
- recorder;
- recognition;
- large dialogue route;
- Deep Speaking route.

Check cleanup after close.

---

## P6.78 PERFORMANCE BASELINE

Measure:

- first audio play latency;
- route open;
- mic start;
- recorder start;
- recognition start;
- dialogue render;
- Deep Speaking load.

Targets come from baseline/product need, not arbitrary numbers.

---

## P6.79 SECURITY

Sanitize:

- transcripts;
- imported dialogue;
- external media metadata.

No raw HTML injection from content.

---

## P6.80 EXTERNAL MEDIA

External audio/video must have:

- safe URL handling;
- fallback;
- provenance;
- availability behavior.

Core assessment should not depend on fragile external media without fallback.

---

## P6.81 LOCAL STORAGE / IDB

Do not put large audio blobs in localStorage.

Use appropriate storage or ephemeral memory.

P14 later hardens storage architecture.

---

## P6.82 QUOTA FAILURE

When browser storage quota fails:

do not corrupt learner state.

Recording storage failure should not wipe attempts.

---

## P6.83 BASIC SPEAKING ACCEPTANCE

A basic speaking flow must prove:

1. load task;
2. hear model;
3. record/attempt;
4. evaluate/fallback;
5. feedback;
6. retry;
7. preserve first official attempt if assessment;
8. reload safely.

---

## P6.84 DIALOGUE ACCEPTANCE

Dialogue flow must prove:

1. select role;
2. receive turn;
3. respond;
4. variation;
5. repair;
6. role/context state;
7. completion evidence.

---

## P6.85 DEEP SPEAKING ACCEPTANCE

Deep Speaking must prove:

1. prompt;
2. prep;
3. timed/untimed response according to task;
4. recording/evidence;
5. rubric signals;
6. follow-up;
7. remediation;
8. history.

---

## P6.86 LISTENING ACCEPTANCE

Listening must prove:

1. audio works;
2. transcript hidden/revealed correctly;
3. response recorded;
4. feedback correct;
5. replay/support metadata preserved where needed;
6. offline fallback works for required core items.

---

## P6.87 BROWSER FAILURE MATRIX

Test:

- mic allowed;
- mic denied;
- no mic;
- recognition supported;
- recognition unsupported;
- offline;
- audio cache missing;
- route interrupted;
- repeated open/close;
- mobile touch;
- keyboard.

---

## P6.88 STATE INTEGRITY TEST

Ensure:

play audio

does not mutate mastery.

start recording

does not create official success.

recognition transcript

does not auto-pass unless assessment policy explicitly evaluates it.

---

## P6.89 DUPLICATE ENGINE TEST

Search for:

- multiple recorder implementations;
- multiple recognition wrappers;
- multiple dialogue state stores;
- direct UI speech API calls bypassing adapter.

Resolve or document.

---

## P6.90 FALLBACK TEST

For every optional browser API:

there is usable learning fallback.

No dead-end route.

---

## P6.91 REQUIRED DELIVERABLES

Create/maintain:

- `RUSSIAN_LISTENING_SPEAKING_ENGINE_CONSTITUTION.md`
- `RUSSIAN_AUDIO_OWNER_MAP.md`
- `RUSSIAN_RECORDING_CONTRACT.md`
- `RUSSIAN_SPEECH_RECOGNITION_ADAPTER_CONTRACT.md`
- `RUSSIAN_PRONUNCIATION_SIGNAL_POLICY.md`
- `RUSSIAN_DIALOGUE_RUNTIME_CONTRACT.md`
- `RUSSIAN_DEEP_SPEAKING_RUNTIME_CONTRACT.md`
- `RUSSIAN_AUDIO_OFFLINE_POLICY.md`
- `RUSSIAN_SPEAKING_BROWSER_MATRIX.md`
- `RUSSIAN_P6_ACCEPTANCE_REPORT.md`

If project architecture consolidates docs, preserve responsibilities even if filenames differ.

---

## P6.92 FAIL CONDITIONS

P6 FAIL if:

- playback writes mastery;
- mic denial breaks route;
- recognition unsupported has no fallback;
- UI directly creates multiple recognition engines;
- rerender duplicates recorder;
- hidden recording continues after route exit;
- transcript appears before assessment policy allows;
- shadowing counted as spontaneous mastery;
- fake pronunciation precision shown;
- dialogue is transcript-only;
- Deep Speaking has no productive response path;
- large dialogue/deep data loads at startup unnecessarily;
- audio required offline but unavailable without fallback;
- recording quota failure corrupts learner state.

---

## P6.93 PASS CONDITIONS

PASS when:

1. Audio owner clear.
2. Recorder owner clear.
3. Recognition adapter single-owner.
4. Transcript policy works.
5. Basic speaking works.
6. Dialogue state works.
7. Deep Speaking works.
8. Repair language supported.
9. Browser/API fallbacks work.
10. Speaking evidence feeds P4 without owning mastery.
11. P5 can adapt difficulty without corrupting truth.
12. Offline core listening/speaking has defined behavior.
13. Large datasets remain lazy.
14. Repeated rerender does not duplicate engines/listeners.
15. Mobile + desktop representative paths pass.
16. Accessibility controls pass.
17. No fake pronunciation authority.
18. Performance baseline recorded.
19. State survives reload where required.
20. P6 evidence complete.

**P6 LISTENING · SPEAKING · AUDIO ENGINE CONSTITUTION COMPLETE**

---

# PART VII — P7–P17 RESPONSIBILITY LOCK MAP

This section locks boundaries before detailed prompt expansion.

It prevents later phases from overlapping or rewriting the foundation.

---

## P7 — LINGUISTIC AUTHORITY & CONTENT VALIDATION

Owns:

- Russian correctness;
- stress validation;
- morphology validation;
- case government;
- aspect pairing;
- collocation;
- register;
- naturalness;
- technical terminology validation;
- provenance/authority workflow;
- generated-content validation.

Does NOT own:

- mastery;
- SRS;
- audio runtime;
- UI redesign.

Exit:
canonical content can be trusted linguistically within declared confidence.

---

## P8 — ACADEMIC & TECHNICAL RUSSIAN DEEPENING

Owns:

- academic discourse;
- mathematics language;
- CS;
- AI/ML;
- database;
- networks/OS;
- control/automation;
- statistics;
- experiment/report language;
- lecture terminology.

Consumes P7-validated linguistic rules.

Exit:
technical/academic content coverage supports R11–R21 targets.

---

## P9 — READING · WRITING · НИР · ВКР PRODUCTION SYSTEM

Owns:

- reading progression;
- note-taking;
- email;
- lab/report writing;
- paraphrase;
- summary;
- academic writing;
- НИР;
- ВКР;
- figures/tables/slides;
- defense language.

Does not own official assessment engine; integrates with P4.

Exit:
learner can move from technical input to research output.

---

## P10 — AI MENTOR PEDAGOGY & GUARDRAILS

Owns:

- AI context builder;
- coaching policy;
- explanation policy;
- temporary practice generation;
- conversation roles;
- source boundary;
- write permissions;
- hallucination guard;
- language switching policy.

AI remains non-authoritative for mastery/canonical truth.

Exit:
AI improves learning without becoming second learning engine.

---

## P11 — SCENARIO · SIMULATION · DIALOGUE EXPERIENCE LAYER

Owns:

- real-life scenarios;
- classroom simulations;
- administration;
- lab/seminar;
- defense simulations;
- branching interactions;
- unexpected turns;
- scenario progression.

Uses P6 dialogue runtime.

Does not create duplicate speech engine.

Exit:
curriculum can be practiced in integrated real-world contexts.

---

## P12 — AUTHORING · CONTENT GOVERNANCE · EDITOR WORKFLOW

Owns:

- safe content authoring;
- schema-aware editor;
- draft/review/active lifecycle;
- provenance workflow;
- validation before publish;
- bulk import/export;
- candidate generation;
- content diff/review.

Does not bypass canonical owner registry.

Exit:
future content can be added without code surgery or architecture drift.

---

## P13 — UX · ACCESSIBILITY · RESPONSIVE · INFORMATION ARCHITECTURE

Owns:

- learner-facing navigation;
- route discoverability;
- cognitive hierarchy;
- responsive behavior;
- keyboard/touch;
- accessibility;
- density;
- readability;
- component consistency;
- presentation integration.

Must preserve P1–P12 domain/state contracts.

Exit:
all capabilities are usable and understandable across representative devices.

---

## P14 — OFFLINE · PACKAGING · PERFORMANCE · MIGRATION · SECURITY HARDENING

Owns non-functional engineering:

- package boundaries;
- lazy loading;
- cache;
- service worker;
- offline;
- large data;
- memory;
- load performance;
- migration hardening;
- storage recovery;
- security;
- package parity;
- update invalidation.

Exit:
system survives real deployment constraints.

---

## P15 — FULL-SYSTEM QA · REGRESSION · ACCEPTANCE

Owns:

- end-to-end test matrix;
- cross-phase regression;
- user journeys;
- linguistic QA sampling;
- pedagogical QA;
- visual QA;
- accessibility QA;
- performance acceptance;
- package/runtime parity;
- defect triage;
- acceptance evidence.

P15 should fix via owner phase, not invent local patches where possible.

Exit:
release candidate satisfies product acceptance contract.

---

## P16 — LEGACY RETIREMENT · TECHNICAL DEBT CLOSURE · RC FREEZE

Owns:

- delete-later execution;
- duplicate engine retirement;
- dead route cleanup;
- obsolete CSS/JS removal;
- alias/migration cleanup;
- docs synchronization;
- release candidate freeze;
- rollback package;
- final dependency inventory.

Deletion only with evidence.

Exit:
scaffolding removed, no known critical architecture debt blocking release.

---

## P17 — PRODUCTION PUBLISH · VERIFY · OBSERVE

Owns:

- production build;
- deploy/publish;
- production SHA;
- smoke test;
- cache/version verification;
- rollback readiness;
- post-deploy observability;
- final production evidence.

P17 does NOT redesign or refactor architecture.

Exit:
production verified against accepted RC.

---

# PART VIII — 17-LAYER HARD GATE MATRIX

Every phase must publish this compact record:

| Field | Required |
|---|---|
| Phase | P0–P17 |
| State | NOT_STARTED / BASELINING / IN_PROGRESS / VALIDATING / BLOCKED / FAIL / PASS |
| Base SHA | yes |
| Head SHA | yes when changed |
| Scope | yes |
| Canonical owners touched | yes |
| Class A–F | yes |
| Inputs | yes |
| Deliverables | yes |
| Tests | yes |
| Runtime evidence | yes |
| State/data migration | when relevant |
| Risks | yes |
| Rollback | when relevant |
| Known limitations | yes |
| Next-phase contract | yes |
| PR | when changed |
| Merge SHA | when merged |
| Production impact | yes |

---

## FOUNDATION ACCEPTANCE AFTER P6

P0–P6 may be declared:

`FOUNDATION_LOCKED`

only when:

- current runtime mapped;
- content architecture defined;
- canonical schema/owners defined;
- assessment/mastery ownership defined;
- adaptive planner/SRS ownership defined;
- listening/speaking/audio owners defined;
- state safety validated;
- no unresolved blocker/critical foundation conflict.

Once locked:

P7–P17 build upward.

No casual foundation refactor.

---

## MASTER EXECUTION PRINCIPLE

The 17-layer architecture is not 17 independent prompts.

It is one executable dependency system:

`P0 commands`

→ `P1 observes reality`

→ `P2 defines learning`

→ `P3 defines truth ownership`

→ `P4 defines evidence/mastery`

→ `P5 defines next action`

→ `P6 defines listening/speaking interaction`

→ `P7 validates language truth`

→ `P8 deepens academic/technical content`

→ `P9 produces research language`

→ `P10 adds bounded AI assistance`

→ `P11 adds integrated scenarios`

→ `P12 makes content sustainable`

→ `P13 makes capabilities usable`

→ `P14 hardens engineering`

→ `P15 proves the whole system`

→ `P16 removes scaffolding and freezes RC`

→ `P17 publishes and verifies production`.

**NO PHASE MAY WIN BY BREAKING AN EARLIER CONTRACT.**

**BUILD UPWARD · VALIDATE DOWNWARD · RELEASE ONLY AFTER EVIDENCE.**

---

# PART IX — FUTURE MASTER-PROMPT MAINTENANCE ZONE

Mọi tầng tiếp theo phải được thêm vào đây hoặc chèn vào đúng Part hiện hữu.

Không tạo Master Prompt thứ hai.

The responsibility map for P0–P17 is now locked above.

Future upgrades must:
- deepen an existing P7–P17 section;
- avoid creating a new phase unless a truly new responsibility exists;
- patch this same Master Prompt;
- preserve foundation contracts unless a formal Foundation Change Request is approved.

---

# MASTER END RULE

Khi Work/Codex sử dụng file này:

1. Xác định phase P0–P17 hiện tại từ repo evidence và status.
2. Kiểm tra entry gate trước khi thay đổi.
3. Không làm lại phase đã PASS trừ khi dependency/diff làm invalid evidence.
4. Chỉ đọc dependency cần thiết; reuse inventory/evidence đã có.
5. Trace canonical owner và sửa root cause.
6. Chạy đúng test/evidence gate của phase.
7. Không tự phá contract P0–P6 sau FOUNDATION_LOCKED.
8. Cập nhật phase transition record và next-phase contract.
9. Cập nhật chính file Master Prompt nếu người dùng yêu cầu nâng cấp prompt.
10. Không tạo prompt song song.
11. P17 là production authority; các phase trước không tự coi preview là production.

**ONE PROJECT · ONE MASTER PROMPT · ONE SOURCE OF TRUTH · SEVENTEEN CONTROLLED PHASES**

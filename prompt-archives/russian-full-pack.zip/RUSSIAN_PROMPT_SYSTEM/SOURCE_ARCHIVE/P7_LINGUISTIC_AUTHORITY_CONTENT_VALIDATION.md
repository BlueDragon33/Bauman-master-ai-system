# P7 — LINGUISTIC AUTHORITY & CONTENT VALIDATION CONSTITUTION
## RUSSIAN CORRECTNESS · NATURALNESS · TERMINOLOGY · PROVENANCE · CONTENT TRUST

Repository: `BlueDragon33/Bauman-master-ai-system`

Primary scope: `subjects/russian/`

Execution mode:

**AUTONOMOUS · EVIDENCE-FIRST · SOURCE-AWARE · LINGUISTIC-INTEGRITY-FIRST · ROOT-CAUSE-FIRST · TOKEN-EFFICIENT**

---

# P7 CHANGELOG

- 2026-09-30 — Initial deep P7 constitution created.
- 2026-09-30 — Final hardening: source freshness, golden regression set, transliteration, numerals/units, terminology drift, assessment variants, learner-evidence impact and rollback.

---

# 0. MISSION

P7 establishes whether Russian-language content in the system can be trusted.

The goal is not to create more content.

The goal is to prove, classify, repair and govern the linguistic quality of existing and future content.

P7 owns:

- Russian orthography;
- stress;
- pronunciation-relevant text metadata;
- morphology;
- inflectional correctness;
- case government;
- preposition government;
- verb aspect pairing;
- verbs of motion forms where represented;
- lexical meaning;
- polysemy separation;
- collocations;
- phraseology;
- semantic compatibility;
- register;
- naturalness;
- classroom language;
- academic Russian wording;
- technical terminology;
- research terminology;
- translation fidelity;
- Vietnamese-interference traps;
- provenance;
- authority/confidence;
- generated-content validation;
- duplicate/near-duplicate linguistic quality;
- cross-dataset linguistic consistency.

P7 does NOT own:

- learner mastery;
- SRS scheduling;
- adaptive recommendation;
- scoring;
- audio runtime;
- speech recognition runtime;
- UI redesign;
- PWA;
- production deployment.

P7 may expose problems in those areas but routes them to the canonical owner.

---

# 1. FOUNDATION PRECONDITION

Before P7 implementation:

1. P1 evidence must identify actual loaded datasets and owners.
2. P2 curriculum target must exist.
3. P3 canonical content ownership/schema must be sufficiently defined.
4. P4 assessment must be able to identify answer-key content.
5. P5 must not depend on unvalidated derived linguistic duplicates.
6. P6 must identify how text/stress/transcript/audio are consumed.

If any dependency is unclear:

mark:

`BLOCKED_BY_FOUNDATION`

or:

`NEEDS_FOUNDATION_CLARIFICATION`.

Do not silently invent ownership.

---

# 2. FOUNDATION FREEZE

P7 must respect P0–P6 as load-bearing contracts.

P7 may enrich canonical content.

P7 may repair incorrect linguistic data.

P7 may add validators and provenance.

P7 may propose schema extensions.

P7 must NOT:

- create a second vocab engine;
- create a second grammar source;
- create a second dialogue source;
- alter mastery because a linguistic item was repaired;
- reset SRS;
- rewrite routes;
- redesign app shell.

If a content repair changes semantic identity and learner state may be affected:

create a migration plan.

---

# 3. P7 CENTRAL QUESTION

For every canonical linguistic fact, P7 must be able to answer:

> Why should the system believe this is correct?

A record is not trustworthy merely because:

- JSON parses;
- AI generated it;
- it has existed for months;
- tests pass;
- it appears in multiple files;
- it “sounds right” to the model.

---

# 4. AUTHORITY CLASSES

Every high-risk linguistic record or assertion should be classifiable as:

`A — AUTHORITATIVE`

`B — CURATED / MULTI-SOURCE VERIFIED`

`C — CORPUS-SUPPORTED`

`D — GENERATED / MACHINE-SUGGESTED`

`E — LEGACY / UNVERIFIED`

`U — UNKNOWN`

These are trust classes, not learner levels.

Do not force every low-risk sentence to carry heavy metadata if unnecessary.

High-risk facts require stronger authority.

---

# 5. HIGH-RISK LINGUISTIC FACTS

Treat as high-risk:

- stress placement;
- pronunciation-sensitive representation;
- irregular forms;
- noun gender exceptions;
- animacy where it affects morphology;
- case government;
- preposition + case;
- aspect pair;
- motion-verb pairing;
- imperative irregularity;
- numeral government;
- short adjective/participle forms when taught;
- lexical sense;
- false friends;
- collocation;
- register;
- formal/academic phrasing;
- technical terminology;
- scientific definitions;
- official administrative vocabulary;
- assessment answer keys.

These must not rely solely on model intuition.

---

# 6. SOURCE HIERARCHY

When external validation is required, prefer source families in roughly this order according to the fact being checked:

1. Official/academic Russian language institutions and dictionaries.
2. Reputable orthoepic, spelling, explanatory and grammatical dictionaries.
3. Academic Russian grammars.
4. National or scholarly corpora for attested usage.
5. Russian-language university textbooks and peer-reviewed academic materials for technical/research usage.
6. Standards/official technical documentation when terminology is standards-bound.
7. Reputable educational sources.
8. Multiple high-quality real usage examples.
9. Generated/model suggestion only as candidate evidence.

No single source type is universally authoritative for every question.

Example:

a corpus is useful for natural usage frequency;

a normative dictionary is stronger for stress;

a technical standard/textbook may be stronger for field terminology.

---

# 7. SOURCE DIVERSITY RULE

For ambiguous/high-impact facts:

do not rely on one weak source.

Use triangulation.

Possible result statuses:

`VERIFIED`

`VERIFIED_WITH_VARIANTS`

`CONTEXT_DEPENDENT`

`DISPUTED`

`UNVERIFIED`

`INCORRECT`.

---

# 8. SOURCE SNAPSHOT

When a content correction depends on external evidence, record enough evidence to reproduce the decision:

- source type;
- source title/reference;
- accessed/verified date when relevant;
- exact linguistic claim;
- notes;
- validator/reviewer;
- confidence.

Do not copy long copyrighted material into repository.

Store concise evidence/reference.

---

# 9. PROVENANCE ≠ CORRECTNESS

A record can be:

`AUTHORITATIVE SOURCE`

but incorrectly transcribed into the app.

A record can be:

`GENERATED`

but later fully validated.

Therefore track separately:

- origin;
- validation status;
- validation evidence;
- confidence.

---

# 10. LINGUISTIC VALIDATION STATUS

Recommended validation lifecycle:

`UNVALIDATED`

→ `AUTO_CHECKED`

→ `SOURCE_CHECKED`

→ `CURATED`

→ `ACTIVE`.

Possible exception states:

`FLAGGED`

`BLOCKED`

`DISPUTED`

`DEPRECATED`.

Do not automatically promote generated content from AUTO_CHECKED to CURATED.

---

# 11. CONTENT RISK TIERS

### TIER 0 — Structural
IDs, enums, missing fields.

Can be automated strongly.

### TIER 1 — Low-risk language
Simple formatting/orthography candidates.

Automation useful.

### TIER 2 — Linguistic
Morphology, stress, government, aspect, meaning.

Requires stronger validation.

### TIER 3 — Academic/technical
Domain terminology, formal register, research language.

Requires domain-aware evidence.

### TIER 4 — Assessment-critical
Answer keys and content that directly determines learner score/mastery.

Requires strongest validation.

---

# 12. ORTHOGRAPHY VALIDATION

Audit:

- Cyrillic spelling;
- ё/е policy;
- capitalization;
- punctuation;
- hyphenation;
- abbreviation;
- numeric formatting;
- quote style where relevant.

Do not normalize `ё` blindly if lexical distinction or teaching value matters.

Maintain a documented display/search policy.

---

# 13. Ё / Е POLICY

Separate:

canonical orthography

from:

search normalization.

Search may support `ё ↔ е`.

Canonical display should preserve intended form when known.

Do not permanently erase `ё` merely for search convenience.

---

# 14. STRESS VALIDATION

Stress must be treated as first-class learning data.

Audit:

- missing stress;
- multiple stress marks;
- invalid stress position;
- stress attached to non-vowel;
- conflicting stress across datasets;
- homographs with different stress;
- variant stress;
- grammatical-form stress changes.

Do not assume lemma stress applies to every inflected form.

---

# 15. STRESS REPRESENTATION

Choose one canonical internal policy.

Possible design:

- base lemma without mark;
- dedicated `stressDisplay`;
- structured stress position;
- per-form stress where needed.

Search index can derive stressless form.

Do not use ad hoc Unicode stress representation inconsistently.

---

# 16. STRESS CONFLICT RESOLUTION

If sources differ:

classify:

- accepted variant;
- register/domain variant;
- obsolete/nonstandard;
- source conflict.

Do not force a single answer when normative variants are valid.

Assessment must not mark accepted variant wrong.

---

# 17. MORPHOLOGY VALIDATION

Audit lexical forms for:

- gender;
- number;
- declension;
- indeclinability;
- animacy;
- irregular plural;
- genitive plural;
- comparative/superlative when represented;
- verb conjugation;
- past forms;
- imperative;
- reflexive form;
- participles where taught.

Do not generate full paradigms unless needed.

---

# 18. MORPHOLOGY ENGINE VS STORED FORMS

Determine canonical owner.

If morphology engine can derive safe regular forms:

avoid storing redundant copies.

Store exceptions/teaching-critical forms when needed.

Do not let stored forms and engine disagree silently.

---

# 19. CASE GOVERNMENT

Create structured validation for:

- verb + case;
- adjective + case;
- noun + dependent case;
- preposition + case;
- verb + preposition + case.

Example:

`зависеть от + GEN`

must not exist only as prose.

---

# 20. GOVERNMENT CONFLICT DETECTOR

Flag when the same head word is represented with incompatible patterns.

Do not assume one pattern must win:

different senses may govern different structures.

Resolve at sense level when necessary.

---

# 21. PREPOSITION VALIDATION

Audit:

- preposition;
- case;
- semantic use;
- motion/static contrast;
- fixed phrases;
- academic usage.

High-priority areas:

`в / на`

`из / с`

`к`

`от`

`для`

`по`

`о / об`

and technical/academic constructions.

---

# 22. CASE EXAMPLE QUALITY

An example is not valid merely because ending is correct.

It must also be:

- semantically plausible;
- natural;
- appropriate to level;
- useful for target function;
- free from unrelated complexity unless intentional.

---

# 23. ASPECT VALIDATION

Audit:

- imperfective/perfective label;
- pair relation;
- lexicalized non-pairs;
- multiple valid partners;
- prefix meaning changes;
- secondary imperfectives;
- context-specific contrast.

Do not force every verb into a one-to-one aspect pair.

---

# 24. ASPECT PAIR CONFIDENCE

Each aspect relation may need:

`CANONICAL_PAIR`

`COMMON_CORRESPONDENCE`

`CONTEXT_DEPENDENT`

`NOT_A_SIMPLE_PAIR`

`UNVERIFIED`.

This prevents false pair data.

---

# 25. VERBS OF MOTION

Audit:

- unidirectional/multidirectional pairing;
- prefixed forms;
- semantic compatibility;
- transport vs walking;
- figurative meanings when taught.

Do not mix beginner motion rules with advanced lexicalized meanings without level metadata.

---

# 26. LEXICAL SENSE VALIDATION

A lemma can have multiple senses.

Audit whether Vietnamese translation corresponds to the actual sense used in:

- example;
- dialogue;
- technical context;
- academic context.

Do not attach one broad Vietnamese translation to every occurrence if meanings differ.

---

# 27. POLYSEMY POLICY

Prefer:

one lexical identity

+ multiple sense records

when appropriate.

Do not create duplicate lexical IDs just because translation changes by context.

But split truly different lexemes/homonyms when necessary.

---

# 28. FALSE FRIENDS

Build/validate high-value false-friend records for Vietnamese/English-influenced learners when relevant.

Each must include:

- misleading association;
- correct meaning;
- example;
- contrast.

Do not overpopulate with trivia.

---

# 29. COLLOCATION VALIDATION

Audit:

- verb + noun;
- adjective + noun;
- noun + noun/government;
- academic collocation;
- technical collocation.

Examples should reflect real usage.

A grammatically possible phrase is not necessarily a natural collocation.

---

# 30. COLLOCATION STRENGTH

Possible categories:

`FIXED`

`STRONG`

`COMMON`

`POSSIBLE`

`DOMAIN_SPECIFIC`.

Do not imply statistical precision unless corpus evidence actually supports it.

---

# 31. PHRASEOLOGY

Idioms and fixed expressions should be explicitly marked.

Do not teach idiom meaning as compositional grammar.

Include register/context constraints.

---

# 32. NATURALNESS VALIDATION

P7 must detect content that is:

- grammatically correct but unnatural;
- literal translation from Vietnamese;
- literal translation from English;
- overly formal for daily speech;
- too colloquial for academic writing;
- technically comprehensible but not idiomatic Russian.

Naturalness validation needs usage evidence, not only rule checking.

---

# 33. NATURALNESS LABEL

Possible:

`NATIVE_NEUTRAL`

`FORMAL`

`ACADEMIC`

`TECHNICAL`

`COLLOQUIAL`

`BOOKISH`

`RARE`

`AWKWARD`

`NONSTANDARD`.

Use only where useful.

---

# 34. REGISTER VALIDATION

Separate:

- colloquial;
- neutral;
- polite;
- formal administrative;
- academic;
- scientific;
- technical;
- bureaucratic;
- presentation/defense.

Learner should not use survival slang in ВКР defense.

---

# 35. POLITENESS & PRAGMATICS

Audit:

- ты / вы;
- requests;
- imperatives;
- softening;
- email openings/closings;
- teacher/student interaction;
- administration interaction.

A grammatically correct imperative can still be pragmatically inappropriate.

---

# 36. CLASSROOM LANGUAGE VALIDATION

Validate teacher phrases such as:

- instructions;
- corrections;
- deadlines;
- task transitions;
- examples;
- attention markers.

Prefer language actually plausible in Russian-speaking classrooms.

---

# 37. ACADEMIC LANGUAGE VALIDATION

Audit academic functions:

- definition;
- comparison;
- cause;
- evidence;
- method;
- result;
- limitation;
- conclusion;
- counterargument.

Ensure patterns are reusable and natural.

Do not create pseudo-academic language by making everyday sentences longer.

---

# 38. TECHNICAL TERMINOLOGY VALIDATION

For each domain:

- Mathematics;
- CS;
- AI/ML;
- Database;
- Networks/OS;
- Control/Automation;
- Statistics;
- Research methods;

validate:

- canonical Russian term;
- common alternative;
- abbreviation;
- borrowed-English variant;
- deprecated/rare variant;
- definition;
- collocations;
- grammar/morphology.

---

# 39. TERMINOLOGY SOURCE POLICY

Technical terminology should be validated against domain-appropriate Russian sources such as:

- university textbooks;
- academic publications;
- recognized technical documentation;
- standards where relevant;
- authoritative Russian-language vendor/open-source docs when technology-specific.

Do not use machine translation as sole authority.

---

# 40. ENGLISH BORROWINGS

Russian technical language may use:

- established Russian term;
- transliterated borrowing;
- English token.

P7 must record actual domain usage.

Do not “Russify” terminology artificially.

---

# 41. ABBREVIATION VALIDATION

For abbreviations:

- full Russian form;
- meaning;
- domain;
- pronunciation/readout if pedagogically needed;
- variant capitalization.

Do not invent expansions.

---

# 42. FORMULA / SYMBOL LANGUAGE

Validate how technical Russian expresses:

- equals;
- greater/less than;
- exponent;
- root;
- derivative;
- integral;
- matrix/vector;
- percentage;
- decimal.

Use authentic mathematical phrasing.

---

# 43. TRANSLATION VALIDATION

Vietnamese translations are scaffolds.

Audit for:

- meaning fidelity;
- sense mismatch;
- overly literal translation;
- missing context;
- technical mistranslation;
- register mismatch.

Do not force word-for-word equivalence.

---

# 44. BIDIRECTIONAL CHECK

For high-value lexical/technical content:

check:

Russian → Vietnamese meaning

and

Vietnamese concept → appropriate Russian expression.

This catches misleading equivalence.

---

# 45. SIMPLIFIED RUSSIAN DEFINITIONS

If `meaningRuSimple` or similar exists:

ensure definition:

- does not use harder unexplained vocabulary excessively;
- does not become circular;
- matches intended sense;
- is level-appropriate.

---

# 46. EXAMPLE VALIDATION

Each important example must pass:

1. linguistic correctness;
2. target concept relevance;
3. semantic plausibility;
4. register appropriateness;
5. level appropriateness;
6. no accidental new high-load grammar unless intended;
7. no conflict with translation.

---

# 47. EXAMPLE DIVERSITY

Avoid thousands of examples with identical syntax and nouns changed.

Need enough variation for transfer.

But do not generate variation solely for count.

---

# 48. EXAMPLE DUPLICATE DETECTOR

Detect:

- exact duplicate;
- near duplicate;
- templated clone;
- translation duplicate;
- same example assigned to unrelated concepts.

Near duplicate only flags candidates.

No blind deletion.

---

# 49. DIALOGUE VALIDATION

Audit dialogue for:

- realistic turn-taking;
- role consistency;
- politeness;
- scenario plausibility;
- repair opportunities;
- lexical/grammar alignment;
- level;
- variation quality.

Do not evaluate dialogue only sentence-by-sentence.

---

# 50. DIALOGUE CONTEXT CONSISTENCY

Flag:

- changing names/details unexpectedly;
- inconsistent location;
- contradictory time;
- impossible administrative flow;
- role reversal without intent.

---

# 51. DEEP SPEAKING VALIDATION

Deep speaking prompt must:

- require productive language;
- be understandable;
- match stage;
- avoid requiring domain knowledge not taught;
- have clear task;
- support meaningful rubric.

Do not create abstract philosophical prompts unrelated to Bauman goals unless explicitly enrichment.

---

# 52. LISTENING TRANSCRIPT VALIDATION

Ensure transcript:

- matches audio;
- uses correct orthography;
- preserves meaningful spoken variation;
- does not silently “correct” audio into different sentence.

If transcript is normalized:

record that transformation.

---

# 53. AUDIO-TEXT CONSISTENCY

Where feasible, validate:

audioRef

↔ transcript

↔ lexical targets

↔ lesson target.

Mismatch is HIGH risk.

---

# 54. PRONUNCIATION TARGET VALIDATION

Pronunciation target text must have:

- correct stress;
- intended phonetic focus;
- appropriate minimal contrast;
- no misleading transcription.

P7 validates linguistic target.

P6 owns runtime measurement.

---

# 55. ASSESSMENT ANSWER VALIDATION

Assessment-critical content gets strongest gate.

Check:

- exactly what question asks;
- correct answer;
- acceptable variants;
- distractors;
- explanation;
- concept mapping;
- no hidden ambiguity;
- no answer leaked by prompt;
- no multiple accepted answers marked wrong.

---

# 56. DISTRACTOR QUALITY

A distractor should be:

- plausible;
- related to target error;
- not accidentally correct;
- not nonsense.

Do not generate distractors by random word replacement.

---

# 57. OPEN-RESPONSE ACCEPTANCE

For open answers:

define acceptable linguistic variants when feasible.

Do not overfit exact string.

But do not over-normalize away meaningful grammar errors.

---

# 58. CEFR / TRKI LABEL VALIDATION

If content has CEFR/TRKI levels:

validate using official/recognized functional descriptors when possible.

If mapping is approximate:

label:

`APPROXIMATE`.

Do not claim formal certification equivalence.

---

# 59. LEVEL APPROPRIATENESS

A sentence can be correct but wrong for level.

Audit:

- vocabulary novelty;
- syntax complexity;
- abstraction;
- speech speed metadata;
- task openness;
- assumed background knowledge.

---

# 60. DIFFICULTY ≠ LENGTH

Longer text is not automatically harder in a meaningful way.

Difficulty may come from:

- lexical density;
- syntax;
- inference;
- speed;
- ambiguity;
- production freedom;
- domain concepts.

---

# 61. CROSS-DATA CONSISTENCY

Same concept across:

- lesson;
- grammar;
- vocab;
- speaking;
- dialogue;
- deep speaking;
- tests;

must not contradict.

P7 builds/uses concept IDs to detect conflict.

---

# 62. CANONICAL TRUTH OWNER

When contradiction occurs:

trace canonical owner from P3.

Repair owner first.

Then rebuild/update derived references.

Do not patch five copies individually if they are derived.

---

# 63. DERIVED INDEX POLICY

Search index, knowledge index and link indexes must not be manually “corrected” as linguistic sources.

Fix canonical data.

Rebuild derived artifacts.

---

# 64. GENERATED CONTENT POLICY

AI-generated content starts as:

`CANDIDATE`.

It must not directly become:

`ACTIVE CANONICAL`.

Pipeline:

`GENERATE`
→ `SCHEMA VALIDATE`
→ `DUPLICATE CHECK`
→ `LINGUISTIC CHECK`
→ `SOURCE CHECK IF HIGH RISK`
→ `PEDAGOGICAL CHECK`
→ `CURATE`
→ `ACTIVATE`.

---

# 65. GENERATED CONTENT METADATA

Candidate should record:

- generation source/process;
- target objective;
- requested level;
- referenced concepts;
- validation status.

Do not store hidden chain-of-thought.

Store only reproducible content metadata.

---

# 66. NO AI SELF-APPROVAL

The same generation step must not be treated as independent validation.

AI can perform a second review pass as a filter,

but high-risk canonical facts still need appropriate external/curated evidence.

---

# 67. BULK GENERATION SAFETY

Before bulk generation:

pilot small sample.

For example:

20 vocab enrichments

before:

8,000-item migration.

Check:

- error rate;
- schema fit;
- duplication;
- style;
- level;
- terminology.

---

# 68. BULK VALIDATION SAMPLING

For large batches:

use:

- deterministic automated checks;
- risk-based samples;
- random samples;
- edge-case samples;
- high-impact samples.

Do not declare thousands of items trusted after checking five easy records.

---

# 69. CONFIDENCE MODEL

Possible internal confidence:

`HIGH`

`MEDIUM`

`LOW`

`UNKNOWN`.

Confidence must derive from evidence quality.

Do not manufacture numeric confidence percentages.

---

# 70. CONFLICT MODEL

When sources conflict:

create a conflict record containing:

- fact;
- source A;
- source B;
- context;
- likely explanation;
- selected policy or unresolved status.

Do not hide conflict.

---

# 71. VARIANT POLICY

Valid variants may differ by:

- stress;
- spelling;
- register;
- region;
- professional usage;
- formal vs colloquial use.

If both accepted:

assessment must recognize valid variants as allowed by task context.

---

# 72. OBSOLETE / RARE USAGE

Mark:

`OBSOLETE`

`RARE`

`BOOKISH`

when pedagogically relevant.

Do not teach rare forms as neutral default.

---

# 73. CORPUS EVIDENCE

Use corpora to answer questions such as:

- Is this phrase attested?
- Which preposition is common?
- Is this collocation natural?
- What register/context appears?

Corpus frequency alone does not decide normative correctness.

---

# 74. FREQUENCY DATA

If frequency bands are used:

record source/method.

Do not invent frequency ranking.

If no reliable source:

use curriculum priority instead.

---

# 75. VOCABULARY PRIORITY VS FREQUENCY

High-value Bauman term may be low general frequency.

Do not remove it merely because general corpus frequency is low.

Separate:

general frequency

from:

course importance.

---

# 76. TECHNICAL SENSES

Common word may have specialized technical sense.

Example policy:

one lemma

+ sense-level domain metadata.

Do not overwrite everyday meaning.

---

# 77. REGISTER ACROSS STAGES

Same function may require different forms:

A0 survival request

vs

B2 academic request.

P7 validates register.

P2/P8 decide teaching sequence.

---

# 78. VIETNAMESE INTERFERENCE VALIDATION

P7 must validate error patterns that claim Vietnamese interference.

Do not invent contrastive-linguistic explanations casually.

Where evidence is weak:

mark as teaching hypothesis, not linguistic fact.

---

# 79. ERROR EXAMPLE SAFETY

Wrong examples should be:

- clearly marked wrong;
- limited;
- immediately contrasted with correct form;
- not over-repeated.

Avoid reinforcing erroneous forms.

---

# 80. NORMALIZATION POLICY

Text normalization for validators/search must distinguish:

safe normalization:

- whitespace;
- Unicode normalization;
- stressless search copy;

from unsafe normalization:

- case ending changes;
- ё deletion from canonical display;
- punctuation that changes meaning;
- accent removal in pronunciation teaching.

---

# 81. MACHINE VALIDATORS

Create automated validators for:

- invalid/missing IDs;
- invalid Cyrillic/Unicode anomalies;
- duplicate stress marks;
- impossible stress location;
- conflicting stress records;
- unresolved lexical refs;
- broken aspect reciprocal refs;
- invalid government enum;
- missing sense IDs;
- empty translations;
- duplicate examples;
- assessment answer mismatch;
- provenance missing on high-risk items;
- generated-active items without validation;
- cross-dataset conflicting canonical IDs.

Automation flags candidates.

It does not replace linguistic review.

---

# 82. VALIDATOR OUTPUT

Machine-readable finding fields:

- finding ID;
- entity ID;
- file/path;
- rule;
- severity;
- confidence;
- evidence;
- suggested action;
- auto-fix safe?;
- status.

---

# 83. AUTO-FIX POLICY

Safe auto-fixes may include:

- whitespace;
- duplicate metadata removal;
- deterministic ID reference repair when mapping is certain;
- Unicode normalization.

Do NOT auto-fix without review:

- stress;
- meaning;
- aspect;
- government;
- translation;
- terminology;
- answer key.

---

# 84. SEVERITY

Use:

`BLOCKER`

`CRITICAL`

`HIGH`

`MEDIUM`

`LOW`.

Examples:

BLOCKER:
wrong canonical answer systematically corrupts mastery.

CRITICAL:
high-frequency wrong stress taught everywhere.

HIGH:
technical term mistranslated across a module.

MEDIUM:
unnatural but understandable example.

LOW:
minor stylistic inconsistency.

---

# 85. RISK PRIORITIZATION

Prioritize by:

- learner harm;
- recurrence;
- assessment impact;
- stage importance;
- propagation across derived content;
- difficulty of repair;
- migration risk.

Do not prioritize only because a fix is easy.

---

# 86. CONTENT HEALTH DASHBOARD

P7 may produce metrics such as:

- validated canonical items;
- high-risk unvalidated;
- stress coverage;
- government coverage;
- terminology coverage;
- assessment-critical unresolved;
- generated candidate backlog;
- duplicate candidates.

Metrics are diagnostic, not learner-facing mastery.

---

# 87. NO METRIC GAMING

Do not fill fake provenance or meaningless metadata to improve coverage percentage.

UNKNOWN is better than fabricated completeness.

---

# 88. VALIDATION QUEUES

Possible review queues:

`ASSESSMENT_CRITICAL`

`HIGH_FREQUENCY_CORE`

`FOUNDATION`

`ACADEMIC`

`TECHNICAL`

`RESEARCH`

`GENERATED_CANDIDATES`

`LEGACY_UNKNOWN`.

Queue priority should reflect risk.

---

# 89. FOUNDATION LANGUAGE PRIORITY

Before deep technical content:

validate R01–R10 high-frequency foundation.

Wrong foundation errors propagate widely.

---

# 90. ASSESSMENT PRIORITY

Any item used for official/authoritative scoring should be validated before low-impact enrichment content.

---

# 91. TECHNICAL PRIORITY

Before P8 expands a domain:

P7 should validate the core terminology framework for that domain.

P8 consumes P7-validated terms.

---

# 92. P7 → P8 CONTRACT

P7 must provide P8:

- terminology validation policy;
- validated technical core terms;
- unresolved terminology conflicts;
- academic register rules;
- source hierarchy;
- generated-content activation policy.

P8 must not redefine those independently.

---

# 93. CONTENT REPAIR WORKFLOW

For each finding:

`DETECT`

→ `CONFIRM`

→ `TRACE OWNER`

→ `ASSESS PROPAGATION`

→ `DEFINE CORRECT FORM`

→ `PATCH CANONICAL OWNER`

→ `REBUILD DERIVED DATA`

→ `RUN TESTS`

→ `CHECK STATE/ASSESSMENT IMPACT`

→ `CLOSE EVIDENCE`.

---

# 94. PROPAGATION ANALYSIS

Before changing a canonical item, find:

- lessons using it;
- exercises;
- tests;
- speaking;
- dialogue;
- Deep Speaking;
- search index;
- cached package;
- learner state keyed by identity.

Do not patch blind.

---

# 95. SEMANTIC IDENTITY CHANGE

If a record was semantically wrong enough that corrected content represents a different concept:

do not simply overwrite under same identity without analysis.

May require:

- new sense;
- new ID;
- alias;
- state migration;
- assessment invalidation.

---

# 96. CONTENT REVISION POLICY

Minor correction:

same ID + revision.

Semantic redefinition:

review identity.

Do not reset state for punctuation fixes.

Do not preserve mastery blindly for concept replacement.

---

# 97. ASSESSMENT INVALIDATION

If answer key or question meaning was wrong:

identify affected attempts if system supports it.

Do not silently pretend old scores remain equally valid.

Document remediation/migration policy.

P4 owns learner-state consequences.

---

# 98. CONTENT DIFF REVIEW

Before merge, produce semantic diff summary:

- linguistic facts changed;
- translations changed;
- stress changes;
- government changes;
- aspect changes;
- terminology changes;
- answer-key changes;
- examples only;
- metadata only.

This is more useful than raw JSON diff alone.

---

# 99. REVIEWER MODE

Where admin/editor exists, P12 may later expose P7 review workflow.

P7 defines rules.

P12 implements authoring/editor experience.

Do not mix responsibilities.

---

# 100. SOURCE LINK DURABILITY

Do not make runtime depend on external source pages used only for validation.

Store concise provenance references.

Canonical lesson must remain usable offline.

---

# 101. COPYRIGHT-SAFE VALIDATION

Do not copy large dictionary/corpus passages into repo.

Store:

- fact;
- concise paraphrase;
- source reference;
- minimal quotation only when allowed/necessary.

---

# 102. SECURITY OF IMPORTED CONTENT

Imported candidate data must be schema-validated and sanitized.

Linguistic validation does not replace security validation.

Route security issues to P14 if needed.

---

# 103. DATASET-BY-DATASET AUDIT

Audit at minimum:

- curriculum;
- lessons;
- grammar;
- grammar-path;
- vocab;
- exercises;
- tests;
- speaking;
- dialogue-bauman-az;
- deep-speaking-bauman;
- handwriting text labels;
- writing;
- videos metadata/transcripts;
- knowledge-index;
- simulations.

Do not assume external-data mirrors are canonical.

---

# 104. VOCABULARY AUDIT FIELDS

Measure:

- total entries;
- duplicate lemmas;
- sense distribution;
- stress coverage;
- POS coverage;
- gender coverage where applicable;
- aspect coverage for verbs;
- government coverage;
- collocation coverage;
- example coverage;
- provenance;
- level;
- stage;
- domain;
- orphan rate;
- conflict rate.

---

# 105. GRAMMAR AUDIT FIELDS

Measure:

- concept count;
- prerequisite coverage;
- example quality;
- morphology correctness;
- government references;
- contrasts;
- error links;
- level;
- assessment links;
- orphan concepts;
- contradictory rules.

---

# 106. SPEAKING/DIALOGUE AUDIT FIELDS

Measure:

- prompt correctness;
- stress support;
- register;
- role naturalness;
- expected function;
- vocabulary alignment;
- grammar alignment;
- variations;
- repair language;
- transcript/audio consistency.

---

# 107. TEST BANK AUDIT FIELDS

Measure:

- objective mapping;
- linguistic correctness;
- answer-key certainty;
- accepted variants;
- ambiguity;
- distractor quality;
- level;
- duplication;
- exposure/reuse risk.

---

# 108. TECHNICAL TERMINOLOGY MATRIX

Create domain matrix:

`Concept`
| `RU canonical`
| `RU variants`
| `VI`
| `EN if helpful`
| `abbreviation`
| `register`
| `source`
| `confidence`
| `lesson refs`.

Do not make English the canonical learning language.

---

# 109. ACADEMIC PHRASE MATRIX

For academic phrase patterns record:

- discourse function;
- Russian pattern;
- constraints;
- register;
- example;
- reusable slots;
- source/validation.

Avoid phrasebook memorization as end goal.

---

# 110. ADMINISTRATIVE RUSSIAN

Validate high-value official terms for:

- visa;
- migration;
- registration;
- dorm;
- university paperwork.

Because incorrect wording can cause real-world confusion.

Do not turn P7 into legal advice.

Only validate language usage.

---

# 111. MEDICAL/EMERGENCY SURVIVAL LANGUAGE

If present, validate simple communication phrases carefully.

Do not turn content into medical diagnosis.

P7 only checks language truth/naturalness.

---

# 112. NATURALNESS SAMPLING

For large datasets:

sample by:

- stage;
- domain;
- generator/source;
- high frequency;
- high learner exposure;
- random;
- edge cases.

If one source batch has high defect rate:

expand audit of that batch.

---

# 113. DEFECT CLUSTERING

Group findings by root cause:

- bad generator prompt;
- bad transliteration;
- translation source;
- schema mapping bug;
- duplicated legacy source;
- systematic stress omission;
- technical glossary import problem.

Fix generator/import pipeline before hand-editing thousands of rows.

---

# 114. GENERATOR FEEDBACK LOOP

If generated content shows systematic error:

1. stop bulk generation;
2. isolate faulty rule/prompt;
3. repair generator;
4. regenerate candidate set;
5. compare;
6. validate sample;
7. activate.

Do not manually patch thousands while faulty generator continues.

---

# 115. CONTENT FREEZE DURING CRITICAL AUDIT

For assessment-critical datasets under repair:

consider temporary content freeze.

Do not accept simultaneous uncontrolled bulk edits.

This is a workflow rule, not necessarily a product feature.

---

# 116. VALIDATION BATCH SIZE

Use manageable coherent batches:

- one grammar family;
- one stage vocab slice;
- one technical domain;
- one dialogue scenario cluster;
- one assessment objective family.

Avoid whole-repo rewrite.

---

# 117. BATCH ACCEPTANCE

Each batch needs:

- baseline;
- findings;
- repairs;
- source evidence;
- validators;
- regression;
- semantic diff;
- remaining unknowns.

---

# 118. P7 PILOT

Before full-course validation, pilot three different risk areas:

### Pilot A — Foundation
Example:
stress + case/government + survival phrase.

### Pilot B — Technical
Example:
AI/DB/Control terminology.

### Pilot C — Assessment
Example:
question bank + accepted answers.

Pilot proves workflow and tooling.

---

# 119. PILOT FAILURE CONDITIONS

Pilot fails if:

- source evidence cannot be reproduced;
- canonical owner unclear;
- fixes require editing multiple duplicate truths;
- validator produces high false-positive rate;
- semantic diff cannot identify impactful changes;
- assessment impact cannot be traced.

Resolve before scale-up.

---

# 120. SOURCE CACHE / EVIDENCE CACHE

Where appropriate, keep lightweight validation evidence index.

Do not re-query same stable fact unnecessarily.

But revalidate if:

- source conflict;
- content revision;
- terminology changed;
- old evidence low confidence.

---

# 121. TOKEN-EFFICIENT P7 EXECUTION

Do not load all 8,000 vocab records into model context at once.

Use:

- machine validators;
- counts/statistics;
- targeted batches;
- suspicious clusters;
- sampled review;
- file slicing;
- content graph references.

Use code for mechanical inspection.

Use model reasoning for semantic cases.

---

# 122. AUTOMATION BOUNDARY

Automate:

- structural checks;
- cross-reference checks;
- duplicate candidates;
- suspicious stress metadata;
- missing fields;
- consistency.

Human/model linguistic review:

- meaning;
- naturalness;
- register;
- technical term choice;
- source conflict;
- ambiguous answer.

---

# 123. VALIDATION SCRIPT POLICY

Scripts must be:

- deterministic;
- read-only by default;
- capable of JSON/Markdown report output;
- version-controlled;
- tested on known fixtures.

Auto-fix scripts require explicit safe rules.

---

# 124. KNOWN-GOOD FIXTURES

Create fixtures containing:

- correct stress;
- wrong stress;
- accepted variant;
- government conflict;
- aspect non-pair;
- duplicate sense;
- natural vs awkward sentence;
- technical term variant;
- ambiguous assessment item.

Use to test validators.

---

# 125. FALSE POSITIVE MANAGEMENT

Track validator precision.

A validator that flags thousands of correct records without useful triage is not production-ready.

Do not hide this by marking all as LOW.

---

# 126. FALSE NEGATIVE AWARENESS

Automated PASS does not prove naturalness.

Reports must state what a validator does NOT prove.

---

# 127. CONTENT TRUST BADGES — INTERNAL ONLY

If useful internally:

- verified;
- needs review;
- generated.

Do not clutter learner UI by default.

P13 decides presentation if any.

---

# 128. P7 REPORT STRUCTURE

Create:

- executive summary;
- authority policy;
- validation coverage;
- high-risk findings;
- dataset health;
- terminology status;
- assessment-critical status;
- generated-content status;
- unresolved conflicts;
- P8 readiness.

---

# 129. REQUIRED DELIVERABLES

Create or maintain:

`subjects/russian/docs/p7/RUSSIAN_P7_EXECUTIVE_SUMMARY.md`

`subjects/russian/docs/p7/RUSSIAN_LINGUISTIC_AUTHORITY_POLICY.md`

`subjects/russian/docs/p7/RUSSIAN_SOURCE_HIERARCHY.md`

`subjects/russian/docs/p7/RUSSIAN_VALIDATION_STATUS_MODEL.md`

`subjects/russian/docs/p7/RUSSIAN_STRESS_VALIDATION_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_MORPHOLOGY_VALIDATION_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_GOVERNMENT_VALIDATION_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_ASPECT_VALIDATION_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_COLLOCATION_NATURALNESS_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_TRANSLATION_VALIDATION_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_TECHNICAL_TERMINOLOGY_MATRIX.md`

`subjects/russian/docs/p7/RUSSIAN_ACADEMIC_REGISTER_MATRIX.md`

`subjects/russian/docs/p7/RUSSIAN_ASSESSMENT_LANGUAGE_INTEGRITY_REPORT.md`

`subjects/russian/docs/p7/RUSSIAN_GENERATED_CONTENT_VALIDATION_POLICY.md`

`subjects/russian/docs/p7/RUSSIAN_P7_RISK_REGISTER.json`

`subjects/russian/docs/p7/RUSSIAN_P7_EVIDENCE_INDEX.md`

Machine tooling may also output:

`subjects/russian/docs/p7/RUSSIAN_LINGUISTIC_FINDINGS.json`

---

# 130. VALIDATION TOOLING DELIVERABLES

When useful, add:

- lexical validator;
- stress consistency validator;
- reference validator;
- aspect-link validator;
- government validator;
- duplicate detector;
- generated-content provenance validator;
- assessment alignment/answer integrity checks.

Do not add tooling just to satisfy file count.

---

# 131. TEST GATES

P7 must run:

### Static/schema
- JSON parse;
- schema;
- IDs;
- refs;
- provenance rules.

### Linguistic fixture tests
- known correct;
- known incorrect;
- variants;
- ambiguous cases.

### Cross-data
- canonical owner consistency;
- derived index rebuild;
- no dangling references after repair.

### Assessment
- answer key integrity;
- accepted variants;
- no newly introduced ambiguity.

### Runtime smoke
- representative lessons still render;
- search resolves;
- speaking/dialogue text loads;
- assessment submits.

### State safety
- content revision does not reset learner state unless migration explicitly requires it.

---

# 132. REGRESSION MATRIX

Representative coverage:

- R01 pronunciation/foundation.
- R05 survival.
- R08 grammar/cases.
- R10 prep.
- R12 math.
- R16 AI/data.
- R17 control.
- R18 experiment.
- R22 НИР.
- R25 defense.
- vocabulary search.
- speaking.
- dialogue.
- assessment.

Do not necessarily retest every route manually if automated dependency evidence is strong.

---

# 133. PERFORMANCE SAFETY

P7 enrichment must not cause startup to load huge rich metadata unnecessarily.

Rich linguistic metadata should be:

- lazy;
- indexed;
- packed appropriately.

If performance concern appears:

coordinate with P14 later.

Do not prematurely redesign runtime unless necessary.

---

# 134. OFFLINE SAFETY

Canonical corrections must remain available offline according to existing content pack contract.

External validation sources are not runtime dependencies.

---

# 135. ACCESSIBILITY SAFETY

Stress/linguistic annotations must remain readable by:

- screen readers where relevant;
- font scaling;
- copy/search.

P13 owns final presentation.

P7 defines semantic data.

---

# 136. BRANCH RULE

Create coherent branch, conceptually:

`russian/p7-linguistic-authority`

or repository convention equivalent.

Do not mix unrelated UI redesign.

---

# 137. COMMIT RULE

Suggested coherent commits:

- authority/provenance policy;
- validators;
- foundation linguistic repairs;
- terminology repairs;
- assessment language repairs.

Do not create one 100,000-line opaque commit if avoidable.

---

# 138. PR BODY

PR must summarize:

- validation scope;
- source policy;
- datasets audited;
- critical fixes;
- technical terminology status;
- assessment integrity;
- generated-content controls;
- schema changes;
- migrations;
- tests;
- performance/offline impact;
- unresolved linguistic conflicts;
- P8 readiness.

---

# 139. MERGE RULE

Do not merge if:

- assessment-critical wrong answer remains unresolved within changed scope;
- canonical owner conflict unresolved;
- migration unsafe;
- high-risk corrections lack evidence;
- validators corrupt valid variants;
- runtime regression;
- state reset risk;
- derived indexes disagree with canonical data.

---

# 140. NO PRODUCTION PUBLISH IN P7 BY DEFAULT

P7 is a content-trust phase.

Follow project release authority.

Normally:

branch
→ PR
→ merge after PASS.

Production belongs to later release flow/P17 unless user/project explicitly authorizes otherwise.

---

# 141. P7 BLOCKERS

BLOCKER examples:

- wrong answer keys affecting mastery;
- widespread wrong stress in foundation content;
- systematic incorrect government;
- duplicate canonical vocab owners with conflicting meanings;
- technical terminology source fundamentally untrustworthy;
- content correction requires destructive state migration without safe plan.

---

# 142. P7 CRITICAL RISKS

CRITICAL examples:

- AI-generated unvalidated content marked canonical across large dataset;
- translated technical glossary with systematic semantic errors;
- assessment accepts only one of several valid Russian answers;
- corpus/index data used as canonical truth incorrectly;
- dialogue bank generated with recurring unnatural administrative language.

---

# 143. KEEP / REPAIR / DEPRECATE

Classify content:

`KEEP`

`ENRICH`

`REPAIR`

`SPLIT_SENSE`

`MERGE_DUPLICATE`

`DEPRECATE_LATER`

`BLOCK`

`UNKNOWN`.

No deletion solely from linguistic suspicion.

---

# 144. P7 QUALITY GATE — FAIL

P7 FAIL if:

- validation is only spellcheck;
- stress not audited;
- government not audited;
- aspect not audited;
- lexical sense not audited;
- naturalness ignored;
- technical terminology not validated;
- assessment answer keys not included;
- generated content can self-promote;
- source hierarchy absent;
- external evidence not reproducible;
- canonical owner conflicts ignored;
- bulk auto-fix changes meaning;
- learner state impact not assessed.

---

# 145. P7 QUALITY GATE — PASS

P7 PASS when evidence shows:

1. Linguistic authority policy exists.
2. Source hierarchy exists.
3. Validation status model exists.
4. High-risk facts are identified.
5. Foundation stress is audited.
6. Morphology audit exists.
7. Government audit exists.
8. Aspect audit exists.
9. Collocation/naturalness process exists.
10. Translation integrity is assessed.
11. Technical terminology matrix exists.
12. Academic register policy exists.
13. Assessment-critical language is validated.
14. Generated content cannot self-activate.
15. Canonical owner contradictions are resolved or explicitly blocked.
16. Automated validators have known scope/limitations.
17. Validation evidence is traceable.
18. Cross-dataset consistency is checked.
19. State safety is preserved.
20. P8 has trustworthy linguistic inputs.

---

# 146. P7 FINAL RESPONSE FORMAT

When P7 completes, respond concisely:

`P7 STATUS: PASS / FAIL / BLOCKED`

`Base SHA:`

`Head SHA:`

`Validated scope:`

`Critical linguistic fixes:`

`Stress integrity: PASS / FAIL`

`Morphology integrity: PASS / FAIL`

`Government integrity: PASS / FAIL`

`Aspect integrity: PASS / FAIL`

`Naturalness/collocation: PASS / PARTIAL / FAIL`

`Translation integrity: PASS / PARTIAL / FAIL`

`Technical terminology readiness: READY / PARTIAL / NOT READY`

`Assessment language integrity: PASS / FAIL`

`Generated-content gate: PASS / FAIL`

`State safety: PASS / FAIL`

`Unresolved conflicts:`

`P8 readiness: READY / NOT READY`

`PR:`

`Merged SHA:`

`Production: UNCHANGED unless explicitly authorized`

End with:

**P7 LINGUISTIC AUTHORITY & CONTENT VALIDATION COMPLETE**

---

# 147. EXECUTION RULE

Begin immediately when P7 is authorized.

Do not ask the user about ordinary technical actions.

Self:

`inspect`
→ `baseline`
→ `classify risk`
→ `build validators`
→ `sample`
→ `validate sources`
→ `repair canonical owner`
→ `rebuild derived data`
→ `run regression`
→ `document evidence`
→ `open PR`.

Do not expand P8 content while P7 critical linguistic trust is unresolved.

---

# 148. FINAL P7 PRINCIPLE

P7 exists to guarantee:

> **The learner is not efficiently memorizing wrong Russian.**

A large dataset is valuable only when:

- the Russian is correct;
- the meaning is correct;
- the usage is natural;
- the register is appropriate;
- the terminology is real;
- the answer key is defensible;
- provenance is known;
- uncertainty is admitted where necessary.

**TRUST BEFORE SCALE.**
**VALIDATE BEFORE TEACH.**
**CORRECT THE OWNER, NOT THE SYMPTOM.**


---

# P7 HARDENING ADDENDUM
## FINAL PROMPT COMPLETENESS PASS BEFORE P8

This addendum closes edge cases that commonly create late-stage linguistic defects.

It does not expand P7 into P8.

---

# 149. SOURCE FRESHNESS & REVALIDATION POLICY

Not every source remains equally useful forever.

Classify evidence as:

`STABLE_NORMATIVE`

`STABLE_ACADEMIC`

`VERSIONED_TECHNICAL`

`FAST_MOVING_TECHNICAL`

`EPHEMERAL_WEB`

Examples:

- spelling/stress rule: usually stable;
- a software/API term: can change;
- AI terminology: can evolve quickly;
- official administrative wording: may change with regulations/institutional forms.

P7 must record revalidation need according to source class.

Do not use one fixed expiry date for everything.

---

# 150. REVALIDATION TRIGGERS

Revalidate a linguistic fact when:

- canonical content is materially edited;
- source is superseded;
- technical terminology version changes;
- repeated learner/reviewer reports indicate conflict;
- two trusted sources disagree;
- assessment dispute exposes ambiguity;
- P8/P9 needs a new technical sense;
- generator pipeline changes.

Do not periodically revalidate stable facts without reason if evidence remains strong.

---

# 151. GOLDEN LINGUISTIC REGRESSION SET

Create a compact known-good corpus covering:

- stress;
- gender;
- cases;
- government;
- aspect;
- verbs of motion;
- collocation;
- register;
- technical terminology;
- academic phrase;
- translation;
- accepted variants;
- ambiguous cases;
- assessment answer variants.

Every validator/tooling change must run against this set.

Purpose:

prevent a “fix” from breaking previously validated language.

---

# 152. GOLDEN SET VERSIONING

Golden set has stable IDs.

When a gold item changes:

record:

- why;
- evidence;
- reviewer;
- expected validator effect.

Do not silently rewrite fixtures to make tests green.

---

# 153. PROPER NAMES & TRANSLITERATION

Audit:

- personal names;
- university/faculty names;
- city/station names;
- street names;
- company/product names;
- algorithm/author names.

Separate:

canonical Russian spelling

from:

Vietnamese/Latin transliteration.

Do not transliterate code identifiers or official product names unnecessarily.

---

# 154. TRANSLITERATION POLICY

If transliteration is pedagogically required:

define system/purpose.

Examples:

- learner pronunciation aid;
- passport/legal Latin spelling;
- search alias.

Do not mix incompatible transliteration schemes in one field.

Transliteration is support data, not Russian orthography.

---

# 155. NUMERALS · DECIMALS · UNITS

Validate Russian expression of:

- integers;
- decimals;
- fractions;
- percentages;
- ranges;
- negative values;
- scientific notation;
- dates;
- time;
- dimensions;
- SI units.

Pay attention to:

- decimal comma conventions in Russian prose;
- grammatical agreement around numerals;
- unit abbreviations;
- spacing conventions where relevant.

Do not let formatting-only normalization alter mathematical meaning.

---

# 156. SYMBOL / EQUATION LANGUAGE

Create known-good validation examples for how learners read:

- `=`
- `≠`
- `<`
- `>`
- `≤`
- `≥`
- `+`
- `−`
- `×`
- `/`
- powers;
- roots;
- indices;
- vectors;
- matrices;
- derivatives;
- integrals.

P8 consumes these validated patterns.

---

# 157. MIXED-LANGUAGE TECHNICAL TEXT

Russian technical content often contains:

- English library names;
- code;
- API names;
- variable names;
- CLI commands;
- file paths;
- SQL keywords;
- protocol names.

Validation rules:

- do not translate code tokens;
- do not decline code identifiers unless actual Russian usage does so in surrounding prose;
- preserve syntax;
- validate Russian explanatory frame around them.

---

# 158. ABBREVIATION & ACRONYM HARDENING

For each high-value abbreviation:

record when useful:

- Russian full form;
- conventional short form;
- pronunciation/readout;
- grammatical behavior;
- domain;
- accepted variants.

Do not infer expansion from letters alone.

---

# 159. TERMINOLOGY DRIFT

Technical terminology can evolve.

For each version-sensitive term, allow:

- current preferred;
- common legacy;
- English borrowing;
- deprecated;
- context-specific.

P8 must not treat all variants as synonyms without constraints.

---

# 160. DOMAIN-EXPERT ESCALATION

Some technical/academic disputes cannot be resolved safely by generic language evidence.

Escalation class:

`DOMAIN_REVIEW_REQUIRED`.

Use for:

- specialized control terminology;
- ambiguous mathematical terminology;
- institution-specific academic wording;
- research-method terms with multiple traditions;
- terminology whose incorrect choice changes technical meaning.

Do not block unrelated content while waiting for one isolated domain review.

---

# 161. ACCEPTED-VARIANT ASSESSMENT POLICY

P7 must publish accepted variant information in a machine-usable form when relevant.

Assessment should distinguish:

- exact required answer;
- accepted orthographic variant;
- accepted lexical variant;
- accepted word-order variant;
- accepted synonymous construction;
- context-dependent variant.

Do not solve this only with free-text “other answers may be possible”.

---

# 162. AMBIGUITY GATE FOR ASSESSMENT

If multiple answers can reasonably be correct and scoring cannot represent that reliably:

the item is:

`BLOCKED_FOR_OFFICIAL_ASSESSMENT`.

It may remain a practice/discussion item.

Do not force single-answer scoring onto genuine ambiguity.

---

# 163. LEARNER-EVIDENCE IMPACT OF CONTENT CORRECTION

When P7 discovers old canonical content was wrong, classify impact:

`NO_LEARNER_IMPACT`

`DISPLAY_ONLY`

`PRACTICE_EVIDENCE_AFFECTED`

`ASSESSMENT_EVIDENCE_AFFECTED`

`MASTERY_EVIDENCE_AFFECTED`.

P4 owns the actual learner-state correction.

P7 must provide the impact evidence.

---

# 164. INVALIDATED QUESTION POLICY

If an official question was wrong/ambiguous:

P7 must output:

- item ID;
- affected content revisions;
- defect;
- corrected truth;
- accepted variants;
- learner-impact class.

Do not silently overwrite and leave old score meaning unexplained.

---

# 165. CONTENT CORRECTION ROLLBACK

For high-risk batch repairs:

retain:

- pre-change snapshot/ref;
- semantic diff;
- migration mapping;
- derived-data rebuild instructions.

If repair introduces widespread regression:

rollback canonical content and derived outputs together.

---

# 166. VALIDATOR QUALITY GATE

Validators themselves must have quality evidence.

Measure where feasible:

- known-good pass rate;
- known-bad detection;
- false positives;
- false negatives known from fixtures;
- unsupported cases.

A validator with unreliable signal cannot become merge gate.

---

# 167. VALIDATOR SEVERITY CALIBRATION

Do not mark every anomaly HIGH.

Severity should reflect:

- linguistic harm;
- assessment impact;
- recurrence;
- stage;
- propagation.

This keeps P7 review queues usable.

---

# 168. SOURCE OUTAGE / LINK ROT

Validation evidence must remain understandable even if an external URL disappears.

Store:

- source identity;
- concise claim;
- enough bibliographic/reference data.

Do not store only a bare link.

---

# 169. SOURCE ACCESS LIMITATION

If a strong source cannot be accessed:

do not fabricate validation.

Use:

`SOURCE_UNAVAILABLE`

and seek another suitable source.

---

# 170. MULTI-SOURCE DISAGREEMENT

When reputable sources disagree:

do not average them.

Determine whether difference is:

- variant;
- register;
- discipline;
- chronology;
- normative vs descriptive;
- source error.

If unresolved:

mark `DISPUTED`.

---

# 171. RUSSIAN TYPOGRAPHY

Validate where relevant:

- dash vs hyphen;
- quote conventions;
- spacing;
- abbreviations;
- number/unit formatting;
- punctuation in academic examples.

Typography issues should not be allowed to mask grammatical correctness issues.

---

# 172. SEARCH NORMALIZATION REGRESSION

Search normalization must not rewrite canonical linguistic content.

Test:

- ё/е;
- stress marks;
- case;
- punctuation;
- transliteration aliases.

Search alias can be broad.

Canonical display remains precise.

---

# 173. SENSE-LEVEL GOVERNMENT

Government can differ by sense.

Therefore high-value polysemous verbs/nouns may need:

sense-specific government links.

Do not attach one government frame globally when only one sense uses it.

---

# 174. SENSE-LEVEL REGISTER

A lemma can be neutral in one sense and technical in another.

Register/domain metadata may belong to sense.

P8 must consume correct sense.

---

# 175. TECHNICAL DEFINITION CONSISTENCY

For one technical concept:

Russian term

↔ definition

↔ simple explanation

↔ Vietnamese support

must all refer to the same concept.

Flag concept drift.

---

# 176. CROSS-LANGUAGE TERM COLLISION

Special attention to terms whose English/Vietnamese gloss is ambiguous, for example concept families such as:

- state;
- control;
- plant/object;
- feature;
- accuracy;
- precision;
- recall;
- query;
- record;
- key;
- model;
- training;
- inference.

Do not assign one Russian translation globally without domain/sense.

---

# 177. CODE-SAFE LANGUAGE VALIDATION

Examples containing code must preserve:

- identifiers;
- strings when semantically code;
- syntax;
- commands;
- paths.

Only surrounding natural-language Russian is subject to normal grammar correction unless task explicitly teaches code comments/naming.

---

# 178. FORMULA-SAFE LANGUAGE VALIDATION

Do not “correct” mathematical notation through language normalization.

Validate text and notation separately, then validate relation between them.

---

# 179. P7 FINAL PROMPT-COMPLETENESS GATE

The P7 prompt itself is considered structurally complete only if it covers:

1. authority;
2. source hierarchy;
3. provenance;
4. freshness/revalidation;
5. stress;
6. orthography;
7. morphology;
8. government;
9. aspect;
10. motion verbs;
11. lexical senses;
12. collocation;
13. naturalness;
14. register/pragmatics;
15. translation;
16. technical terminology;
17. academic language;
18. proper names/transliteration;
19. numerals/units/symbols;
20. mixed code/technical text;
21. dialogue/transcript alignment;
22. assessment answers/variants;
23. generated content;
24. validators;
25. golden regression set;
26. learner-evidence impact;
27. rollback;
28. P8 handoff.

If all are defined:

`P7 PROMPT STATUS: COMPLETE / READY TO EXECUTE`.

This does NOT mean repository P7 work has already been executed.

---

# 180. P7 → P8 HARD HANDOFF

P8 may begin deep implementation only against:

- P7 validation rules;
- validated terminology subset;
- explicit unresolved conflicts;
- technical-domain review requirements;
- accepted-variant policy;
- stable canonical owners.

P8 must never silently “fix” a P7 linguistic authority decision inside domain content.

If P8 finds new linguistic conflict:

return it to P7 evidence workflow.

**P7 PROMPT HARDENING COMPLETE**
